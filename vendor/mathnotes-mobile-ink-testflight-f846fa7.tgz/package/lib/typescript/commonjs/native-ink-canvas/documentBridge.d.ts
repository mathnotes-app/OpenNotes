export declare function splitProjectedPageByLayers(payload: string, boundaries: number[]): Promise<string[]>;
export declare function composeDocument(payloads: string[], pageHeight: number): Promise<string>;
export declare function partitionDocument(payload: string, pageCount: number, pageHeight: number): Promise<string[]>;
/**
 * Page payloads of a mounted continuous canvas. Native copies the strokes on
 * the drawing thread and partitions the copy in the background; the whole
 * document never crosses into JavaScript.
 */
export declare function captureDocument(viewTag: number, pageCount: number, pageHeight: number): Promise<string[]>;
/** Render-only payloads containing neighboring overflow. Do not save these. */
export declare function projectDocumentPages(payloads: string[], pageHeight: number, pageIndices: number[]): Promise<string[]>;
/** Compose and load without returning the combined document through JavaScript. */
export declare function loadDocument(viewTag: number, payloads: string[], pageHeight: number): Promise<boolean>;
//# sourceMappingURL=documentBridge.d.ts.map