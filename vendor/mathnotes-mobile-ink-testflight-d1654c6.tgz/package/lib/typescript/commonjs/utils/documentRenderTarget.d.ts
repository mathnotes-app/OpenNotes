import type { ViewportTransformLike } from './viewportTransform';
/** Crop and resolution for a continuous-document native ink surface. */
export type DocumentRenderTarget = {
    renderScale: number;
    leftRatio: number;
    topRatio: number;
    widthRatio: number;
    heightRatio: number;
};
export type DocumentRenderLayout = {
    pageWidth: number;
    pageHeight: number;
    pageCount: number;
    contentPadding: number;
    /** Device pixels per point; defaults to PixelRatio.get(). */
    pixelRatio?: number;
    /** Highest native render scale; defaults to MAX_NATIVE_RENDER_SCALE. */
    maxRenderScale?: number;
    /** Fraction of the visible span to include beyond each edge. */
    overscanFraction?: number;
};
/** Native engines clamp render scale to this (kMaximumRenderScale in C++). */
export declare const MAX_NATIVE_RENDER_SCALE = 5;
/**
 * Returns `previous` unchanged while it still covers the visible document at
 * the wanted resolution, so a pan or pinch does not re-render native ink every
 * frame. While `isMoving`, the previous resolution is held (the view transform
 * scales it) until the visible area no longer fits it; the settled call then
 * resolves the crisp scale.
 */
export declare function resolveDocumentRenderTarget(previous: DocumentRenderTarget | null, transform: ViewportTransformLike | null, layout: DocumentRenderLayout, isMoving: boolean): DocumentRenderTarget;
//# sourceMappingURL=documentRenderTarget.d.ts.map