import { NativeModules } from 'react-native';

interface DocumentBridge {
  loadDocument(viewTag: number, payloads: string[], pageHeight: number): Promise<boolean>;
  projectDocumentPages(payloads: string[], pageHeight: number, pageIndices: number[]): Promise<string[]>;
  composeDocument(payloads: string[], pageHeight: number): Promise<string>;
  partitionDocument(payload: string, pageCount: number, pageHeight: number): Promise<string[]>;
  captureDocument(viewTag: number, pageCount: number, pageHeight: number): Promise<string[]>;
  splitProjectedPageByLayers(payload: string, boundaries: number[]): Promise<string[]>;
}

export function splitProjectedPageByLayers(payload: string, boundaries: number[]): Promise<string[]> {
  return bridge().splitProjectedPageByLayers(payload, boundaries);
}
function bridge(): DocumentBridge {
  const native = NativeModules.MobileInkDocumentBridge as DocumentBridge | undefined;
  if (!native) throw new Error('MobileInkDocumentBridge is unavailable. Rebuild the app with the continuous document engine.');
  return native;
}
export function composeDocument(payloads: string[], pageHeight: number): Promise<string> {
  return bridge().composeDocument(payloads, pageHeight);
}
export function partitionDocument(payload: string, pageCount: number, pageHeight: number): Promise<string[]> {
  return bridge().partitionDocument(payload, pageCount, pageHeight);
}

/**
 * Page payloads of a mounted continuous canvas. Native copies the strokes on
 * the drawing thread and partitions the copy in the background; the whole
 * document never crosses into JavaScript.
 */
export function captureDocument(viewTag: number, pageCount: number, pageHeight: number): Promise<string[]> {
  return bridge().captureDocument(viewTag, pageCount, pageHeight);
}

/** Render-only payloads containing neighboring overflow. Do not save these. */
export function projectDocumentPages(payloads: string[], pageHeight: number, pageIndices: number[]): Promise<string[]> {
  return bridge().projectDocumentPages(payloads, pageHeight, pageIndices);
}

/** Compose and load without returning the combined document through JavaScript. */
export function loadDocument(viewTag: number, payloads: string[], pageHeight: number): Promise<boolean> {
  return bridge().loadDocument(viewTag, payloads, pageHeight);
}
