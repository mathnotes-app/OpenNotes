type Box = {
    x: number;
    y: number;
    width: number;
    height: number;
};
export type VectorPdfLayer = {
    kind: "ink";
    drawing: string;
} | ({
    kind: "text";
    text: string;
    fontSize: number;
    color: string;
    padding?: number;
} & Box) | ({
    kind: "image";
    uri: string;
    rotation?: number;
    crop?: Box;
    cornerRadius?: number;
} & Box) | {
    kind: "overlay";
    uri: string;
};
export type VectorPdfPage = {
    width: number;
    height: number;
    density: number;
    pdfPage?: number;
    paper?: string;
    pageIndex?: number;
    layers: VectorPdfLayer[];
};
export declare function supportsVectorPdfExport(): boolean;
/** Pulls one page at a time so inserted photos and raster effects stay bounded. */
export declare function writeVectorPdf(sourceUri: string | null | undefined, pageCount: number, pageAt: (index: number, sourcePageCount: number) => Promise<VectorPdfPage>): Promise<string>;
/** Project a bounded range of pages while retaining ink that crosses page seams. */
export declare function createPdfInkProjector(payloads: string[], pageHeight: number): (index: number) => Promise<string>;
export {};
//# sourceMappingURL=pdfExport.d.ts.map