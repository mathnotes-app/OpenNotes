#import <Foundation/Foundation.h>

// Don't include Skia headers here - they're included by SkiaDrawingEngine.h
// Just include our engine which has its own Skia includes
#include "cpp/SkiaDrawingEngine.h"
#include "cpp/DrawingSerialization.h"
#include "cpp/DisplayAppearance.h"
#include "cpp/PathRenderer.h"
#include "cpp/EraserMaskOptimization.h"
#include "cpp/StrokeTilePreparation.h"

// Additional Skia includes for batch export PDF handling
// Note: SkImages namespace functions are in SkImage.h
#include <include/core/SkImage.h>
#include <include/core/SkData.h>
#include <include/core/SkColorSpace.h>
#include <include/core/SkColorFilter.h>
#include <include/core/SkPaint.h>
#include <include/effects/SkColorMatrix.h>
#import <Metal/Metal.h>

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdocumentation"
#include <include/gpu/ganesh/GrBackendSurface.h>
#include <include/gpu/ganesh/GrDirectContext.h>
#include <include/gpu/ganesh/SkImageGanesh.h>
#include <include/gpu/ganesh/SkSurfaceGanesh.h>
#include <include/gpu/ganesh/mtl/GrMtlBackendContext.h>
#include <include/gpu/ganesh/mtl/GrMtlBackendSurface.h>
#include <include/gpu/ganesh/mtl/GrMtlDirectContext.h>
#include <include/gpu/ganesh/mtl/GrMtlTypes.h>
#pragma clang diagnostic pop

#include <algorithm>
#include <climits>
#include <cmath>
#include <unordered_map>

namespace {

struct PageStrokeSegment {
    int pageIndex = 0;
    std::vector<nativedrawing::Point> points;
};

int clampPageIndexForY(float y, int pageCount, float pageHeight) {
    if (pageCount <= 0 || pageHeight <= 0.0f) {
        return 0;
    }

    const int unclamped = static_cast<int>(std::floor(y / pageHeight));
    return std::max(0, std::min(pageCount - 1, unclamped));
}

nativedrawing::Point interpolatePointAtY(
    const nativedrawing::Point& start,
    const nativedrawing::Point& end,
    float targetY
) {
    const float denominator = end.y - start.y;
    const float rawT = std::fabs(denominator) < 0.0001f
        ? 0.0f
        : (targetY - start.y) / denominator;
    const float t = std::max(0.0f, std::min(1.0f, rawT));

    nativedrawing::Point interpolated;
    interpolated.x = start.x + (end.x - start.x) * t;
    interpolated.y = targetY;
    interpolated.pressure = start.pressure + (end.pressure - start.pressure) * t;
    interpolated.azimuthAngle = start.azimuthAngle + (end.azimuthAngle - start.azimuthAngle) * t;
    interpolated.altitude = start.altitude + (end.altitude - start.altitude) * t;
    interpolated.calculatedWidth = start.calculatedWidth + (end.calculatedWidth - start.calculatedWidth) * t;
    interpolated.timestamp = start.timestamp + static_cast<long>((end.timestamp - start.timestamp) * t);
    return interpolated;
}

bool deserializeDrawingBytes(
    const uint8_t* data,
    int size,
    nativedrawing::DrawingSerialization& serializer,
    std::vector<nativedrawing::Stroke>& strokes
) {
    if (!data || size <= 0) {
        strokes.clear();
        return true;
    }

    const std::vector<uint8_t> buffer(data, data + size);
    return serializer.deserialize(buffer, strokes);
}

void renderWithCpuColorOrdering(nativedrawing::SkiaDrawingEngine* engine, SkCanvas* canvas, bool cropped, bool dark) {
    if (engine->hasImageLayers()) {
        engine->setInkDisplayTransform(dark, true);
        if (cropped) engine->renderVisibleViewport(canvas); else engine->render(canvas);
        return;
    }
    engine->setInkDisplayTransform(false, false);
    SkPaint outputPaint;
    outputPaint.setColorFilter(nativedrawing::makeDisplayColorFilter(dark, true));
    canvas->saveLayer(nullptr, &outputPaint);
    if (cropped) engine->renderVisibleViewport(canvas);
    else engine->render(canvas);
    canvas->restore();
}

void translateStrokeInPlace(
    nativedrawing::Stroke& stroke,
    float deltaY,
    size_t affectedStrokeOffset
) {
    for (auto& point : stroke.points) {
        point.y += deltaY;
    }

    for (auto& circle : stroke.erasedBy) {
        circle.y += deltaY;
    }

    if (stroke.isEraser && affectedStrokeOffset > 0) {
        std::unordered_set<size_t> translatedIndices;
        for (size_t index : stroke.affectedStrokeIndices) {
            translatedIndices.insert(index + affectedStrokeOffset);
        }
        stroke.affectedStrokeIndices = std::move(translatedIndices);
    }

    stroke.path.reset();
    stroke.pathLength = 0.0f;
    stroke.cachedEraserPath.reset();
    stroke.cachedEraserCount = 0;
    stroke.cachedHasVisiblePoints = true;
}

std::vector<PageStrokeSegment> splitStrokeAcrossPages(
    const nativedrawing::Stroke& stroke,
    int pageCount,
    float pageHeight
) {
    std::vector<PageStrokeSegment> segments;
    if (stroke.points.empty() || pageCount <= 0 || pageHeight <= 0.0f) {
        return segments;
    }

    const int firstPageIndex = clampPageIndexForY(stroke.points.front().y, pageCount, pageHeight);
    segments.push_back(PageStrokeSegment{ firstPageIndex, { stroke.points.front() } });

    for (size_t index = 1; index < stroke.points.size(); ++index) {
        const nativedrawing::Point& previousPoint = stroke.points[index - 1];
        const nativedrawing::Point& currentPoint = stroke.points[index];
        const int previousPageIndex = clampPageIndexForY(previousPoint.y, pageCount, pageHeight);
        const int currentPageIndex = clampPageIndexForY(currentPoint.y, pageCount, pageHeight);

        if (previousPageIndex == currentPageIndex || std::fabs(currentPoint.y - previousPoint.y) < 0.0001f) {
          segments.back().points.push_back(currentPoint);
          continue;
        }

        int traversedPageIndex = previousPageIndex;
        const int direction = currentPageIndex > previousPageIndex ? 1 : -1;

        while (traversedPageIndex != currentPageIndex) {
            const float boundaryY = direction > 0
                ? static_cast<float>(traversedPageIndex + 1) * pageHeight
                : static_cast<float>(traversedPageIndex) * pageHeight;

            nativedrawing::Point boundaryPoint = interpolatePointAtY(
                previousPoint,
                currentPoint,
                boundaryY
            );
            segments.back().points.push_back(boundaryPoint);

            traversedPageIndex += direction;
            PageStrokeSegment nextSegment;
            nextSegment.pageIndex = traversedPageIndex;
            nextSegment.points.push_back(boundaryPoint);
            segments.push_back(std::move(nextSegment));
        }

        segments.back().points.push_back(currentPoint);
    }

    return segments;
}

nativedrawing::Stroke makePageLocalStroke(
    const nativedrawing::Stroke& originalStroke,
    const PageStrokeSegment& segment,
    float pageHeight
) {
    nativedrawing::Stroke pageStroke = originalStroke;
    pageStroke.points.clear();
    pageStroke.points.reserve(segment.points.size());
    pageStroke.affectedStrokeIndices.clear();
    pageStroke.erasedBy.clear();
    pageStroke.path.reset();
    pageStroke.pathLength = 0.0f;
    pageStroke.cachedEraserPath.reset();
    pageStroke.cachedEraserCount = 0;
    pageStroke.cachedHasVisiblePoints = true;

    const float pageTop = static_cast<float>(segment.pageIndex) * pageHeight;
    const float pageBottom = pageTop + pageHeight;

    for (const auto& point : segment.points) {
        nativedrawing::Point localPoint = point;
        localPoint.y -= pageTop;
        pageStroke.points.push_back(localPoint);
    }

    for (const auto& circle : originalStroke.erasedBy) {
        if ((circle.y + circle.radius) < pageTop || (circle.y - circle.radius) > pageBottom) {
            continue;
        }

        nativedrawing::EraserCircle localCircle = circle;
        localCircle.y -= pageTop;
        pageStroke.erasedBy.push_back(localCircle);
    }

    return pageStroke;
}

} // namespace

using namespace nativedrawing;

// C wrapper functions for Swift
extern "C" {
void* snapshotZoomTiles(void* engine, float scale, float left, float top, float width, float height) {
    if (!engine) return nullptr;
    try { return static_cast<SkiaDrawingEngine*>(engine)->prepareStrokeTiles(scale, left, top, width, height).release(); }
    catch (...) { NSLog(@"[MobileInk] Could not snapshot zoom tiles"); return nullptr; }
}

void limitZoomTileContext(void* contextPtr) {
    if (!contextPtr) return;
    auto* context = static_cast<sk_sp<GrDirectContext>*>(contextPtr)->get();
    if (context) context->setResourceCacheLimit(32 * 1024 * 1024);
}

int prepareNextZoomTile(void* snapshot, void* contextPtr, void* devicePtr, void** outputTexture) {
    if (!snapshot || !contextPtr || !devicePtr || !outputTexture) return -1;
    *outputTexture = nullptr;
    try {
        auto* context = static_cast<sk_sp<GrDirectContext>*>(contextPtr)->get();
        auto surface = context ? SkSurfaces::RenderTarget(context, skgpu::Budgeted::kYes,
            SkImageInfo::MakeN32Premul(1, 1)) : nullptr;
        if (!surface) return -1;
        auto& batch = *static_cast<StrokeTilePreparation*>(snapshot);
        sk_sp<SkImage> tile;
        const int result = SkiaDrawingEngine::renderPreparedStrokeTileImage(batch, surface->getCanvas(), tile);
        if (result != 1) return result;
        id<MTLDevice> device = (__bridge id<MTLDevice>)devicePtr;
        auto descriptor = [MTLTextureDescriptor texture2DDescriptorWithPixelFormat:MTLPixelFormatBGRA8Unorm
            width:batch.ready.width height:batch.ready.height mipmapped:NO];
        descriptor.usage = MTLTextureUsageRenderTarget | MTLTextureUsageShaderRead;
        descriptor.storageMode = MTLStorageModePrivate;
        id<MTLTexture> texture = [device newTextureWithDescriptor:descriptor];
        if (!texture) return -1;
        GrMtlTextureInfo info; info.fTexture.retain((__bridge void*)texture);
        auto target = GrBackendRenderTargets::MakeMtl(batch.ready.width, batch.ready.height, info);
        auto destination = SkSurfaces::WrapBackendRenderTarget(context, target, kTopLeft_GrSurfaceOrigin,
            kBGRA_8888_SkColorType, nullptr, nullptr);
        if (!destination) return -1;
        SkPaint copy; copy.setBlendMode(SkBlendMode::kSrc);
        destination->getCanvas()->drawImage(tile, 0, 0, SkSamplingOptions(), &copy);
        context->flushAndSubmit(destination.get(), GrSyncCpu::kYes);
        *outputTexture = (__bridge_retained void*)texture;
        return 1;
    } catch (...) { NSLog(@"[MobileInk] Could not prepare a zoom tile"); return -1; }
}

void releaseZoomTileTexture(void* texture) { if (texture) CFRelease(texture); }

bool installPreparedZoomTile(void* engine, void* snapshot, void* contextPtr, void* texturePtr) {
    if (!texturePtr) return false;
    id<MTLTexture> texture = (__bridge_transfer id<MTLTexture>)texturePtr;
    if (!engine || !snapshot || !contextPtr) return false;
    try {
        auto& batch = *static_cast<StrokeTilePreparation*>(snapshot);
        auto* context = static_cast<sk_sp<GrDirectContext>*>(contextPtr)->get();
        if (!context || batch.context != context || texture.width != batch.ready.width || texture.height != batch.ready.height) return false;
        GrMtlTextureInfo info; info.fTexture.retain((__bridge void*)texture);
        auto backend = GrBackendTextures::MakeMtl(batch.ready.width, batch.ready.height, skgpu::Mipmapped::kNo, info);
        void* lease = (__bridge_retained void*)texture;
        auto release = [](void* p) { if (p) CFRelease(p); };
        batch.pixels = SkImages::BorrowTextureFrom(context, backend, kTopLeft_GrSurfaceOrigin,
            kBGRA_8888_SkColorType, kPremul_SkAlphaType, nullptr, release, lease);
        if (!batch.pixels) return false;
        const bool installed = static_cast<SkiaDrawingEngine*>(engine)->installPreparedStrokeTile(batch);
        if (!installed) batch.pixels.reset();
        return installed;
    }
    catch (...) { NSLog(@"[MobileInk] Could not install a zoom tile"); return false; }
}

bool hasPreparedZoomTiles(void* engine, void* snapshot) {
    if (!engine || !snapshot) return false;
    try { return static_cast<SkiaDrawingEngine*>(engine)->hasPreparedStrokeTiles(
        *static_cast<StrokeTilePreparation*>(snapshot)); }
    catch (...) { NSLog(@"[MobileInk] Could not check prepared zoom tiles"); return false; }
}

void releaseZoomTileSnapshot(void* snapshot) { delete static_cast<StrokeTilePreparation*>(snapshot); }

void* snapshotEraserMasks(void* engine) {
    if (!engine) return nullptr;
    try { return static_cast<SkiaDrawingEngine*>(engine)->snapshotEraserMasks().release(); }
    catch (...) { NSLog(@"[MobileInk] Could not snapshot eraser masks for optimization"); return nullptr; }
}

int optimizeNextEraserMask(void* snapshot) {
    if (!snapshot) return 0;
    try { return nativedrawing::optimizeNextEraserMask(*static_cast<nativedrawing::EraserMaskOptimizationBatch*>(snapshot)); }
    catch (...) { NSLog(@"[MobileInk] Could not optimize an eraser mask"); return 0; }
}

void installOptimizedEraserMask(void* engine, void* snapshot) {
    if (!engine || !snapshot) return;
    try {
        static_cast<SkiaDrawingEngine*>(engine)->installOptimizedEraserMask(
            *static_cast<nativedrawing::EraserMaskOptimizationBatch*>(snapshot));
    } catch (...) { NSLog(@"[MobileInk] Could not install an optimized eraser mask"); }
}

void releaseEraserMaskSnapshot(void* snapshot) {
    delete static_cast<nativedrawing::EraserMaskOptimizationBatch*>(snapshot);
}
void clearEraserMaskCache() { nativedrawing::clearEraserMaskOptimizationCache(); }
uint64_t reserveDocumentLayerOrder(void* engine) {
    return engine ? static_cast<SkiaDrawingEngine*>(engine)->reserveLayerOrder() : 0;
}

void* createDrawingEngine(int width, int height) {
    return new SkiaDrawingEngine(width, height);
}

void* createContinuousDrawingEngine(int width, int height) {
    return new SkiaDrawingEngine(width, height, true);
}

bool resizeContinuousDrawingEngine(void* engine, int width, int height) {
    return engine && static_cast<SkiaDrawingEngine*>(engine)->resizeDocument(width, height);
}

void destroyDrawingEngine(void* engine) {
    if (engine) {
        delete static_cast<SkiaDrawingEngine*>(engine);
    }
}

void touchBegan(void* engine, float x, float y, float pressure, float azimuth, float altitude, long timestamp, bool isPencilInput) {
    if (engine) {
        static_cast<SkiaDrawingEngine*>(engine)->touchBegan(x, y, pressure, azimuth, altitude, timestamp, isPencilInput);
    }
}

void touchMoved(void* engine, float x, float y, float pressure, float azimuth, float altitude, long timestamp, bool isPencilInput) {
    if (engine) {
        static_cast<SkiaDrawingEngine*>(engine)->touchMoved(x, y, pressure, azimuth, altitude, timestamp, isPencilInput);
    }
}

void touchEnded(void* engine, long timestamp) {
    if (engine) {
        static_cast<SkiaDrawingEngine*>(engine)->touchEnded(timestamp);
    }
}

bool updateHoldShapePreview(void* engine, long timestamp) {
    if (!engine) {
        return false;
    }

    return static_cast<SkiaDrawingEngine*>(engine)->updateHoldShapePreview(timestamp);
}

void setHoldToShapeEnabled(void* engine, bool enabled) {
    if (engine) static_cast<SkiaDrawingEngine*>(engine)->setHoldToShapeEnabled(enabled);
}

void warmCrayonTextures() {
    nativedrawing::PathRenderer::warmCrayonTextures();
}

void setViewportMotionActive(void* engine, bool active) {
    if (engine) static_cast<SkiaDrawingEngine*>(engine)->setViewportMotionActive(active);
}

// Predictive touch support for Apple Pencil low-latency rendering
void clearPredictedPoints(void* engine) {
    if (engine) {
        static_cast<SkiaDrawingEngine*>(engine)->clearPredictedPoints();
    }
}

void addPredictedPoint(void* engine, float x, float y, float pressure, float azimuth, float altitude, long timestamp, bool isPencilInput) {
    if (engine) {
        static_cast<SkiaDrawingEngine*>(engine)->addPredictedPoint(x, y, pressure, azimuth, altitude, timestamp, isPencilInput);
    }
}

bool clearContinuousDocumentPage(void* engine, int pageIndex, float pageHeight) {
    return engine && static_cast<SkiaDrawingEngine*>(engine)->clearDocumentPage(pageIndex, pageHeight);
}

void clearCanvas(void* engine) {
    if (engine) {
        static_cast<SkiaDrawingEngine*>(engine)->clear();
    }
}

bool commitExternalEdit(void* engine, const char* before, const char* after) {
    return engine && before && after &&
        static_cast<SkiaDrawingEngine*>(engine)->commitExternalEdit(before, after);
}

char* undoExternalEdit(void* engine) {
    if (!engine) return nullptr;
    const auto payload = static_cast<SkiaDrawingEngine*>(engine)->undo();
    return payload.empty() ? nullptr : strdup(payload.c_str());
}

char* redoExternalEdit(void* engine) {
    if (!engine) return nullptr;
    const auto payload = static_cast<SkiaDrawingEngine*>(engine)->redo();
    return payload.empty() ? nullptr : strdup(payload.c_str());
}

void undoStroke(void* engine) {
    if (engine) {
        static_cast<SkiaDrawingEngine*>(engine)->undo();
    }
}

void redoStroke(void* engine) {
    if (engine) {
        static_cast<SkiaDrawingEngine*>(engine)->redo();
    }
}

void setStrokeColor(void* engine, uint32_t color) {
    if (engine) {
        static_cast<SkiaDrawingEngine*>(engine)->setStrokeColor(color);
    }
}

void setStrokeWidth(void* engine, float width) {
    if (engine) {
        static_cast<SkiaDrawingEngine*>(engine)->setStrokeWidth(width);
    }
}

void setTool(void* engine, const char* toolType) {
    if (engine) {
        static_cast<SkiaDrawingEngine*>(engine)->setTool(toolType);
    }
}

void setToolWithParams(void* engine, const char* toolType, float width, uint32_t color, const char* eraserMode) {
    if (engine) {
        static_cast<SkiaDrawingEngine*>(engine)->setToolWithParams(toolType, width, color, eraserMode);
    }
}

void setBackgroundType(void* engine, const char* backgroundType) {
    if (engine && backgroundType) {
        static_cast<SkiaDrawingEngine*>(engine)->setBackgroundType(backgroundType);
    }
}

void eraseObjects(void* engine) {
    if (engine) {
        static_cast<SkiaDrawingEngine*>(engine)->eraseObjects();
    }
}

bool canUndo(void* engine) {
    if (engine) {
        return static_cast<SkiaDrawingEngine*>(engine)->canUndo();
    }
    return false;
}

bool canRedo(void* engine) {
    if (engine) {
        return static_cast<SkiaDrawingEngine*>(engine)->canRedo();
    }
    return false;
}

bool isEmpty(void* engine) {
    if (engine) {
        return static_cast<SkiaDrawingEngine*>(engine)->isEmpty();
    }
    return true;
}

void renderToCanvas(void* engine, void* canvas) {
    if (engine && canvas) {
        auto* drawing = static_cast<SkiaDrawingEngine*>(engine);
        drawing->setInkDisplayTransform(false, false);
        drawing->render(static_cast<SkCanvas*>(canvas));
    }
}

void renderVisibleViewportToCanvas(void* engine, void* canvas) {
    if (engine && canvas) {
        auto* drawing = static_cast<SkiaDrawingEngine*>(engine);
        drawing->setInkDisplayTransform(false, false);
        drawing->renderVisibleViewport(static_cast<SkCanvas*>(canvas));
    }
}

void renderToDisplayCanvas(void* engine, void* canvas, bool cropped, bool dark) {
    if (!engine || !canvas) return;
    auto* target = static_cast<SkCanvas*>(canvas);
    auto* drawing = static_cast<SkiaDrawingEngine*>(engine);
    if (drawing->hasImageLayers()) {
        drawing->setInkDisplayTransform(dark, false);
        if (cropped) drawing->renderVisibleViewport(target); else drawing->render(target);
        return;
    }
    drawing->setInkDisplayTransform(false, false);
    SkPaint paint;
    paint.setColorFilter(nativedrawing::makeDisplayColorFilter(dark, false));
    if (dark) target->saveLayer(nullptr, &paint);
    if (cropped) drawing->renderVisibleViewport(target);
    else drawing->render(target);
    if (dark) target->restore();
}

void renderToCanvasForExport(void* engine, void* canvas) {
    if (engine && canvas) {
        auto* drawing = static_cast<SkiaDrawingEngine*>(engine);
        drawing->setInkDisplayTransform(false, false);
        drawing->renderForExport(static_cast<SkCanvas*>(canvas));
    }
}

void setRenderViewport(
    void* engine,
    float renderScale,
    float visibleLeft,
    float visibleTop,
    float visibleWidth,
    float visibleHeight
) {
    if (engine) {
        static_cast<SkiaDrawingEngine*>(engine)->setRenderViewport(
            renderScale,
            visibleLeft,
            visibleTop,
            visibleWidth,
            visibleHeight
        );
    }
}

void* createGaneshMetalContext(void* devicePtr, void* commandQueuePtr) {
    if (!devicePtr || !commandQueuePtr) {
        return nullptr;
    }

    id<MTLDevice> device = (__bridge id<MTLDevice>)devicePtr;
    id<MTLCommandQueue> commandQueue = (__bridge id<MTLCommandQueue>)commandQueuePtr;

    GrMtlBackendContext backendContext = {};
    backendContext.fDevice.retain((__bridge void*)device);
    backendContext.fQueue.retain((__bridge void*)commandQueue);

    sk_sp<GrDirectContext> context = GrDirectContexts::MakeMetal(backendContext);
    if (!context) {
        NSLog(@"[MobileInk][Ganesh] Failed to create GrDirectContext for Metal");
        return nullptr;
    }

    return new sk_sp<GrDirectContext>(std::move(context));
}

void destroyGaneshMetalContext(void* contextPtr) {
    if (!contextPtr) {
        return;
    }

    auto* contextHandle = static_cast<sk_sp<GrDirectContext>*>(contextPtr);
    if (contextHandle->get()) {
        (*contextHandle)->flushAndSubmit();
    }
    delete contextHandle;
}

bool renderToGaneshMetalTextureForDisplay(void* engine, void* contextPtr, void* texturePtr, int width, int height, bool cropped, bool dark) {
    if (!engine || !contextPtr || !texturePtr || width <= 0 || height <= 0) {
        return false;
    }

    auto* contextHandle = static_cast<sk_sp<GrDirectContext>*>(contextPtr);
    GrDirectContext* directContext = contextHandle->get();
    if (!directContext) {
        return false;
    }

    id<MTLTexture> texture = (__bridge id<MTLTexture>)texturePtr;
    GrMtlTextureInfo textureInfo;
    textureInfo.fTexture.retain((__bridge void*)texture);

    GrBackendRenderTarget backendRenderTarget =
        GrBackendRenderTargets::MakeMtl(width, height, textureInfo);

    sk_sp<SkSurface> surface = SkSurfaces::WrapBackendRenderTarget(
        directContext,
        backendRenderTarget,
        kTopLeft_GrSurfaceOrigin,
        kBGRA_8888_SkColorType,
        nullptr,
        nullptr
    );

    if (!surface) {
        NSLog(@"[MobileInk][Ganesh] Failed to wrap MTKView drawable texture");
        return false;
    }

    SkCanvas* canvas = surface->getCanvas();
    canvas->clear(SK_ColorTRANSPARENT);
    renderWithCpuColorOrdering(static_cast<SkiaDrawingEngine*>(engine), canvas, cropped, dark);
    directContext->flushAndSubmit(surface.get());
    return true;
}

bool renderToGaneshMetalTexture(void* engine, void* contextPtr, void* texturePtr, int width, int height, bool cropped) {
    return renderToGaneshMetalTextureForDisplay(engine, contextPtr, texturePtr, width, height, cropped, false);
}

void* createSkiaCanvas(void* pixels, int width, int height, int rowBytes) {
    SkImageInfo info = SkImageInfo::MakeN32Premul(width, height);
    sk_sp<SkSurface> surface = SkSurfaces::WrapPixels(info, pixels, rowBytes);
    if (surface) {
        SkCanvas* canvas = surface->getCanvas();
        surface->ref();
        return canvas;
    }
    return nullptr;
}

void scaleSkiaCanvas(void* canvas, float scaleX, float scaleY) {
    if (canvas) {
        SkCanvas* skCanvas = static_cast<SkCanvas*>(canvas);
        skCanvas->scale(scaleX, scaleY);
    }
}

void destroySkiaCanvas(void* canvas) {
    if (canvas) {
        SkCanvas* skCanvas = static_cast<SkCanvas*>(canvas);
        skCanvas->getSurface()->unref();
    }
}

// Selection operations
bool selectStrokeAt(void* engine, float x, float y) {
    if (engine) {
        return static_cast<SkiaDrawingEngine*>(engine)->selectStrokeAt(x, y);
    }
    return false;
}

bool selectShapeStrokeAt(void* engine, float x, float y) {
    if (engine) {
        return static_cast<SkiaDrawingEngine*>(engine)->selectShapeStrokeAt(x, y);
    }
    return false;
}

void clearSelection(void* engine) {
    if (engine) {
        static_cast<SkiaDrawingEngine*>(engine)->clearSelection();
    }
}

void deleteSelection(void* engine) {
    if (engine) {
        static_cast<SkiaDrawingEngine*>(engine)->deleteSelection();
    }
}

void copySelection(void* engine) {
    if (engine) {
        static_cast<SkiaDrawingEngine*>(engine)->copySelection();
    }
}

void pasteSelection(void* engine, float offsetX, float offsetY) {
    if (engine) {
        static_cast<SkiaDrawingEngine*>(engine)->pasteSelection(offsetX, offsetY);
    }
}

void moveSelection(void* engine, float dx, float dy) {
    if (engine) {
        static_cast<SkiaDrawingEngine*>(engine)->moveSelection(dx, dy);
    }
}

void finalizeMove(void* engine) {
    if (engine) {
        static_cast<SkiaDrawingEngine*>(engine)->finalizeMove();
    }
}

void cancelSelectionMove(void* engine) {
    if (engine) {
        static_cast<SkiaDrawingEngine*>(engine)->endSelectionDrag();
    }
}

void beginSelectionTransform(void* engine, int handleIndex) {
    if (engine) {
        static_cast<SkiaDrawingEngine*>(engine)->beginSelectionTransform(handleIndex);
    }
}

void updateSelectionTransform(void* engine, float x, float y) {
    if (engine) {
        static_cast<SkiaDrawingEngine*>(engine)->updateSelectionTransform(x, y);
    }
}

void finalizeSelectionTransform(void* engine) {
    if (engine) {
        static_cast<SkiaDrawingEngine*>(engine)->finalizeSelectionTransform();
    }
}

void cancelSelectionTransform(void* engine) {
    if (engine) {
        static_cast<SkiaDrawingEngine*>(engine)->cancelSelectionTransform();
    }
}

int getSelectionCount(void* engine) {
    if (engine) {
        return static_cast<SkiaDrawingEngine*>(engine)->getSelectionCount();
    }
    return 0;
}

void getSelectionBounds(void* engine, float* outBounds) {
    if (engine && outBounds) {
        std::vector<float> bounds = static_cast<SkiaDrawingEngine*>(engine)->getSelectionBounds();
        if (bounds.size() == 4) {
            outBounds[0] = bounds[0]; // minX
            outBounds[1] = bounds[1]; // minY
            outBounds[2] = bounds[2]; // maxX
            outBounds[3] = bounds[3]; // maxY
        }
    }
}

// Copies serialized bytes into a buffer Swift frees with freeSerializedData.
// Empty data yields nullptr with *outSize == 0; -1 marks a failure.
static uint8_t* copyToSerializedBuffer(const std::vector<uint8_t>& data, int* outSize) {
    if (data.size() > INT_MAX) {
        *outSize = -1;
        return nullptr;
    }
    *outSize = static_cast<int>(data.size());
    if (data.empty()) return nullptr;
    uint8_t* buffer = new uint8_t[data.size()];
    std::memcpy(buffer, data.data(), data.size());
    return buffer;
}

// A snapshot owns its strokes independently of the view/engine lifetime. The UI
// thread only copies state; serialization must not hold the live engine's lock.
void* snapshotDrawing(void* engine) {
    if (!engine) return nullptr;
    try {
        return new std::vector<nativedrawing::Stroke>(
            static_cast<SkiaDrawingEngine*>(engine)->snapshotDrawing());
    } catch (...) { return nullptr; }
}

// The caller owns the vector before and after this swap. It can release the
// previous drawing off-thread after the main-thread handoff completes.
bool replaceDrawingSnapshot(void* engine, void* snapshot) {
    if (!engine || !snapshot) return false;
    try {
        static_cast<SkiaDrawingEngine*>(engine)->replaceDrawing(
            *static_cast<std::vector<nativedrawing::Stroke>*>(snapshot));
        return true;
    } catch (...) { return false; }
}

uint8_t* serializeDrawingSnapshot(void* snapshot, int* outSize) {
    if (!outSize) return nullptr;
    *outSize = -1;
    if (!snapshot) return nullptr;
    try {
        nativedrawing::DrawingSerialization serializer;
        return copyToSerializedBuffer(
            serializer.serialize(*static_cast<std::vector<nativedrawing::Stroke>*>(snapshot)), outSize);
    } catch (...) {
        *outSize = -1;
        return nullptr;
    }
}

void freeDrawingSnapshot(void* snapshot) {
    delete static_cast<std::vector<nativedrawing::Stroke>*>(snapshot);
}

// Serialization operations
uint8_t* serializeDrawing(void* engine, int* outSize) {
    if (!outSize) return nullptr;
    if (!engine) {
        *outSize = 0;
        return nullptr;
    }
    return copyToSerializedBuffer(static_cast<SkiaDrawingEngine*>(engine)->serializeDrawing(), outSize);
}

void freeSerializedData(uint8_t* data) {
    if (data) {
        delete[] data;
    }
}

bool deserializeDrawing(void* engine, const uint8_t* data, int size) {
    if (!engine || !data || size <= 0) {
        return false;
    }

    std::vector<uint8_t> buffer(data, data + size);
    return static_cast<SkiaDrawingEngine*>(engine)->deserializeDrawing(buffer);
}

uint8_t* composeContinuousWindow(
    const uint8_t** pageDataPtrs,
    const int* pageDataSizes,
    int pageCount,
    float pageHeight,
    int* outSize
) {
    if (!outSize) {
        return nullptr;
    }

    *outSize = 0;
    if (!pageDataPtrs || !pageDataSizes || pageCount <= 0 || pageHeight <= 0.0f) {
        return nullptr;
    }

    DrawingSerialization serializer;
    std::vector<Stroke> combinedStrokes;

    for (int pageIndex = 0; pageIndex < pageCount; ++pageIndex) {
        std::vector<Stroke> pageStrokes;
        if (!deserializeDrawingBytes(pageDataPtrs[pageIndex], pageDataSizes[pageIndex], serializer, pageStrokes)) {
            continue;
        }

        const size_t affectedStrokeOffset = combinedStrokes.size();
        const float yOffset = static_cast<float>(pageIndex) * pageHeight;
        for (auto& stroke : pageStrokes) {
            translateStrokeInPlace(stroke, yOffset, affectedStrokeOffset);
            combinedStrokes.push_back(std::move(stroke));
        }
    }

    if (combinedStrokes.empty()) {
        return nullptr;
    }

    std::vector<uint8_t> serialized = serializer.serialize(combinedStrokes);
    if (serialized.empty()) {
        return nullptr;
    }

    *outSize = static_cast<int>(serialized.size());
    uint8_t* buffer = new uint8_t[serialized.size()];
    std::memcpy(buffer, serialized.data(), serialized.size());
    return buffer;
}

int decomposeContinuousWindow(
    const uint8_t* windowData,
    int windowDataSize,
    int pageCount,
    float pageHeight,
    uint8_t** outPageDataPtrs,
    int* outPageDataSizes
) {
    if (!outPageDataPtrs || !outPageDataSizes || pageCount <= 0 || pageHeight <= 0.0f) {
        return 0;
    }

    for (int pageIndex = 0; pageIndex < pageCount; ++pageIndex) {
        outPageDataPtrs[pageIndex] = nullptr;
        outPageDataSizes[pageIndex] = 0;
    }

    if (!windowData || windowDataSize <= 0) {
        return pageCount;
    }

    DrawingSerialization serializer;
    std::vector<Stroke> combinedStrokes;
    if (!deserializeDrawingBytes(windowData, windowDataSize, serializer, combinedStrokes)) {
        return 0;
    }

    std::vector<std::vector<Stroke>> pageStrokes(static_cast<size_t>(pageCount));
    std::vector<std::unordered_map<int, std::vector<size_t>>> outputIndexMap(combinedStrokes.size());

    for (size_t originalStrokeIndex = 0; originalStrokeIndex < combinedStrokes.size(); ++originalStrokeIndex) {
        const Stroke& originalStroke = combinedStrokes[originalStrokeIndex];
        std::vector<PageStrokeSegment> segments = splitStrokeAcrossPages(originalStroke, pageCount, pageHeight);
        for (const auto& segment : segments) {
            Stroke pageLocalStroke = makePageLocalStroke(originalStroke, segment, pageHeight);
            pageStrokes[segment.pageIndex].push_back(std::move(pageLocalStroke));
            outputIndexMap[originalStrokeIndex][segment.pageIndex].push_back(
                pageStrokes[segment.pageIndex].size() - 1
            );
        }
    }

    for (size_t originalStrokeIndex = 0; originalStrokeIndex < combinedStrokes.size(); ++originalStrokeIndex) {
        const Stroke& originalStroke = combinedStrokes[originalStrokeIndex];
        if (!originalStroke.isEraser) {
            continue;
        }

        for (const auto& pageEntry : outputIndexMap[originalStrokeIndex]) {
            const int pageIndex = pageEntry.first;
            const std::vector<size_t>& eraserSegmentIndices = pageEntry.second;
            std::unordered_set<size_t> remappedAffectedIndices;
            for (size_t affectedOriginalIndex : originalStroke.affectedStrokeIndices) {
                if (affectedOriginalIndex >= outputIndexMap.size()) {
                    continue;
                }

                const auto affectedSegmentsIt = outputIndexMap[affectedOriginalIndex].find(pageIndex);
                if (affectedSegmentsIt == outputIndexMap[affectedOriginalIndex].end()) {
                    continue;
                }

                remappedAffectedIndices.insert(
                    affectedSegmentsIt->second.begin(),
                    affectedSegmentsIt->second.end()
                );
            }

            for (size_t eraserSegmentIndex : eraserSegmentIndices) {
                if (eraserSegmentIndex < pageStrokes[pageIndex].size()) {
                    pageStrokes[pageIndex][eraserSegmentIndex].affectedStrokeIndices = remappedAffectedIndices;
                }
            }
        }
    }

    for (int pageIndex = 0; pageIndex < pageCount; ++pageIndex) {
        if (pageStrokes[pageIndex].empty()) {
            continue;
        }

        std::vector<uint8_t> serialized = serializer.serialize(pageStrokes[pageIndex]);
        if (serialized.empty()) {
            continue;
        }

        outPageDataSizes[pageIndex] = static_cast<int>(serialized.size());
        uint8_t* buffer = new uint8_t[serialized.size()];
        std::memcpy(buffer, serialized.data(), serialized.size());
        outPageDataPtrs[pageIndex] = buffer;
    }

    return pageCount;
}

void* makeSnapshot(void* engine) {
    if (!engine) {
        return nullptr;
    }

    sk_sp<SkImage> image = static_cast<SkiaDrawingEngine*>(engine)->makeSnapshot();
    if (image) {
        image->ref(); // Increment ref count for Swift ownership
        return image.get();
    }
    return nullptr;
}

void releaseSkImage(void* image) {
    if (image) {
        static_cast<SkImage*>(image)->unref();
    }
}

// Batch export multiple pages to PNG
// pagesDataPtrs: array of pointers to serialized drawing data
// pagesDataSizes: array of sizes for each data buffer
// backgroundTypes: array of background type strings (e.g., "plain", "lined", "pdf")
// pdfPixelDataPtrs: array of pointers to RGBA pixel data for PDF backgrounds (can be null)
// pdfPixelDataWidths: array of PDF image widths (0 if no PDF for that page)
// pdfPixelDataHeights: array of PDF image heights (0 if no PDF for that page)
// numPages: number of pages
// width, height: canvas dimensions
// scale: export scale factor
// outResults: array to receive base64 PNG strings (caller allocates numPages pointers)
// outResultLengths: array to receive lengths of each result string
// Returns number of successfully exported pages
int batchExportPages(
    const uint8_t** pagesDataPtrs,
    const int* pagesDataSizes,
    const char** backgroundTypes,
    const uint8_t** pdfPixelDataPtrs,
    const int* pdfPixelDataWidths,
    const int* pdfPixelDataHeights,
    const int* pageIndices,
    int numPages,
    int width,
    int height,
    float scale,
    char** outResults,
    int* outResultLengths
) {
    if (!pagesDataPtrs || !pagesDataSizes || !backgroundTypes ||
        !outResults || !outResultLengths || numPages <= 0) {
        return 0;
    }

    // Create a temporary engine for batch processing
    SkiaDrawingEngine* engine = new SkiaDrawingEngine(width, height);

    // Prepare page data and background type vectors
    std::vector<std::vector<uint8_t>> pagesData;
    std::vector<std::string> bgTypes;
    std::vector<sk_sp<SkImage>> pdfBackgrounds;
    std::vector<int> resolvedPageIndices;
    pagesData.reserve(numPages);
    bgTypes.reserve(numPages);
    pdfBackgrounds.reserve(numPages);
    resolvedPageIndices.reserve(numPages);

    for (int i = 0; i < numPages; ++i) {
        if (pagesDataPtrs[i] && pagesDataSizes[i] > 0) {
            pagesData.push_back(std::vector<uint8_t>(
                pagesDataPtrs[i],
                pagesDataPtrs[i] + pagesDataSizes[i]
            ));
        } else {
            pagesData.push_back(std::vector<uint8_t>());
        }

        bgTypes.push_back(backgroundTypes[i] ? backgroundTypes[i] : "plain");
        resolvedPageIndices.push_back(pageIndices ? pageIndices[i] : i);

        // Create SkImage from PDF pixel data if provided
        if (pdfPixelDataPtrs && pdfPixelDataPtrs[i] &&
            pdfPixelDataWidths && pdfPixelDataHeights &&
            pdfPixelDataWidths[i] > 0 && pdfPixelDataHeights[i] > 0) {
            int pdfWidth = pdfPixelDataWidths[i];
            int pdfHeight = pdfPixelDataHeights[i];
            size_t rowBytes = pdfWidth * 4; // RGBA

            // Create SkImageInfo for the pixel data
            SkImageInfo info = SkImageInfo::Make(
                pdfWidth, pdfHeight,
                kRGBA_8888_SkColorType,
                kPremul_SkAlphaType
            );

            // Make a copy of the pixel data since SkImage needs to own it
            size_t dataSize = rowBytes * pdfHeight;
            sk_sp<SkData> pixelData = SkData::MakeWithCopy(pdfPixelDataPtrs[i], dataSize);

            // Create SkImage from the pixel data
            sk_sp<SkImage> pdfImage = SkImages::RasterFromData(info, pixelData, rowBytes);
            pdfBackgrounds.push_back(pdfImage);
        } else {
            pdfBackgrounds.push_back(nullptr);
        }
    }

    // Call batch export with PDF backgrounds
    std::vector<std::string> results = engine->batchExportPages(
        pagesData,
        bgTypes,
        pdfBackgrounds,
        resolvedPageIndices,
        scale
    );

    // Copy results to output arrays
    int successCount = 0;
    for (int i = 0; i < numPages && i < (int)results.size(); ++i) {
        if (!results[i].empty()) {
            outResultLengths[i] = static_cast<int>(results[i].size());
            outResults[i] = new char[results[i].size() + 1];
            std::memcpy(outResults[i], results[i].c_str(), results[i].size() + 1);
            successCount++;
        } else {
            outResults[i] = nullptr;
            outResultLengths[i] = 0;
        }
    }

    delete engine;
    return successCount;
}

// Free a batch export result string
void freeBatchExportResult(char* result) {
    if (result) {
        delete[] result;
    }
}

} // extern "C"
