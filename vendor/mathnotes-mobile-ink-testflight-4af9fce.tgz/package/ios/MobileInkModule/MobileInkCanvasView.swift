import UIKit
import MetalKit
import React

enum PencilStrokeInputNormalizer {
  static let perpendicularAltitude = Float.pi / 2
  private static let minimumPencilPressure: Float = 0.015
  private static let pencilPressureExponent: Float = 0.88

  static func isPencil(_ touch: UITouch) -> Bool {
    touch.type == .pencil
  }

  static func normalizePressure(rawNormalizedPressure: Float, isPencil: Bool) -> Float {
    if isPencil {
      let clamped = max(0.0, min(1.0, rawNormalizedPressure.isFinite ? rawNormalizedPressure : 1.0))
      return max(minimumPencilPressure, powf(clamped, pencilPressureExponent))
    }

    return max(0.1, rawNormalizedPressure)
  }

  static func normalizeAltitude(_ rawAltitude: Float, isPencil: Bool) -> Float {
    guard isPencil else {
      return perpendicularAltitude
    }

    return max(0.0, min(perpendicularAltitude, rawAltitude))
  }

  static func normalizedPressure(for touch: UITouch) -> Float {
    let maxForce = touch.maximumPossibleForce
    let rawNormalizedPressure: Float
    if maxForce > 0 {
      rawNormalizedPressure = Float(touch.force / maxForce)
    } else {
      rawNormalizedPressure = 1.0
    }

    return normalizePressure(rawNormalizedPressure: rawNormalizedPressure, isPencil: isPencil(touch))
  }

  static func azimuthAndAltitude(for touch: UITouch, in view: UIView) -> (azimuth: Float, altitude: Float) {
    guard isPencil(touch) else {
      return (0.0, perpendicularAltitude)
    }

    let altitude = normalizeAltitude(Float(touch.altitudeAngle), isPencil: true)
    let azimuthAngle = Float(touch.azimuthAngle(in: view))
    return (azimuthAngle, altitude)
  }
}

// MARK: - MobileInkCanvasView

private final class ImageLayerWorkToken {
    private let lock = NSLock()
    private var cancelled = false
    func cancel() { lock.lock(); cancelled = true; lock.unlock() }
    var isCancelled: Bool { lock.lock(); defer { lock.unlock() }; return cancelled }
}

private final class ImageAnimationTarget: NSObject {
    weak var view: MobileInkCanvasView?
    @objc func tick(_ link: CADisplayLink) { view?.advanceAnimatedImageLayers(at: link.timestamp) }
}

@objc(MobileInkCanvasView)
class MobileInkCanvasView: MTKView {
    private static let warmCrayonTextureCache: Void = {
        DispatchQueue.global(qos: .utility).async { warmCrayonTextures() }
    }()
    private static let imageLayerQueue = DispatchQueue(label: "MobileInk.imageLayers", qos: .userInitiated)
    private static let eraserMaskQueue = DispatchQueue(label: "MobileInk.eraserMasks", qos: .utility)
    private static let imageCacheMemoryObserver = NotificationCenter.default.addObserver(
        forName: UIApplication.didReceiveMemoryWarningNotification, object: nil, queue: nil
    ) { _ in clearDocumentImageCache(); clearEraserMaskCache() }
    var drawingEngine: OpaquePointer?
    private var imageLayerRevision: UInt64 = 0
    private var imageLayerWork: ImageLayerWorkToken?
    private var pendingImageLayers: UnsafeMutableRawPointer?
    private var pendingImageLayersJSON: String?
    private var imageAnimationLink: CADisplayLink?
    private var imageAnimationTarget: ImageAnimationTarget?
    private var imageFrameUpdatePending = false
    private var eraserMaskRevision: UInt64 = 0
    private var eraserMaskInFlight = false
    private var eraserMaskRestart = false
    private var eraserMaskScheduled: DispatchWorkItem?
    @objc var onImageLayersError: RCTDirectEventBlock?
    @objc var onImageLayersReady: RCTDirectEventBlock?
    @objc var documentImageLayersJSON: String? {
        didSet {
            guard oldValue != documentImageLayersJSON, !isReleased else { return }
            scheduleImageLayersPreparation(documentImageLayersJSON ?? "[]")
        }
    }

    private func scheduleImageLayersPreparation(_ json: String) {
        imageLayerWork?.cancel()
        let work = ImageLayerWorkToken()
        imageLayerWork = work
        imageLayerRevision &+= 1
        let revision = imageLayerRevision
        let scale = Double(baseContentScale())
        Self.imageLayerQueue.async { [weak self] in
            guard !work.isCancelled else { return }
            let prepared = json.withCString { prepareDocumentImageLayers($0, scale) }
            DispatchQueue.main.async { [weak self] in
                guard let self, !self.isReleased, self.imageLayerRevision == revision else {
                    if let prepared { releaseDocumentImageLayers(prepared) }
                    return
                }
                guard let prepared else {
                    self.onImageLayersError?(["message": "Unable to load an inserted image"])
                    return
                }
                if let pending = self.pendingImageLayers { releaseDocumentImageLayers(pending) }
                self.pendingImageLayers = prepared
                self.pendingImageLayersJSON = json
                self.installPendingImageLayers()
            }
        }
    }

    // Optimize copies away from the input/render thread. Each result is
    // validated against current stroke geometry before it can be installed.
    private func scheduleEraserMaskOptimization() {
        eraserMaskRevision &+= 1
        let revision = eraserMaskRevision
        eraserMaskScheduled?.cancel()
        let work = DispatchWorkItem { [weak self] in self?.startEraserMaskOptimization(revision) }
        eraserMaskScheduled = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.75, execute: work)
    }

    private func startEraserMaskOptimization(_ revision: UInt64) {
        guard !isReleased, revision == eraserMaskRevision else { return }
        if eraserMaskInFlight { eraserMaskRestart = true; return }
        guard let engine = drawingEngine, let snapshot = snapshotEraserMasks(engine) else { return }
        eraserMaskInFlight = true
        advanceEraserMaskOptimization(snapshot, revision: revision)
    }

    private func advanceEraserMaskOptimization(_ snapshot: UnsafeMutableRawPointer, revision: UInt64) {
        Self.eraserMaskQueue.async { [weak self] in
            let result = optimizeNextEraserMask(snapshot)
            DispatchQueue.main.async { [weak self] in
                guard let self else { releaseEraserMaskSnapshot(snapshot); return }
                guard !self.isReleased, revision == self.eraserMaskRevision,
                      let engine = self.drawingEngine, result != 0 else {
                    releaseEraserMaskSnapshot(snapshot)
                    self.eraserMaskInFlight = false
                    if !self.isReleased && self.eraserMaskRestart {
                        self.eraserMaskRestart = false
                        self.startEraserMaskOptimization(self.eraserMaskRevision)
                    }
                    return
                }
                if result == 1 { installOptimizedEraserMask(engine, snapshot) }
                self.advanceEraserMaskOptimization(snapshot, revision: revision)
            }
        }
    }

    private func installPendingImageLayers() {
        guard let engine = drawingEngine, let prepared = pendingImageLayers else { return }
        pendingImageLayers = nil
        let animated = documentImageLayersAreAnimated(prepared)
        installDocumentImageLayers(engine, prepared)
        releaseDocumentImageLayers(prepared)
        updateImageAnimationLink(animated)
        requestDisplay(forceWhenSuspended: true)
        if let json = pendingImageLayersJSON { onImageLayersReady?(["json": json]) }
        pendingImageLayersJSON = nil
    }

    private func updateImageAnimationLink(_ enabled: Bool) {
        if !enabled || isReleased {
            imageAnimationLink?.invalidate()
            imageAnimationLink = nil
            imageAnimationTarget = nil
        } else if imageAnimationLink == nil {
            let target = ImageAnimationTarget()
            target.view = self
            let link = CADisplayLink(target: target, selector: #selector(ImageAnimationTarget.tick(_:)))
            link.preferredFramesPerSecond = 60
            link.add(to: .main, forMode: .common)
            imageAnimationTarget = target
            imageAnimationLink = link
        }
    }

    fileprivate func advanceAnimatedImageLayers(at time: CFTimeInterval) {
        guard !isReleased, window != nil, UIApplication.shared.applicationState == .active,
              !imageFrameUpdatePending, let engine = drawingEngine,
              let snapshot = snapshotDocumentImageLayers(engine) else { return }
        imageFrameUpdatePending = true
        let revision = imageLayerRevision
        Self.imageLayerQueue.async { [weak self] in
            let result = advanceDocumentImageLayers(snapshot, time)
            DispatchQueue.main.async { [weak self] in
                defer { releaseDocumentImageLayers(snapshot) }
                guard let self else { return }
                self.imageFrameUpdatePending = false
                guard !self.isReleased, revision == self.imageLayerRevision, let engine = self.drawingEngine else { return }
                if result < 0 {
                    self.updateImageAnimationLink(false)
                    self.onImageLayersError?(["message": "Unable to decode an animated image frame"])
                } else if result > 0 {
                    installAnimatedDocumentImageLayers(engine, snapshot)
                    self.requestDisplay(forceWhenSuspended: true)
                }
            }
        }
    }
    private var commandQueue: MTLCommandQueue?
    private var ganeshMetalContext: OpaquePointer?
    private var ganeshPreparationAttempted = false
    private var ganeshPreparationPending = false
    private var ganeshFrameFailed = false
    private var ganeshPreparationRequest: MobileInkGaneshPreparation.Request?
    private var hasPresentedFrame = false
    private let frameAcquisition = MobileInkFrameAcquisition<CAMetalDrawable>()
    private var hasPendingFrame = false
    private var isFrameScheduled = false
    private var pendingFrameRequestedAt: CFTimeInterval?
    var requestedRenderBackend: MobileInkRenderBackend = .ganesh
    var darkDisplay = false {
        didSet { if oldValue != darkDisplay { requestDisplay() } }
    }
    let benchmarkRecorder: MobileInkBenchmarkRecorder
    private let interactionAudit: MobileInkInteractionAudit?
    var isBenchmarkReplayRunning = false
    var benchmarkRunToken = UUID()
    private var useExperimentalGaneshBackend: Bool {
        requestedRenderBackend == .ganesh && !ganeshFrameFailed
    }
    var scaleX: CGFloat = 1.0
    var scaleY: CGFloat = 1.0
  private var pixelBuffer: UnsafeMutablePointer<UInt8>?
  private var pixelBufferLength: Int = 0
    private var pixelBytesPerRow: Int = 0
  var pixelWidth: Int32 = 0
  var pixelHeight: Int32 = 0
    private var enginePixelWidth: Int32 = 0
    private var enginePixelHeight: Int32 = 0
    private var isApplyingDrawableSize = false
    private var clampedRenderScale: CGFloat {
        let requested = max(0.25, min(5.0, renderScale.isFinite ? renderScale : 1.0))
        return [CGFloat(0.25), 0.5, 0.75, 1, 1.5, 2, 2.5, 3, 4, 5].min { abs($0 - requested) < abs($1 - requested) } ?? 1
    }

    private var documentSize: CGSize = .zero
    private var targetRenderFrame: CGRect = .zero
    private var targetRenderScale: CGFloat = 0
    private var renderGeometryRevision: UInt64 = 0
    private var renderGeometryUpdatePending = false
    private var usesCroppedViewport: Bool { continuousDocument || abs(clampedRenderScale - 1) > 0.01 }

    func updateDocumentLayout(_ size: CGSize) {
        let scale = baseContentScale()
        guard size.width.isFinite, size.height.isFinite, size.width > 0, size.height > 0,
              size.width * scale <= CGFloat(Int32.max), size.height * scale <= CGFloat(Int32.max) else { return }
        documentSize = size
        scheduleRenderGeometryUpdate()
    }

    private func scheduleRenderGeometryUpdate() {
        guard !renderGeometryUpdatePending else { return }
        renderGeometryUpdatePending = true
        // React delivers scale and viewport props separately. Apply their final
        // values together, avoiding a transient full-page high-resolution allocation.
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            self.renderGeometryUpdatePending = false
            guard !self.isReleased, self.documentSize.width > 0, self.documentSize.height > 0 else { return }
            let full = CGRect(origin: .zero, size: self.documentSize)
            var target = full
            if self.usesCroppedViewport {
                let left = max(0, min(1, self.renderViewportLeftRatio))
                let top = max(0, min(1, self.renderViewportTopRatio))
                let width = max(0.001, min(1 - left, self.renderViewportWidthRatio))
                let height = max(0.001, min(1 - top, self.renderViewportHeightRatio))
                target = CGRect(x: left * full.width, y: top * full.height,
                                width: width * full.width, height: height * full.height)
            }
            if self.continuousDocument {
                // Initial prop delivery must never allocate a document-sized
                // drawable even before the viewport ratios arrive.
                let maxSide = 4096 / (self.baseContentScale() * self.clampedRenderScale)
                target.size.width = min(target.width, maxSide)
                target.size.height = min(target.height, maxSide)
            }
            if self.targetRenderFrame != target || self.targetRenderScale != self.clampedRenderScale {
                self.targetRenderFrame = target
                self.targetRenderScale = self.clampedRenderScale
                self.renderGeometryRevision &+= 1
            }
            // Keep the previously presented ink aligned with its old crop
            // until the new crop is rendered and can be swapped atomically.
            if !self.continuousDocument || !self.hasPresentedFrame { self.frame = target }
            self.applyDrawableContentScale(updateDrawableSize: true, targetSize: target.size)
            self.syncContinuousEngineDocumentSize()
            self.applyRenderViewportToEngine()
            self.updateSelectionToolbarFrame()
            self.requestDisplay(forceWhenSuspended: true)
        }
    }

    // A growing document can keep exactly the same cropped drawable size.
    // In that case MTKView does not call drawableSizeWillChange, so update
    // the logical engine extent directly from the host document layout.
    private func syncContinuousEngineDocumentSize() {
        guard continuousDocument, let engine = drawingEngine,
              documentSize.width > 0, documentSize.height > 0 else { return }
        let scale = baseContentScale()
        let width = Int32(max(1, round(documentSize.width * scale)))
        let height = Int32(max(1, round(documentSize.height * scale)))
        guard width != enginePixelWidth || height != enginePixelHeight else { return }
        if resizeContinuousDrawingEngine(engine, width, height) {
            enginePixelWidth = width
            enginePixelHeight = height
        }
    }

    // Store pending tool settings to apply when engine is ready
    private var pendingTool: String = "pen"
    private var activeStrokeTool: String?
    var holdToShapeEnabled = true {
        didSet {
            if !holdToShapeEnabled { cancelHoldToShapePreview() }
            if let engine = drawingEngine { setHoldToShapeEnabled(engine, holdToShapeEnabled); requestDisplay() }
        }
    }
    private var pendingViewportQualityRefresh: DispatchWorkItem?
    var viewportMotionActive = false {
        didSet {
            guard oldValue != viewportMotionActive else { return }
            pendingViewportQualityRefresh?.cancel()
            pendingViewportQualityRefresh = nil
            if viewportMotionActive {
                if let engine = drawingEngine { setViewportMotionActive(engine, true) }
            } else {
                // Rapid consecutive pinches should not rebuild high-resolution
                // tiles between gestures. Sharpen once the viewport stays idle.
                let refresh = DispatchWorkItem { [weak self] in
                    guard let self, !self.isReleased, !self.viewportMotionActive,
                          let engine = self.drawingEngine else { return }
                    setViewportMotionActive(engine, false)
                    self.requestDisplay(forceWhenSuspended: true)
                }
                pendingViewportQualityRefresh = refresh
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.25, execute: refresh)
            }
        }
    }
    private var pendingWidth: Float = 3.0
    private var pendingColor: UInt32 = 0xFF000000  // Black
    private var pendingEraserMode: String = "pixel"
    private var pendingBackgroundType: String = "plain"  // For PDF transparency
    private let holdToShapeDelay: TimeInterval = 0.30
    private let holdToShapeRetryDelay: TimeInterval = 0.06
    private var holdToShapeTimer: Timer?
    var isHoldToShapeStrokeActive = false

    // Eraser cursor
    private var eraserCursorLayer: CAShapeLayer?
    private var currentTouchLocation: CGPoint?

    // Selection state
    private var isSelectionMode: Bool = false
    private var isDraggingSelection: Bool = false
    private var isMovingSelection: Bool = false
    private var isTransformingSelection: Bool = false
    private var selectionTransformHandleIndex: Int32 = -1
    private var hasSelectionMoveDelta: Bool = false
    private var lastDragPoint: CGPoint?
    private let selectionToolbar = UIStackView()
    private let selectionToolbarHeight: CGFloat = 44
    private let selectionToolbarButtonWidth: CGFloat = 48
    private let selectionToolbarMargin: CGFloat = 8

    // Text mode state
    private var isTextMode: Bool = false

    // Drawing policy: "default", "anyinput", or "pencilonly"
    // When "pencilonly", only Apple Pencil touches are processed for drawing
    @objc var drawingPolicy: String = "default"
    @objc var renderBackend: String = MobileInkRenderBackend.ganesh.rawValue {
        didSet {
            guard !isReleased else { return }
            let normalizedBackend = MobileInkRenderBackend(rawValue: renderBackend.lowercased()) ?? .ganesh
            requestedRenderBackend = normalizedBackend
            benchmarkRecorder.updateRequestedBackend(normalizedBackend.rawValue)
            interactionAudit?.updateRequestedBackend(normalizedBackend.rawValue)
            if normalizedBackend == .ganesh { _ = ensureGaneshMetalContext() }

            if normalizedBackend == .cpu {
                if pixelWidth > 0 && pixelHeight > 0 {
                    allocatePixelBuffer(width: Int(pixelWidth), height: Int(pixelHeight))
                }
            } else {
                pixelBuffer?.deallocate()
                pixelBuffer = nil
                pixelBufferLength = 0
                pixelBytesPerRow = 0
            }

            requestDisplay(forceWhenSuspended: true)
        }
    }
    @objc var renderSuspended: Bool = false {
        didSet {
            if oldValue != renderSuspended && !renderSuspended {
                requestDisplay(forceWhenSuspended: true)
            }
        }
    }
    // Set before loading content; changing rendering mode recreates the engine.
    @objc var continuousDocument: Bool = false {
        didSet {
            guard oldValue != continuousDocument else { return }
            if drawingEngine != nil {
                configureDrawingEngine(width: enginePixelWidth, height: enginePixelHeight,
                                       preserveExistingDrawing: true)
            }
            scheduleRenderGeometryUpdate()
        }
    }

    @objc var renderScale: CGFloat = 1.0 {
        didSet {
            guard oldValue != renderScale else { return }
            scheduleRenderGeometryUpdate()
        }
    }
    @objc var renderViewportLeftRatio: CGFloat = 0.0 {
        didSet {
            guard oldValue != renderViewportLeftRatio else { return }
            scheduleRenderGeometryUpdate()
        }
    }
    @objc var renderViewportTopRatio: CGFloat = 0.0 {
        didSet {
            guard oldValue != renderViewportTopRatio else { return }
            scheduleRenderGeometryUpdate()
        }
    }
    @objc var renderViewportWidthRatio: CGFloat = 1.0 {
        didSet {
            guard oldValue != renderViewportWidthRatio else { return }
            scheduleRenderGeometryUpdate()
        }
    }
    @objc var renderViewportHeightRatio: CGFloat = 1.0 {
        didSet {
            guard oldValue != renderViewportHeightRatio else { return }
            scheduleRenderGeometryUpdate()
        }
    }

    @objc var onDrawingChange: RCTDirectEventBlock?
    @objc var onDrawingBegin: RCTDirectEventBlock?
    @objc var onInkSelectionChange: RCTDirectEventBlock?
    @objc var onPencilDoubleTap: RCTDirectEventBlock?
    private var pencilDoubleTapSequence: Int = 0
    private var pendingPresentedLoadCallbacks: [RCTResponseSenderBlock] = []
    private var hasDeferredPresentation = false
    private var deferredBase64Payload: String?

    // Reference to background view for compositing during export
    weak var backgroundView: MobileInkBackgroundView?

    private func shouldIgnoreTouchForDrawingPolicy(_ touch: UITouch) -> Bool {
        // Selection is deliberately finger-addressable even when drawing
        // is Apple-Pencil-only. Otherwise users can draw with Pencil but
        // are forced to tap selected shapes/strokes with Pencil too.
        drawingPolicy == "pencilonly" && touch.type != .pencil && !isSelectionMode && !isMovingSelection && !isTransformingSelection
    }

    // Page dimensions (like PencilKit's pageWidth/pageHeight)
    // These are calculated from bounds.width to fit the screen
    private var pageWidth: CGFloat = 0
    private var pageHeight: CGFloat = 0

    override init(frame: CGRect, device: MTLDevice?) {
        // Start before Metal/view construction so the audit includes cold-open
        // work, rather than beginning only once the first frame is ready.
        let recorder = MobileInkBenchmarkRecorder()
        self.benchmarkRecorder = recorder
        self.interactionAudit = MobileInkInteractionAudit(recorder: recorder)
        let metalDevice = device ?? MTLCreateSystemDefaultDevice()
        super.init(frame: frame, device: metalDevice)

        _ = Self.warmCrayonTextureCache
        _ = Self.imageCacheMemoryObserver

        self.isOpaque = false // Transparent to show background underneath
        self.backgroundColor = .clear
        self.framebufferOnly = false
        self.enableSetNeedsDisplay = false
        self.isPaused = true
        self.preferredFramesPerSecond = 120

        // Configure pixel format
        self.colorPixelFormat = .bgra8Unorm
        self.clearColor = MTLClearColorMake(0, 0, 0, 0) // Transparent

        self.autoResizeDrawable = false

        // Configure Metal layer for transparency and low latency
        if let metalLayer = self.layer as? CAMetalLayer {
            metalLayer.isOpaque = false // Transparent to composite over background
            metalLayer.pixelFormat = .bgra8Unorm
            metalLayer.framebufferOnly = false
            // Allow 3 drawables for smooth triple-buffering without blocking
            metalLayer.maximumDrawableCount = 3
            // Don't synchronize with Core Animation - present immediately for lowest latency
            metalLayer.presentsWithTransaction = false
        }

        print("🔧 Metal layer configured: isOpaque=\(self.layer.isOpaque), pixelFormat=\(self.colorPixelFormat.rawValue), backgroundColor=\(String(describing: self.backgroundColor))")

        commandQueue = metalDevice?.makeCommandQueue()
        delegate = self

        // Drawing engine will be initialized when we get valid dimensions
        // This is done in mtkView(_:drawableSizeWillChange:)

        // Enable touch handling
        isUserInteractionEnabled = true
        isMultipleTouchEnabled = false

        // Setup eraser cursor
        setupEraserCursor()
        setupSelectionToolbar()

        if #available(iOS 12.1, *) {
            let pencilInteraction = UIPencilInteraction()
            pencilInteraction.delegate = self
            addInteraction(pencilInteraction)
        }
    }

    required init(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    @objc func simulatePencilDoubleTapForTesting() {
        emitPencilDoubleTapEvent()
    }

    /// Set true by releaseHeavyNativeState. Used to short-circuit any
    /// post-release reallocation (mtkView delegate methods can fire
    /// even after we've been removed from the window if the layout
    /// pass is still in flight). Without this guard, allocatePixelBuffer
    /// would re-create the 13 MB buffer right after we just freed it,
    /// effectively undoing the release. Once true, never flips back --
    /// a released view is dead.
    var isReleased: Bool = false

    deinit {
        releaseHeavyNativeState()
    }

    /// Release the multi-MB pixel buffer + the C++ drawing engine + the
    /// background view's PDF page cache + queued JS callbacks. Called
    /// only for final teardown: deinit (ARC released us), didMoveToWindow
    /// when window becomes nil, removeFromSuperview, AND the explicit
    /// JS-bridge call from the fixed engine pool's final unmount.
    /// All four converge here; the function is idempotent (every field
    /// is nil-checked / no-op-on-second-call) so multiple firings are
    /// safe. We need this many entry points because Instruments
    /// confirmed no single hook was reliable on its own -- something
    /// in the RN/MTKView chain retains views past their React unmount
    /// for unpredictable amounts of time.
    func releaseHeavyNativeState() {
        if isReleased { return }
        isReleased = true
        eraserMaskRevision &+= 1
        eraserMaskScheduled?.cancel()
        eraserMaskScheduled = nil
        eraserMaskRestart = false
        updateImageAnimationLink(false)
        imageLayerWork?.cancel()
        imageLayerWork = nil
        imageLayerRevision &+= 1
        if let pending = pendingImageLayers { releaseDocumentImageLayers(pending); pendingImageLayers = nil }
        pendingImageLayersJSON = nil
        frameAcquisition.cancel()
        hasPendingFrame = false
        pendingFrameRequestedAt = nil
        ganeshPreparationRequest?.cancel()
        ganeshPreparationRequest = nil
        if let audit = interactionAudit {
            if Thread.isMainThread { audit.dispose() }
            else { DispatchQueue.main.async { audit.dispose() } }
        }

        benchmarkRunToken = UUID()
        isBenchmarkReplayRunning = false
        holdToShapeTimer?.invalidate()
        holdToShapeTimer = nil
        pixelBuffer?.deallocate()
        pixelBuffer = nil
        pixelBufferLength = 0
        pixelBytesPerRow = 0
        if let engine = drawingEngine {
            destroyDrawingEngine(engine)
            drawingEngine = nil
        }
        if let context = ganeshMetalContext {
            ganeshMetalContext = nil
            MobileInkGaneshPreparation.discard(context)
        }
        // Settle loads waiting for a frame, including background preparation.
        // Dropping the native block alone leaves its JavaScript promise pending.
        let cancelledLoads = pendingPresentedLoadCallbacks
        pendingPresentedLoadCallbacks.removeAll()
        cancelledLoads.forEach { $0(["Canvas released before load presentation", NSNull()]) }
        deferredBase64Payload = nil
        hasDeferredPresentation = false
        onDrawingChange = nil
        onDrawingBegin = nil
        onInkSelectionChange = nil
        onPencilDoubleTap = nil
        delegate = nil
        commandQueue = nil
        isUserInteractionEnabled = false
        eraserCursorLayer?.removeFromSuperlayer()
        eraserCursorLayer = nil
        selectionToolbar.isHidden = true
        selectionToolbar.removeFromSuperview()
        currentTouchLocation = nil
        isTransformingSelection = false
        selectionTransformHandleIndex = -1
        hasSelectionMoveDelta = false
        lastDragPoint = nil
        // The background view holds a PDFKit document + a page cache
        // (up to 3 rendered CGPDFPage at ~10 MB each). When THIS view
        // gets stuck in the retain-cycle limbo, its sibling
        // backgroundView is dragged along with it via RN's container
        // hierarchy, so the cache outlives its usefulness too. Tell
        // it to drop everything now.
        backgroundView?.unloadPDF()
    }

    override func removeFromSuperview() {
        // Defer release because UIKit fires removeFromSuperview during
        // sibling reordering and layout passes too -- NOT only on
        // permanent teardown. Releasing immediately killed live slots
        // that were briefly detached, leaving broken-but-retained
        // views in retain-cycle limbo while React mounted fresh
        // replacements (Instruments showed 13.28 MiB persistent jump
        // 10 -> 18, doubling the per-mount leak rate). The 300ms
        // defer + superview-still-nil check filters out transient
        // detaches: if we got re-added quickly, we don't release.
        super.removeFromSuperview()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { [weak self] in
            guard let self = self, self.superview == nil, self.window == nil else { return }
            self.releaseHeavyNativeState()
        }
    }

    override func didMoveToWindow() {
        super.didMoveToWindow()
        // window == nil means we've been removed from any window. React
        // unmount funnels through here. Eagerly release the heavy native
        // state -- per-view this is ~13 MB pixel buffer + multi-MB
        // engine state (strokes + 20 history snapshots). Across ~14
        // leaked views that's >250 MB just on pixel buffers, plus the
        // ~500 MB of raster data the engine accumulates -- which is
        // exactly what the user was seeing in the Allocations Instrument.
        //
        // 200 ms defer filters out transient window detachments
        // (rotation, modal presentation, brief layout passes). If the
        // view re-attaches before the timer fires, the closure's
        // self.window check returns false and no release happens. RN's
        // unmount path leaves the view detached permanently, so the
        // closure fires on the leaked view and we reclaim the heavy
        // memory regardless of whether ARC ever releases the Swift
        // object itself.
        if window == nil {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) { [weak self] in
                guard let self = self, self.window == nil else { return }
                self.releaseHeavyNativeState()
            }
        } else if hasPendingFrame {
            requestDisplay(forceWhenSuspended: true)
        }
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        // Let the coalesced geometry update crop the frame before resizing
        // its drawable. A layout between React prop setters must not allocate
        // a temporary full-page texture at the new zoom level.
        scheduleRenderGeometryUpdate()
    }

    private func baseContentScale() -> CGFloat {
        window?.screen.scale ?? UIScreen.main.scale
    }

    private func applyDrawableContentScale(updateDrawableSize: Bool, targetSize: CGSize? = nil) {
        let targetScale = baseContentScale() * clampedRenderScale
        if abs(contentScaleFactor - targetScale) > 0.001 {
            contentScaleFactor = targetScale
        }
        if abs(layer.contentsScale - targetScale) > 0.001 {
            layer.contentsScale = targetScale
        }
        let size = targetSize ?? bounds.size
        guard updateDrawableSize, !isApplyingDrawableSize, size.width > 0, size.height > 0 else {
            return
        }

        let targetDrawableSize = CGSize(
            width: max(1.0, round(size.width * targetScale)),
            height: max(1.0, round(size.height * targetScale))
        )
        if abs(drawableSize.width - targetDrawableSize.width) > 0.5 ||
            abs(drawableSize.height - targetDrawableSize.height) > 0.5 {
            isApplyingDrawableSize = true
            defer { isApplyingDrawableSize = false }
            drawableSize = targetDrawableSize
        }
    }

    private func applyRenderViewportToEngine() {
        guard let engine = drawingEngine, enginePixelWidth > 0, enginePixelHeight > 0 else {
            return
        }

        let actualRenderScale = clampedRenderScale
        let left = max(0.0, min(1.0, renderViewportLeftRatio)) * CGFloat(enginePixelWidth)
        let top = max(0.0, min(1.0, renderViewportTopRatio)) * CGFloat(enginePixelHeight)
        let widthRatio = max(0.001, min(1.0, renderViewportWidthRatio))
        let heightRatio = max(0.001, min(1.0, renderViewportHeightRatio))
        let width = min(CGFloat(enginePixelWidth) - left, widthRatio * CGFloat(enginePixelWidth))
        let height = min(CGFloat(enginePixelHeight) - top, heightRatio * CGFloat(enginePixelHeight))

        let renderFrame = continuousDocument && !targetRenderFrame.isEmpty ? targetRenderFrame : frame
        setRenderViewport(
            engine,
            Float(actualRenderScale),
            Float(continuousDocument ? renderFrame.minX * baseContentScale() : left),
            Float(continuousDocument ? renderFrame.minY * baseContentScale() : top),
            Float(max(1.0, continuousDocument ? renderFrame.width * baseContentScale() : width)),
            Float(max(1.0, continuousDocument ? renderFrame.height * baseContentScale() : height))
        )
    }

    func requestDisplay(forceWhenSuspended: Bool = false) {
        guard !isReleased else { return }
        if renderSuspended && !forceWhenSuspended {
            return
        }
        hasPendingFrame = true

        // Acquisition is asynchronous, so own the on-demand frame loop rather
        // than returning from an MTKView display callback before submission.
        // Coalesce updates in this UI transaction without adding a display-cycle
        // wait. The acquisition gate serializes encoding; Metal owns submitted frames.
        // Paper/PDF invalidation remains owned by the separate background view.
        guard !isFrameScheduled else { return }
        isFrameScheduled = true
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            self.isFrameScheduled = false
            guard self.hasPendingFrame else { return }
            self.draw(in: self)
        }
    }

    private func setupSelectionToolbar() {
        selectionToolbar.axis = .horizontal
        selectionToolbar.alignment = .fill
        selectionToolbar.distribution = .fill
        selectionToolbar.spacing = 0
        selectionToolbar.isHidden = true
        selectionToolbar.isUserInteractionEnabled = true
        selectionToolbar.backgroundColor = UIColor.white.withAlphaComponent(0.96)
        selectionToolbar.layer.cornerRadius = 10
        selectionToolbar.layer.masksToBounds = false
        selectionToolbar.layer.shadowColor = UIColor.black.cgColor
        selectionToolbar.layer.shadowOpacity = 0.18
        selectionToolbar.layer.shadowRadius = 10
        selectionToolbar.layer.shadowOffset = CGSize(width: 0, height: 3)

        selectionToolbar.addArrangedSubview(
            makeSelectionToolbarButton(
                systemName: "doc.on.doc",
                fallbackTitle: "Copy",
                tintColor: UIColor(red: 0.22, green: 0.30, blue: 0.40, alpha: 1),
                action: #selector(handleNativeSelectionCopy)
            )
        )
        addSelectionToolbarDivider()
        selectionToolbar.addArrangedSubview(
            makeSelectionToolbarButton(
                systemName: "doc.on.clipboard",
                fallbackTitle: "Paste",
                tintColor: UIColor(red: 0.22, green: 0.30, blue: 0.40, alpha: 1),
                action: #selector(handleNativeSelectionPaste)
            )
        )
        addSelectionToolbarDivider()
        selectionToolbar.addArrangedSubview(
            makeSelectionToolbarButton(
                systemName: "trash",
                fallbackTitle: "Delete",
                tintColor: UIColor(red: 1.0, green: 0.23, blue: 0.19, alpha: 1),
                action: #selector(handleNativeSelectionDelete)
            )
        )

        addSubview(selectionToolbar)
    }

    private func makeSelectionToolbarButton(
        systemName: String,
        fallbackTitle: String,
        tintColor: UIColor,
        action: Selector
    ) -> UIButton {
        let button = UIButton(type: .system)
        button.tintColor = tintColor
        button.backgroundColor = .clear
        button.adjustsImageWhenHighlighted = true
        button.accessibilityLabel = fallbackTitle
        button.widthAnchor.constraint(equalToConstant: selectionToolbarButtonWidth).isActive = true
        button.heightAnchor.constraint(equalToConstant: selectionToolbarHeight).isActive = true

        if let image = UIImage(systemName: systemName) {
            button.setImage(image, for: .normal)
        } else {
            button.setTitle(fallbackTitle, for: .normal)
            button.titleLabel?.font = UIFont.systemFont(ofSize: 12, weight: .semibold)
        }

        button.addTarget(self, action: action, for: .touchUpInside)
        return button
    }

    private func addSelectionToolbarDivider() {
        let divider = UIView()
        divider.backgroundColor = UIColor(white: 0.88, alpha: 1)
        divider.widthAnchor.constraint(equalToConstant: 1.0 / max(1.0, UIScreen.main.scale)).isActive = true
        selectionToolbar.addArrangedSubview(divider)
    }

    private func selectionBoundsInView(engine: OpaquePointer) -> CGRect? {
        guard getSelectionCount(engine) > 0 else {
            return nil
        }

        var bounds: [Float] = [0, 0, 0, 0]
        getSelectionBounds(engine, &bounds)
        let rect = CGRect(
            x: CGFloat(bounds[0]) / scaleX - frame.minX,
            y: CGFloat(bounds[1]) / scaleY - frame.minY,
            width: CGFloat(bounds[2] - bounds[0]) / scaleX,
            height: CGFloat(bounds[3] - bounds[1]) / scaleY
        )

        // CGRect.width reports the standardized (absolute) width, so a rect
        // built from inverted or overflowing bounds can pass a `> 0` check
        // while its origin and midpoints are infinite or NaN. Setting such a
        // frame raises CALayerInvalidGeometry and terminates the app.
        guard rect.width > 0, rect.height > 0,
              rect.minX.isFinite, rect.minY.isFinite,
              rect.maxX.isFinite, rect.maxY.isFinite else {
            return nil
        }

        return rect
    }

    private func updateSelectionToolbarFrame() {
        guard !isReleased, let engine = drawingEngine, let selectionRect = selectionBoundsInView(engine: engine) else {
            selectionToolbar.isHidden = true
            return
        }

        let toolbarWidth = selectionToolbarButtonWidth * 3 + 2.0 / max(1.0, UIScreen.main.scale)
        let minX = selectionToolbarMargin
        let maxX = max(minX, bounds.width - toolbarWidth - selectionToolbarMargin)
        let centeredX = selectionRect.midX - toolbarWidth / 2.0
        let toolbarX = min(max(centeredX, minX), maxX)

        let preferredY = selectionRect.minY - selectionToolbarHeight - 10
        let fallbackY = selectionRect.maxY + 10
        let rawY = preferredY >= selectionToolbarMargin ? preferredY : fallbackY
        let maxY = max(selectionToolbarMargin, bounds.height - selectionToolbarHeight - selectionToolbarMargin)
        let toolbarY = min(max(rawY, selectionToolbarMargin), maxY)

        selectionToolbar.frame = CGRect(
            x: toolbarX,
            y: toolbarY,
            width: toolbarWidth,
            height: selectionToolbarHeight
        )
        selectionToolbar.isHidden = false
        bringSubviewToFront(selectionToolbar)
    }

    @objc private func handleNativeSelectionCopy() {
        performCopy()
        updateSelectionToolbarFrame()
    }

    @objc private func handleNativeSelectionPaste() {
        performPaste()
        updateSelectionToolbarFrame()
    }

    @objc private func handleNativeSelectionDelete() {
        performDelete()
        updateSelectionToolbarFrame()
    }

    private func selectionBoundsContain(_ location: CGPoint, engine: OpaquePointer, padding: CGFloat) -> Bool {
        guard let selectionRect = selectionBoundsInView(engine: engine) else {
            return false
        }
        return selectionRect.insetBy(dx: -padding, dy: -padding).contains(location)
    }

    private func selectionHandleHitTest(_ location: CGPoint, engine: OpaquePointer) -> Int32? {
        guard let selectionRect = selectionBoundsInView(engine: engine) else {
            return nil
        }
        let minX = selectionRect.minX
        let minY = selectionRect.minY
        let maxX = selectionRect.maxX
        let maxY = selectionRect.maxY

        let centerX = (minX + maxX) * 0.5
        let centerY = (minY + maxY) * 0.5
        let handles: [(Int32, CGPoint)] = [
            (0, CGPoint(x: minX, y: minY)),
            (1, CGPoint(x: centerX, y: minY)),
            (2, CGPoint(x: maxX, y: minY)),
            (3, CGPoint(x: minX, y: centerY)),
            (4, CGPoint(x: maxX, y: centerY)),
            (5, CGPoint(x: minX, y: maxY)),
            (6, CGPoint(x: centerX, y: maxY)),
            (7, CGPoint(x: maxX, y: maxY)),
        ]
        let hitRadius: CGFloat = 28
        let hitRadiusSquared = hitRadius * hitRadius

        for (index, point) in handles {
            let dx = location.x - point.x
            let dy = location.y - point.y
            if dx * dx + dy * dy <= hitRadiusSquared {
                return index
            }
        }

        return nil
    }

    private func handleFingerSelectionTouch(
        engine: OpaquePointer,
        location: CGPoint,
        scaledX: Float,
        scaledY: Float
    ) -> Bool {
        guard !isTextMode else {
            return false
        }

        cancelHoldToShapePreview()
        isHoldToShapeStrokeActive = false
        updateEraserCursor(at: nil, width: pendingWidth)

        if let handleIndex = selectionHandleHitTest(location, engine: engine) {
            beginSelectionTransform(engine, handleIndex)
            isTransformingSelection = true
            selectionTransformHandleIndex = handleIndex
            hasSelectionMoveDelta = false
            lastDragPoint = location
            requestDisplay()
            return true
        }

        if selectionBoundsContain(location, engine: engine, padding: 24) {
            isMovingSelection = true
            hasSelectionMoveDelta = false
            lastDragPoint = location
            requestDisplay()
            return true
        }

        let hadSelection = getSelectionCount(engine) > 0
        if hadSelection {
            clearSelection(engine)
        }

        if selectShapeStrokeAt(engine, scaledX, scaledY) {
            isMovingSelection = true
            hasSelectionMoveDelta = false
            lastDragPoint = location
            requestDisplay()
            notifySelectionChange()
            return true
        }

        if hadSelection {
            requestDisplay()
            notifySelectionChange()
            return true
        }

        return false
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let engine = drawingEngine, let touch = touches.first else { return }

        let location = touch.location(in: superview ?? self)
        currentTouchLocation = location
        let scaledX = Float(location.x * scaleX)
        let scaledY = Float(location.y * scaleY)

        if touch.type != .pencil && handleFingerSelectionTouch(engine: engine, location: location, scaledX: scaledX, scaledY: scaledY) {
            return
        }

        // Filter touches based on drawing policy
        // When "pencilonly", only process Apple Pencil touches
        if shouldIgnoreTouchForDrawingPolicy(touch) {
            return
        }

        // Update eraser cursor position
        updateEraserCursor(at: location, width: pendingWidth)

        onDrawingBegin?([
            "x": location.x,
            "y": location.y,
        ])

        // Don't process touches when in text mode
        if isTextMode {
            cancelHoldToShapePreview()
            isHoldToShapeStrokeActive = false
            return
        }

        if isSelectionMode {
            cancelHoldToShapePreview()
            isHoldToShapeStrokeActive = false
            // Check if we're tapping inside an existing selection
            let tappedInsideSelection = selectionBoundsInView(engine: engine)?.contains(location) ?? false

            if tappedInsideSelection {
                // Start moving the existing selection
                isMovingSelection = true
                hasSelectionMoveDelta = false
                lastDragPoint = location
            } else {
                // Clear previous selection and start new selection drag
                clearSelection(engine)

                // Start selection by calling touchBegan (this initiates the selection path)
                let pressure = normalizedPressure(for: touch)
                let (azimuth, altitude) = extractAzimuthAndAltitude(for: touch)
                let isPencilInput = PencilStrokeInputNormalizer.isPencil(touch)
                let timestamp = Int64(touch.timestamp * 1000)  // Convert to milliseconds
                touchBegan(engine, scaledX, scaledY, pressure, azimuth, altitude, timestamp, isPencilInput)
                recordBenchmarkInputSample()

                isDraggingSelection = true
                lastDragPoint = location
            }
            requestDisplay()
        } else {
            // Normal drawing mode
            activeStrokeTool = pendingTool
            let pressure = normalizedPressure(for: touch)
            let (azimuth, altitude) = extractAzimuthAndAltitude(for: touch)
            let isPencilInput = PencilStrokeInputNormalizer.isPencil(touch)
            let timestamp = Int64(touch.timestamp * 1000)  // Convert to milliseconds
            touchBegan(engine, scaledX, scaledY, pressure, azimuth, altitude, timestamp, isPencilInput)
            recordBenchmarkInputSample()
            isHoldToShapeStrokeActive = true
            scheduleHoldToShapePreview(restart: true)
            requestDisplay()
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let engine = drawingEngine, let touch = touches.first else { return }

        // Don't process touches when in text mode
        if isTextMode {
            cancelHoldToShapePreview()
            isHoldToShapeStrokeActive = false
            return
        }

        // Filter touches based on drawing policy
        if shouldIgnoreTouchForDrawingPolicy(touch) {
            return
        }

        // Update cursor for all touch modes (but skip during selection move for performance)
        let currentLocation = touch.location(in: superview ?? self)
        currentTouchLocation = currentLocation

        if isTransformingSelection {
            cancelHoldToShapePreview()
            isHoldToShapeStrokeActive = false
            updateSelectionTransform(
                engine,
                Float(currentLocation.x * scaleX),
                Float(currentLocation.y * scaleY)
            )
            hasSelectionMoveDelta = true
            lastDragPoint = currentLocation
            requestDisplay()
            notifySelectionChange()
            return
        }

        if isMovingSelection, let lastPoint = lastDragPoint {
            cancelHoldToShapePreview()
            isHoldToShapeStrokeActive = false
            // Moving existing selection - optimized path
            let location = touch.location(in: superview ?? self)
            let dx = Float((location.x - lastPoint.x) * scaleX)
            let dy = Float((location.y - lastPoint.y) * scaleY)

            if dx != 0 || dy != 0 {
                hasSelectionMoveDelta = true
                moveSelection(engine, dx, dy)
                notifySelectionChange()
            }
            lastDragPoint = location
            requestDisplay()
            return  // Skip eraser cursor update for performance
        }

        // Update eraser cursor only when not moving selection
        updateEraserCursor(at: currentLocation, width: pendingWidth)

        if isSelectionMode && isDraggingSelection {
            cancelHoldToShapePreview()
            isHoldToShapeStrokeActive = false
            // In selection mode: continue selecting strokes (like eraser drag)
            if let coalesced = event?.coalescedTouches(for: touch), !coalesced.isEmpty {
                for sample in coalesced {
                    processTouchSample(engine: engine, touch: sample)
                }
            } else {
                processTouchSample(engine: engine, touch: touch)
            }
            requestDisplay()
        } else if !isSelectionMode {
            // PREDICTIVE TOUCH: Clear old predicted points before adding new actual data
            clearPredictedPoints(engine)

            // Normal drawing mode - process coalesced touches (actual data)
            if let coalesced = event?.coalescedTouches(for: touch), !coalesced.isEmpty {
                for sample in coalesced {
                    processTouchSample(engine: engine, touch: sample)
                }
            } else {
                processTouchSample(engine: engine, touch: touch)
            }

            // PREDICTIVE TOUCH: Add predicted points for Apple Pencil low-latency rendering
            // Only for Apple Pencil - finger touch doesn't have useful predictions
            if touch.type == .pencil, let predicted = event?.predictedTouches(for: touch) {
                for predictedTouch in predicted {
                    processPredictedTouchSample(engine: engine, touch: predictedTouch)
                }
            }

            scheduleHoldToShapePreview()
            requestDisplay()
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let engine = drawingEngine, let touch = touches.first else { return }

        // Don't process touches when in text mode
        if isTextMode {
            cancelHoldToShapePreview()
            isHoldToShapeStrokeActive = false
            return
        }

        // Filter touches based on drawing policy
        if shouldIgnoreTouchForDrawingPolicy(touch) {
            return
        }

        // Hide eraser cursor when touch ends
        currentTouchLocation = nil
        updateEraserCursor(at: nil, width: pendingWidth)

        if isTransformingSelection {
            cancelHoldToShapePreview()
            isHoldToShapeStrokeActive = false
            let didTransformSelection = hasSelectionMoveDelta
            if didTransformSelection {
                finalizeSelectionTransform(engine)
            } else {
                cancelSelectionTransform(engine)
            }
            isTransformingSelection = false
            selectionTransformHandleIndex = -1
            hasSelectionMoveDelta = false
            lastDragPoint = nil
            requestDisplay()
            notifySelectionChange()
            if didTransformSelection {
                scheduleEraserMaskOptimization()
                onDrawingChange?([:])
            }
        } else if isMovingSelection {
            cancelHoldToShapePreview()
            isHoldToShapeStrokeActive = false
            // Finished moving selection - finalize and update history
            // only when the touch actually moved. A finger tap that just
            // selects a stroke should not create a zero-distance undo entry.
            let didMoveSelection = hasSelectionMoveDelta
            if didMoveSelection {
                finalizeMove(engine)
            }
            isMovingSelection = false
            hasSelectionMoveDelta = false
            lastDragPoint = nil
            requestDisplay()
            notifySelectionChange()
            if didMoveSelection {
                scheduleEraserMaskOptimization()
                onDrawingChange?([:])
            }
        } else if isSelectionMode && isDraggingSelection {
            cancelHoldToShapePreview()
            isHoldToShapeStrokeActive = false
            // Finalize selection
            touchEnded(engine, currentUptimeTimestampMillis())
            isDraggingSelection = false
            lastDragPoint = nil
            requestDisplay()
            notifySelectionChange()
        } else if !isSelectionMode {
            cancelHoldToShapePreview()
            isHoldToShapeStrokeActive = false
            // Normal drawing mode
            // PREDICTIVE TOUCH: Clear predicted points before finalizing stroke
            // Final stroke should only contain actual touch data, not predictions
            clearPredictedPoints(engine)
            touchEnded(engine, currentUptimeTimestampMillis())
            recordBenchmarkInputSample()
            requestDisplay()
            let completedTool = activeStrokeTool
            activeStrokeTool = nil
            if completedTool == "eraser" && pendingEraserMode == "pixel" {
                scheduleEraserMaskOptimization()
            }
            if let completedTool { onDrawingChange?(["completedStrokeTool": completedTool]) }
            else { onDrawingChange?([:]) }
        }
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let engine = drawingEngine, let touch = touches.first else { return }
        let cancelledTool = activeStrokeTool
        activeStrokeTool = nil

        // Filter touches based on drawing policy
        if shouldIgnoreTouchForDrawingPolicy(touch) {
            return
        }

        // Hide eraser cursor when touch cancelled
        cancelHoldToShapePreview()
        isHoldToShapeStrokeActive = false
        currentTouchLocation = nil
        updateEraserCursor(at: nil, width: pendingWidth)

        if isTransformingSelection {
            cancelSelectionTransform(engine)
            isTransformingSelection = false
            selectionTransformHandleIndex = -1
            hasSelectionMoveDelta = false
            lastDragPoint = nil
            requestDisplay()
            notifySelectionChange()
        } else if isSelectionMode || isMovingSelection {
            // Cancel selection drag or move
            isDraggingSelection = false
            isMovingSelection = false
            hasSelectionMoveDelta = false
            lastDragPoint = nil
        } else {
            // Normal drawing mode
            clearPredictedPoints(engine)  // Clear predictions before cancelling
            touchEnded(engine, 0)
            if cancelledTool == "eraser" && pendingEraserMode == "pixel" {
                scheduleEraserMaskOptimization()
            }
            requestDisplay()
            onDrawingChange?([:])
        }
    }

    @objc func clearDocumentPage(_ pageIndex: Int32, pageHeight: Float) {
        guard let engine = drawingEngine else { return }
        let hadSelection = getSelectionCount(engine) > 0
        guard clearContinuousDocumentPage(engine, pageIndex, pageHeight) else { return }
        endSelectionInteractionAfterHistoryChange(hadSelection: hadSelection)
        requestDisplay()
        onDrawingChange?([:])
    }

    @objc func clear() {
        guard let engine = drawingEngine else { return }
        let hadSelection = getSelectionCount(engine) > 0
        clearCanvas(engine)
        endSelectionInteractionAfterHistoryChange(hadSelection: hadSelection)
        requestDisplay()
        onDrawingChange?([:])
    }

    @objc func recordExternalEdit(_ before: String, after: String) -> Bool {
        guard let engine = drawingEngine else { return false }
        return before.withCString { beforeBytes in
            after.withCString { afterBytes in commitExternalEdit(engine, beforeBytes, afterBytes) }
        }
    }

    @objc func undo() {
        guard let engine = drawingEngine else { return }
        let hadSelection = getSelectionCount(engine) > 0
        let external = undoExternalEdit(engine)
        endSelectionInteractionAfterHistoryChange(hadSelection: hadSelection)
        scheduleEraserMaskOptimization()
        requestDisplay()
        if let external {
            let payload = String(cString: external)
            free(external)
            onDrawingChange?(["historyAction": "undo", "externalEdit": ["payload": payload]])
        } else {
            onDrawingChange?(["historyAction": "undo"])
        }
    }

    @objc func redo() {
        guard let engine = drawingEngine else { return }
        let hadSelection = getSelectionCount(engine) > 0
        let external = redoExternalEdit(engine)
        endSelectionInteractionAfterHistoryChange(hadSelection: hadSelection)
        scheduleEraserMaskOptimization()
        requestDisplay()
        if let external {
            let payload = String(cString: external)
            free(external)
            onDrawingChange?(["historyAction": "redo", "externalEdit": ["payload": payload]])
        } else {
            onDrawingChange?(["historyAction": "redo"])
        }
    }

    /// Undo, redo and clear rebuild the stroke list, so the engine drops its
    /// selection. Mirror that here: stop any in-flight move/transform and hide
    /// the selection toolbar so it cannot act on strokes that are gone.
    /// An in-progress lasso is kept: it selects against the new strokes on
    /// pen-up.
    private func endSelectionInteractionAfterHistoryChange(hadSelection: Bool) {
        isMovingSelection = false
        isTransformingSelection = false
        selectionTransformHandleIndex = -1
        hasSelectionMoveDelta = false
        if hadSelection {
            notifySelectionChange()
        }
    }

    // MARK: - Eraser Cursor

    private func setupEraserCursor() {
        if eraserCursorLayer == nil {
            let cursorLayer = CAShapeLayer()
            cursorLayer.fillColor = UIColor.clear.cgColor
            cursorLayer.strokeColor = UIColor.systemGray.cgColor
            cursorLayer.lineWidth = 2.0
            cursorLayer.isHidden = true
            layer.addSublayer(cursorLayer)
            eraserCursorLayer = cursorLayer
        }
    }

    private func updateEraserCursor(at location: CGPoint?, width: Float) {
        guard let cursorLayer = eraserCursorLayer else { return }

        if let location = location, pendingTool == "eraser" && pendingEraserMode == "pixel" {
            // Show cursor with circle matching eraser size
            // Width is in canvas coordinates, need to convert to view coordinates
            let radiusInViewCoords = CGFloat(width) / (2.0 * scaleX)
            let localLocation = CGPoint(x: location.x - frame.minX, y: location.y - frame.minY)
            let circlePath = UIBezierPath(arcCenter: localLocation,
                                         radius: radiusInViewCoords,
                                         startAngle: 0,
                                         endAngle: .pi * 2,
                                         clockwise: true)
            cursorLayer.path = circlePath.cgPath
            cursorLayer.isHidden = false
        } else {
            // Hide cursor for non-eraser tools
            cursorLayer.isHidden = true
        }
    }

    private func emitPencilDoubleTapEvent() {
        pencilDoubleTapSequence += 1
        onPencilDoubleTap?([
            "sequence": pencilDoubleTapSequence,
            "timestamp": Date().timeIntervalSince1970 * 1000,
        ])
    }

    @objc func setTool(_ toolType: String, width: Float, color: UIColor, eraserMode: String = "pixel") {
        cancelHoldToShapePreview()

        // Convert UIColor to UInt32 (ARGB format)
        var red: CGFloat = 0
        var green: CGFloat = 0
        var blue: CGFloat = 0
        var alpha: CGFloat = 0
        color.getRed(&red, green: &green, blue: &blue, alpha: &alpha)

        let a = UInt32(alpha * 255) << 24
        let r = UInt32(red * 255) << 16
        let g = UInt32(green * 255) << 8
        let b = UInt32(blue * 255)
        let argb = a | r | g | b

        // Store settings for when engine is ready
        pendingTool = toolType
        pendingWidth = width
        pendingColor = argb
        pendingEraserMode = eraserMode
        isHoldToShapeStrokeActive = false

        syncInteractionModeFlags()
        resetTransientInteractionState()

        if !isSelectionMode, let engine = drawingEngine {
            // Clear selection when switching to non-selection tool
            clearSelection(engine)
            notifySelectionChange()
        }

        // Update eraser cursor visibility when tool changes
        if toolType == "eraser" && eraserMode == "pixel" {
            updateEraserCursor(at: currentTouchLocation, width: width)
        } else {
            updateEraserCursor(at: nil, width: width)
        }

        // If engine exists, apply immediately
        if let engine = drawingEngine {
            toolType.withCString { toolPtr in
                pendingEraserMode.withCString { eraserPtr in
                    nativeSetToolWithParams(engine, toolPtr, width, argb, eraserPtr)
                }
            }
        }
    }

    /// Set background type on C++ engine so it knows whether to clear with transparent (for PDF) or white
    func setEngineBackgroundType(_ backgroundType: String) {
        // Always store as pending (applied when engine is created, or re-applied if engine restarts)
        pendingBackgroundType = backgroundType

        guard let engine = drawingEngine else {
            print("⏳ [MobileInkCanvasView] Engine not ready, stored pending background type: \(backgroundType)")
            return
        }

        backgroundType.withCString { typePtr in
            nativeSetBackgroundType(engine, typePtr)
        }
        print("✅ [MobileInkCanvasView] Set engine background type to: \(backgroundType)")
        requestDisplay(forceWhenSuspended: true)
    }

    // Used only by the document bridge, which validates and builds geometry on
    // its background queue. The pointer is borrowed for this synchronous swap.
    func loadPreparedDrawing(_ snapshot: UnsafeMutableRawPointer, callback: @escaping RCTResponseSenderBlock) {
        guard let engine = drawingEngine, !isReleased else {
            callback([NSNull(), false])
            return
        }
        guard replaceDrawingSnapshot(engine, snapshot) else {
            callback(["Failed to install prepared drawing", NSNull()])
            return
        }
        deferredBase64Payload = nil
        hasDeferredPresentation = false
        syncInteractionModeFlags()
        resetTransientInteractionState()
        applyPendingTool(to: engine)
        notifySelectionChange()
        enqueueLoadPresentationCallback(callback)
        scheduleEraserMaskOptimization()
    }

    @objc func loadBase64Data(_ base64String: String, callback: @escaping RCTResponseSenderBlock) {
        // React attaches the native view before its first layout creates the
        // engine. Report retryable readiness without treating valid ink as bad.
        guard drawingEngine != nil else {
            callback([NSNull(), false])
            return
        }
        deferredBase64Payload = nil
        if let errorMessage = applyBase64Data(base64String) {
            callback([errorMessage, NSNull()])
            return
        }

        hasDeferredPresentation = false
        enqueueLoadPresentationCallback(callback)
        scheduleEraserMaskOptimization()
    }

    @objc func stageBase64Data(_ base64String: String, callback: @escaping RCTResponseSenderBlock) {
        deferredBase64Payload = base64String
        hasDeferredPresentation = true
        callback([NSNull(), true])
    }

    @objc func presentDeferredLoad(_ callback: @escaping RCTResponseSenderBlock) {
        if !hasDeferredPresentation {
            callback([NSNull(), true])
            return
        }

        let pendingPayload = deferredBase64Payload
        deferredBase64Payload = nil
        hasDeferredPresentation = false

        if let pendingPayload {
            if let errorMessage = applyBase64Data(pendingPayload) {
                callback([errorMessage, NSNull()])
                return
            }
        }

        enqueueLoadPresentationCallback(callback)
        scheduleEraserMaskOptimization()
    }

    private func applyBase64Data(_ base64String: String) -> String? {
        guard let engine = drawingEngine else {
            return "Engine not initialized"
        }

        if base64String.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            clearCanvas(engine)
            syncInteractionModeFlags()
            resetTransientInteractionState()
            applyPendingTool(to: engine)
            notifySelectionChange()
            return nil
        }

        guard let jsonData = base64String.data(using: .utf8) else {
            return "Invalid JSON string"
        }

        do {
            guard let jsonDict = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any],
                  let pages = jsonDict["pages"] as? [String: String] else {
                return "Invalid drawing payload JSON"
            }

            guard let page0Base64 = pages["0"] else {
                clearCanvas(engine)
                syncInteractionModeFlags()
                resetTransientInteractionState()
                applyPendingTool(to: engine)
                notifySelectionChange()
                return nil
            }

            guard let binaryData = Data(base64Encoded: page0Base64) else {
                return "Failed to decode base64 data"
            }

            if !restoreRawDrawingData(binaryData, into: engine) {
                return "Failed to deserialize drawing payload"
            }

            syncInteractionModeFlags()
            resetTransientInteractionState()
            applyPendingTool(to: engine)
            notifySelectionChange()

            return nil
        } catch {
            return error.localizedDescription
        }
    }

    private func enqueueLoadPresentationCallback(_ callback: @escaping RCTResponseSenderBlock) {
        pendingPresentedLoadCallbacks.append(callback)
        requestDisplay(forceWhenSuspended: true)
    }

    private func syncInteractionModeFlags() {
        isSelectionMode = (pendingTool == "select")
        isTextMode = (pendingTool == "text")
    }

    func resetTransientInteractionState() {
        isDraggingSelection = false
        isMovingSelection = false
        isTransformingSelection = false
        selectionTransformHandleIndex = -1
        hasSelectionMoveDelta = false
        isHoldToShapeStrokeActive = false
        lastDragPoint = nil
        // Hide the eraser cursor overlay so a pooled view reassigned to a new
        // page doesn't keep showing a stale cursor circle.
        updateEraserCursor(at: nil, width: 0)
    }

    @objc func getBase64PngData(_ scale: CGFloat, callback: @escaping RCTResponseSenderBlock) {
        print("📸 [Export] getBase64PngData called with scale: \(scale)")
        print("📸 [Export] pageWidth: \(pageWidth), pageHeight: \(pageHeight)")
        print("📸 [Export] backgroundView: \(backgroundView != nil ? "exists" : "nil")")

        guard let engine = drawingEngine else {
            callback(["Engine not initialized", NSNull()])
            return
        }

        // Get Skia snapshot
        guard let skImagePtr = makeSnapshot(engine) else {
            callback(["Failed to create snapshot", NSNull()])
            return
        }
        defer { releaseSkImage(skImagePtr) }

        // Convert Skia image to UIImage with background composited
        guard let uiImage = skImageToUIImage(skImagePtr, scale: scale) else {
            callback(["Failed to convert image", NSNull()])
            return
        }

        print("📸 [Export] Generated UIImage size: \(uiImage.size.width) × \(uiImage.size.height), scale: \(uiImage.scale)")
        print("📸 [Export] Actual pixel dimensions: \(Int(uiImage.size.width * uiImage.scale)) × \(Int(uiImage.size.height * uiImage.scale))")

        // Encode as PNG
        guard let pngData = uiImage.pngData() else {
            callback(["Failed to encode PNG", NSNull()])
            return
        }

        // Return as data URI
        let base64String = pngData.base64EncodedString()
        let dataUri = "data:image/png;base64,\(base64String)"
        callback([NSNull(), dataUri])
    }

    @objc func getBase64JpegData(_ scale: CGFloat, compression: CGFloat, callback: @escaping RCTResponseSenderBlock) {
        guard let engine = drawingEngine else {
            callback(["Engine not initialized", NSNull()])
            return
        }

        // Get Skia snapshot
        guard let skImagePtr = makeSnapshot(engine) else {
            callback(["Failed to create snapshot", NSNull()])
            return
        }
        defer { releaseSkImage(skImagePtr) }

        // Convert Skia image to UIImage with background composited
        guard let uiImage = skImageToUIImage(skImagePtr, scale: scale) else {
            callback(["Failed to convert image", NSNull()])
            return
        }

        // Encode as JPEG
        guard let jpegData = uiImage.jpegData(compressionQuality: compression) else {
            callback(["Failed to encode JPEG", NSNull()])
            return
        }

        // Return as data URI
        let base64String = jpegData.base64EncodedString()
        let dataUri = "data:image/jpeg;base64,\(base64String)"
        callback([NSNull(), dataUri])
    }

    // Helper to convert Skia image to UIImage with background composited
    // Copied from PencilKit's getBase64PngDataForPage approach
    private func skImageToUIImage(_ skImagePtr: OpaquePointer, scale: CGFloat) -> UIImage? {
        let actualScale = scale > 0 ? scale : UIScreen.main.scale

        // Use actual page dimensions (screen-based), exactly like PencilKit
        let pageBounds = CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight)

        print("📸 [Composite] Exporting at page dimensions: \(pageWidth) × \(pageHeight), scale: \(actualScale)")

        // Create a graphics context to composite background + drawing (PencilKit line 490)
        let size = CGSize(width: pageWidth * actualScale, height: pageHeight * actualScale)
        print("📸 [Composite] Context size: \(size.width) × \(size.height)")

        UIGraphicsBeginImageContextWithOptions(size, true, 1.0)
        guard let context = UIGraphicsGetCurrentContext() else {
            return nil
        }

        // Scale the context (PencilKit line 498)
        context.scaleBy(x: actualScale, y: actualScale)

        // Draw background directly into context (PencilKit line 500-509)
        // This matches PencilKit's drawBackground(in: context, rect: pageBounds, type: backgroundType)
        if let bgView = backgroundView {
            print("📸 [Composite] Drawing background into context with drawIntoContext method")
            bgView.drawIntoContext(context, rect: pageBounds)
        } else {
            print("📸 [Composite] No backgroundView, filling with white")
            context.setFillColor(UIColor.white.cgColor)
            context.fill(pageBounds)
        }

        // Draw the Skia drawing on top (PencilKit line 512-515)
        // For Skia, render at screen scale for quality, then draw scaled
        guard let engine = drawingEngine else {
            UIGraphicsEndImageContext()
            return nil
        }

        // Render strokes at screen scale for quality (prevents dotted lines at low scales)
        let drawingImage = renderEngineToUIImage(engine, scale: actualScale)

        // The image is rendered at minRenderScale but we draw it at page bounds
        // The context scaling handles the final output size
        drawingImage.draw(in: pageBounds)

        // Get the composite image (PencilKit line 518)
        guard let compositeImage = UIGraphicsGetImageFromCurrentImageContext() else {
            UIGraphicsEndImageContext()
            return nil
        }
        UIGraphicsEndImageContext()

        return compositeImage
    }

    // Render engine to UIImage at specified scale (like PencilKit's image(from:scale:))
    private func renderEngineToUIImage(_ engine: OpaquePointer, scale: CGFloat) -> UIImage {
        // Always render at minimum 2x to preserve stroke quality, then scale down if needed
        // This prevents thin strokes from appearing dotted at low scales
        let minRenderScale = max(scale, UIScreen.main.scale)

        // Calculate render dimensions at the higher scale
        let renderWidth = Int(pageWidth * minRenderScale)
        let renderHeight = Int(pageHeight * minRenderScale)
        let bytesPerRow = renderWidth * 4
        let bufferLength = bytesPerRow * renderHeight

        // Allocate temporary buffer for rendering
        guard let renderBuffer = malloc(bufferLength) else {
            return UIImage() // Return empty image on allocation failure
        }
        defer { free(renderBuffer) }

        // Clear buffer to transparent
        memset(renderBuffer, 0, bufferLength)

        // Create Skia canvas wrapping the render buffer
        let renderCanvas = createSkiaCanvas(
            renderBuffer,
            Int32(renderWidth),
            Int32(renderHeight),
            Int32(bytesPerRow)
        )

        if let renderCanvas = renderCanvas {
            // Engine stores strokes in pixel coordinates, but we're exporting at page dimensions
            // Scale to convert: pixels → page → export scale (using minRenderScale for quality)
            let pixelToPage = Float(pageWidth) / Float(max(1, enginePixelWidth))  // e.g. 788 / 1576 = 0.5
            let totalScale = pixelToPage * Float(minRenderScale)  // Use higher scale for quality
            scaleSkiaCanvas(renderCanvas, totalScale, totalScale)

            // Render engine strokes (in pixel coords) to the scaled canvas
            renderToCanvasForExport(engine, renderCanvas)
            destroySkiaCanvas(renderCanvas)
        }

        // Convert buffer to UIImage
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        let bitmapInfo = CGBitmapInfo(rawValue:
            CGImageAlphaInfo.premultipliedFirst.rawValue |
            CGBitmapInfo.byteOrder32Little.rawValue
        )

        guard let dataProvider = CGDataProvider(
            data: Data(bytes: renderBuffer, count: bufferLength) as CFData
        ),
        let cgImage = CGImage(
            width: renderWidth,
            height: renderHeight,
            bitsPerComponent: 8,
            bitsPerPixel: 32,
            bytesPerRow: bytesPerRow,
            space: colorSpace,
            bitmapInfo: bitmapInfo,
            provider: dataProvider,
            decode: nil,
            shouldInterpolate: true,
            intent: .defaultIntent
        ) else {
            return UIImage()
        }

        return UIImage(cgImage: cgImage)
    }

    // Selection operations
    @objc func performCopy() {
        guard let engine = drawingEngine else { return }
        copySelection(engine)
        updateSelectionToolbarFrame()
    }

    @objc func performPaste() {
        guard let engine = drawingEngine else { return }
        // Paste with a slight offset (50 points down and right)
        pasteSelection(engine, 50.0, 50.0)
        requestDisplay()
        notifySelectionChange()
        onDrawingChange?([:])
    }

    @objc func performDelete() {
        guard let engine = drawingEngine else { return }
        deleteSelection(engine)
        requestDisplay()
        notifySelectionChange()
        onDrawingChange?([:])
    }

    func notifySelectionChange() {
        guard let engine = drawingEngine else { return }
        let count = Int(getSelectionCount(engine))
        var payload: [String: Any] = ["count": count]
        if count > 0, let selectionRect = selectionBoundsInView(engine: engine) {
            payload["bounds"] = [
                "x": selectionRect.minX,
                "y": selectionRect.minY,
                "width": selectionRect.width,
                "height": selectionRect.height,
            ]
        } else {
            payload["bounds"] = NSNull()
        }
        updateSelectionToolbarFrame()
        onInkSelectionChange?(payload)
    }

    private func serializedDrawingData() -> Data? {
        guard let engine = drawingEngine else {
            return nil
        }

        var size: Int32 = 0
        guard let dataPtr = serializeDrawing(engine, &size), size > 0 else {
            return nil
        }
        defer {
            freeSerializedData(dataPtr)
        }

        return Data(bytes: dataPtr, count: Int(size))
    }

    private func applyPendingBackgroundType(to engine: OpaquePointer) {
        pendingBackgroundType.withCString { typePtr in
            nativeSetBackgroundType(engine, typePtr)
        }
    }

    private func applyPendingTool(to engine: OpaquePointer) {
        pendingTool.withCString { toolPtr in
            pendingEraserMode.withCString { eraserPtr in
                nativeSetToolWithParams(engine, toolPtr, pendingWidth, pendingColor, eraserPtr)
            }
        }
    }

    @discardableResult
    private func restoreRawDrawingData(_ drawingData: Data, into engine: OpaquePointer) -> Bool {
        let didDeserialize = drawingData.withUnsafeBytes { (ptr: UnsafeRawBufferPointer) -> Bool in
            guard let baseAddress = ptr.baseAddress else {
                return false
            }

            let uint8Ptr = baseAddress.assumingMemoryBound(to: UInt8.self)
            return deserializeDrawing(engine, uint8Ptr, Int32(drawingData.count))
        }

        guard didDeserialize else {
            return false
        }

        syncInteractionModeFlags()
        resetTransientInteractionState()
        applyPendingTool(to: engine)
        notifySelectionChange()
        requestDisplay(forceWhenSuspended: true)
        return true
    }

    private func configureDrawingEngine(
        width: Int32,
        height: Int32,
        preserveExistingDrawing: Bool
    ) {
        let preservedDrawingData = preserveExistingDrawing ? serializedDrawingData() : nil

        if let engine = drawingEngine {
            destroyDrawingEngine(engine)
            drawingEngine = nil
        }

        drawingEngine = continuousDocument
            ? createContinuousDrawingEngine(width, height)
            : createDrawingEngine(width, height)
        enginePixelWidth = width
        enginePixelHeight = height

        guard let engine = drawingEngine else {
            return
        }

        if pendingImageLayers != nil { installPendingImageLayers() }
        else if let json = documentImageLayersJSON { scheduleImageLayersPreparation(json) }

        setHoldToShapeEnabled(engine, holdToShapeEnabled)
        setViewportMotionActive(engine, viewportMotionActive)
        applyPendingBackgroundType(to: engine)
        applyRenderViewportToEngine()

        if let preservedDrawingData, !preservedDrawingData.isEmpty {
            if !restoreRawDrawingData(preservedDrawingData, into: engine) {
                print("⚠️ Failed to restore drawing payload after resizing engine")
                syncInteractionModeFlags()
                resetTransientInteractionState()
                applyPendingTool(to: engine)
                notifySelectionChange()
            }
        } else {
            syncInteractionModeFlags()
            resetTransientInteractionState()
            applyPendingTool(to: engine)
            notifySelectionChange()
            applyRenderViewportToEngine()
            requestDisplay(forceWhenSuspended: true)
        }
    }

    #if DEBUG
    func injectStrokeForTesting(points: [CGPoint]) {
        guard let engine = drawingEngine, let firstPoint = points.first else {
            return
        }

        touchBegan(
            engine,
            Float(firstPoint.x * scaleX),
            Float(firstPoint.y * scaleY),
            1.0,
            0.0,
            PencilStrokeInputNormalizer.perpendicularAltitude,
            0,
            false
        )

        for (index, point) in points.dropFirst().enumerated() {
            touchMoved(
                engine,
                Float(point.x * scaleX),
                Float(point.y * scaleY),
                1.0,
                0.0,
                PencilStrokeInputNormalizer.perpendicularAltitude,
                Int64((index + 1) * 16),
                false
            )
        }

        touchEnded(engine, Int64(points.count * 16))
        requestDisplay(forceWhenSuspended: true)
    }

    func serializedDrawingDataForTesting() -> Data? {
        serializedDrawingData()
    }

    @discardableResult
    func loadRawDrawingDataForTesting(_ drawingData: Data) -> Bool {
        guard let engine = drawingEngine else {
            return false
        }

        return restoreRawDrawingData(drawingData, into: engine)
    }
    #endif
}

@available(iOS 12.1, *)
extension MobileInkCanvasView: UIPencilInteractionDelegate {
    func pencilInteractionDidTap(_ interaction: UIPencilInteraction) {
        emitPencilDoubleTapEvent()
    }

    @available(iOS 17.5, *)
    func pencilInteraction(_ interaction: UIPencilInteraction, didReceiveTap tap: UIPencilInteraction.Tap) {
        emitPencilDoubleTapEvent()
    }
}

extension MobileInkCanvasView: MTKViewDelegate {
    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {
        // If we've already released (slot unmount), refuse to
        // re-allocate the 13 MB pixel buffer / re-create the engine.
        // MTKView can fire this delegate method during the layout pass
        // even after we've been removed from the window hierarchy --
        // that's exactly the path that resurrected leaked buffers
        // before this guard.
        if isReleased { return }

        // Calculate page dimensions from bounds (for export)
        if documentSize.width > 0 && documentSize.height > 0 {
            pageWidth = documentSize.width
            pageHeight = pageWidth * (11.0 / 8.5) // US Letter aspect ratio
        }

        applyDrawableContentScale(updateDrawableSize: false)

        // Calculate scale from view bounds to the stable document-pixel
        // coordinate system. The drawable may be larger at high zoom, but
        // touches must remain in the same persisted stroke coordinates.
        let baseScale = baseContentScale()
        let nextEnginePixelWidth: Int32
        let nextEnginePixelHeight: Int32
        if documentSize.width > 0 && documentSize.height > 0 {
            scaleX = baseScale
            scaleY = baseScale
            nextEnginePixelWidth = Int32(max(1, round(documentSize.width * baseScale)))
            nextEnginePixelHeight = Int32(max(1, round(documentSize.height * baseScale)))
        } else {
            nextEnginePixelWidth = 0
            nextEnginePixelHeight = 0
        }

        if size.width > 0 && size.height > 0 {
            pixelWidth = Int32(size.width)
            pixelHeight = Int32(size.height)
            if useExperimentalGaneshBackend {
                pixelBuffer?.deallocate()
                pixelBuffer = nil
                pixelBufferLength = 0
                pixelBytesPerRow = 0
            } else {
                allocatePixelBuffer(width: Int(size.width), height: Int(size.height))
            }
        }

        if nextEnginePixelWidth > 0 && nextEnginePixelHeight > 0 {
            if drawingEngine == nil {
                configureDrawingEngine(
                    width: nextEnginePixelWidth,
                    height: nextEnginePixelHeight,
                    preserveExistingDrawing: false
                )
                print("✅ Drawing engine created with size: \(pixelWidth)x\(pixelHeight) (page: \(pageWidth)x\(pageHeight))")
            } else if enginePixelWidth != nextEnginePixelWidth || enginePixelHeight != nextEnginePixelHeight {
                if continuousDocument, let engine = drawingEngine,
                   resizeContinuousDrawingEngine(engine, nextEnginePixelWidth, nextEnginePixelHeight) {
                    enginePixelWidth = nextEnginePixelWidth
                    enginePixelHeight = nextEnginePixelHeight
                    applyRenderViewportToEngine()
                } else {
                    configureDrawingEngine(
                        width: nextEnginePixelWidth,
                        height: nextEnginePixelHeight,
                        preserveExistingDrawing: true
                    )
                }
                print("✅ Drawing engine resized to: \(pixelWidth)x\(pixelHeight) (page: \(pageWidth)x\(pageHeight))")
            } else {
                applyRenderViewportToEngine()
            }
        }

        requestDisplay(forceWhenSuspended: true)
    }


    private func ensureGaneshMetalContext() -> OpaquePointer? {
        if let context = ganeshMetalContext {
            return context
        }

        guard !ganeshPreparationAttempted, !isReleased,
              let device = device, let commandQueue = commandQueue else {
            return nil
        }
        ganeshPreparationAttempted = true
        ganeshPreparationPending = true
        ganeshPreparationRequest = MobileInkGaneshPreparation.prepare(device: device, commandQueue: commandQueue) { [weak self] context in
            guard let self, !self.isReleased else {
                if let context { MobileInkGaneshPreparation.discard(context) }
                return
            }
            self.ganeshPreparationPending = false
            self.ganeshPreparationRequest = nil
            self.ganeshMetalContext = context
            if context == nil {
                NSLog("[MobileInk][Ganesh] Renderer preparation failed; using CPU rendering")
            }
            self.requestDisplay(forceWhenSuspended: true)
        }
        return nil
    }

    private func attachPresentedLoadCallbacks(to commandBuffer: MTLCommandBuffer) {
        guard !pendingPresentedLoadCallbacks.isEmpty else {
            return
        }

        let loadCallbacks = pendingPresentedLoadCallbacks
        pendingPresentedLoadCallbacks.removeAll()
        commandBuffer.addCompletedHandler { [weak self] completed in
            DispatchQueue.main.async {
                let error: String?
                if self?.isReleased != false { error = "Canvas released before load presentation" }
                else if completed.status == .error { error = "Metal could not present the loaded drawing" }
                else { error = nil }
                if error == nil { self?.interactionAudit?.didPresentInitialLoad() }
                loadCallbacks.forEach { callback in
                    if let error { callback([error, NSNull()]) }
                    else { callback([NSNull(), true]) }
                }
            }
        }
    }

    func draw(in view: MTKView) {
        guard !isReleased, drawingEngine != nil, window != nil,
              drawableSize.width > 0, drawableSize.height > 0,
              let metalLayer = layer as? CAMetalLayer else { return }
        // MTKView normally synchronizes its layer during its display callback.
        // The asynchronous on-demand loop must do that before acquiring a
        // drawable; otherwise zoom receives textures with the previous size.
        if metalLayer.drawableSize != drawableSize { metalLayer.drawableSize = drawableSize }
        hasPendingFrame = true
        if useExperimentalGaneshBackend {
            _ = ensureGaneshMetalContext()
            if ganeshPreparationPending && !hasPresentedFrame { return }
        }
        if pendingFrameRequestedAt == nil { pendingFrameRequestedAt = CACurrentMediaTime() }

        // MTKView.currentDrawable can wait a full second when the presentation
        // pool is exhausted. Never perform that wait on the Pencil/input thread.
        frameAcquisition.acquire({ metalLayer.nextDrawable() }) { [weak self] drawable in
            guard let self, !self.isReleased else { return }
            guard let drawable, self.window != nil,
                  drawable.texture.width == Int(self.drawableSize.width),
                  drawable.texture.height == Int(self.drawableSize.height) else {
                self.frameAcquisition.finish()
                self.retryPendingFrame()
                return
            }
            let requestedAt = self.pendingFrameRequestedAt ?? CACurrentMediaTime()
            // The engine and target frame are read on the main thread below.
            // A drawable acquired for an older revision is still usable when
            // its size matches the latest geometry.
            let revision = self.renderGeometryRevision
            let geometrySwap = self.continuousDocument && self.frame != self.targetRenderFrame
            let targetFrame = self.targetRenderFrame
            self.hasPendingFrame = false
            self.pendingFrameRequestedAt = nil
            // Keep drawable waiting in the timing evidence even though it no
            // longer blocks input; moving a wait must not hide a late frame.
            let submitted = autoreleasepool { self.renderFrame(to: drawable, requestedAt: requestedAt,
                geometrySwap: geometrySwap, targetFrame: targetFrame, revision: revision) }
            // Commit hands ownership to Metal. Allow the next acquisition
            // while that command buffer executes; CAMetalLayer bounds queued
            // GPU work to its drawable pool without blocking touch delivery.
            if !geometrySwap || !submitted { self.frameAcquisition.finish() }
            if !submitted {
                self.hasPendingFrame = true
                self.pendingFrameRequestedAt = requestedAt
                self.retryPendingFrame()
            }
        }
    }

    private func retryPendingFrame() {
        let interval = 1.0 / Double(max(1, UIScreen.main.maximumFramesPerSecond))
        DispatchQueue.main.asyncAfter(deadline: .now() + interval) { [weak self] in
            guard let self, !self.isReleased, self.hasPendingFrame, self.window != nil else { return }
            self.requestDisplay(forceWhenSuspended: true)
        }
    }

    // A crop's image and its frame must appear in the same Core Animation
    // transaction. Presenting an old drawable under a new frame stretches or
    // shifts old ink for a few frames during a rapid pinch.
    private func presentGeometryFrame(_ drawable: CAMetalDrawable, on commandBuffer: MTLCommandBuffer,
                                      targetFrame: CGRect, revision: UInt64) {
        commandBuffer.addCompletedHandler { [weak self] completed in
            DispatchQueue.main.async {
                guard let self, !self.isReleased else { return }
                defer { self.frameAcquisition.finish() }
                guard completed.status == .completed, self.window != nil,
                      let metalLayer = self.layer as? CAMetalLayer else {
                    self.hasPendingFrame = true
                    self.retryPendingFrame()
                    return
                }
                CATransaction.begin()
                CATransaction.setDisableActions(true)
                metalLayer.presentsWithTransaction = true
                self.frame = targetFrame
                drawable.present()
                CATransaction.commit()
                metalLayer.presentsWithTransaction = false
                // Present the matching image and crop even when a newer crop
                // arrived during rendering. Dropping every such frame can
                // leave only a small old crop visible throughout a fast pinch.
                if revision != self.renderGeometryRevision { self.hasPendingFrame = true }
                let callbacks = self.pendingPresentedLoadCallbacks
                self.pendingPresentedLoadCallbacks.removeAll()
                if !callbacks.isEmpty { self.interactionAudit?.didPresentInitialLoad() }
                callbacks.forEach { $0([NSNull(), true]) }
                if self.hasPendingFrame { self.retryPendingFrame() }
            }
        }
    }

    private func finishFrameAfterSubmission(_ commandBuffer: MTLCommandBuffer, backend: MobileInkRenderBackend) {
        commandBuffer.addCompletedHandler { [weak self] completed in
            DispatchQueue.main.async {
                guard let self, !self.isReleased else { return }
                if completed.status == .error {
                    NSLog("[MobileInk] Metal frame failed: %@", completed.error?.localizedDescription ?? "unknown error")
                    if backend == .ganesh {
                        // Keep the failed context alive until its cached images
                        // and surfaces are released with the engine at teardown.
                        self.ganeshFrameFailed = true
                        self.hasPendingFrame = true
                    }
                }
                // Drain coalesced updates without another display-cycle wait.
                // An existing acquisition remains gated.
                if self.hasPendingFrame { self.draw(in: self) }
            }
        }
    }

    private func renderFrame(to freshDrawable: CAMetalDrawable, requestedAt: CFTimeInterval,
                             geometrySwap: Bool, targetFrame: CGRect, revision: UInt64) -> Bool {
        guard let engine = drawingEngine, !isReleased else { return false }
        // Cropping can resize the drawable without a delegate size callback.
        // Keep the CPU upload buffer in step with the actual Metal drawable.
        let currentWidth = Int32(freshDrawable.texture.width)
        let currentHeight = Int32(freshDrawable.texture.height)
        if currentWidth > 0, currentHeight > 0,
           currentWidth != pixelWidth || currentHeight != pixelHeight {
            pixelWidth = currentWidth
            pixelHeight = currentHeight
            if !useExperimentalGaneshBackend {
                allocatePixelBuffer(width: Int(currentWidth), height: Int(currentHeight))
            }
        }
        let width = pixelWidth
        let height = pixelHeight

        if useExperimentalGaneshBackend,
           let commandQueue = commandQueue,
           let ganeshContext = ensureGaneshMetalContext() {
            let texturePtr = Unmanaged.passUnretained(freshDrawable.texture).toOpaque()
            if renderToGaneshMetalTextureForDisplay(engine, ganeshContext, texturePtr, width, height, usesCroppedViewport, darkDisplay) {
                let renderDurationMs = (CACurrentMediaTime() - requestedAt) * 1000.0
                guard let commandBuffer = commandQueue.makeCommandBuffer() else {
                    return false
                }
                pixelBuffer?.deallocate()
                pixelBuffer = nil
                pixelBufferLength = 0
                pixelBytesPerRow = 0
                if !geometrySwap { attachPresentedLoadCallbacks(to: commandBuffer) }
                attachBenchmarkFrameCallback(
                    to: commandBuffer,
                    backend: .ganesh,
                    didFallbackFromGanesh: false,
                    renderDurationMs: renderDurationMs
                )
                hasPresentedFrame = true
                if geometrySwap {
                    presentGeometryFrame(freshDrawable, on: commandBuffer, targetFrame: targetFrame, revision: revision)
                } else {
                    commandBuffer.present(freshDrawable)
                }
                finishFrameAfterSubmission(commandBuffer, backend: .ganesh)
                commandBuffer.commit()
                return true
            }
        }

        if pixelBuffer == nil && width > 0 && height > 0 {
            allocatePixelBuffer(width: Int(width), height: Int(height))
        }

        guard let commandBuffer = commandQueue?.makeCommandBuffer(),
              let buffer = pixelBuffer else {
            return false
        }

        let bytesPerRow = pixelBytesPerRow

        // Clear pixel buffer to transparent (background view underneath will show through)
        memset(buffer, 0, pixelBufferLength)

        // Render Skia strokes to pixel buffer (no scaling - engine already in pixel coords)
        let canvas = createSkiaCanvas(UnsafeMutableRawPointer(buffer), width, height, Int32(bytesPerRow))
        if let canvas = canvas {
            renderToDisplayCanvas(engine, canvas, usesCroppedViewport, darkDisplay)
            destroySkiaCanvas(canvas)
        }

        // Copy pixel buffer to drawable texture
        let region = MTLRegionMake2D(0, 0, Int(width), Int(height))
        freshDrawable.texture.replace(
            region: region,
            mipmapLevel: 0,
            withBytes: UnsafeRawPointer(buffer),
            bytesPerRow: bytesPerRow
        )
        let renderDurationMs = (CACurrentMediaTime() - requestedAt) * 1000.0

        if !geometrySwap { attachPresentedLoadCallbacks(to: commandBuffer) }
        attachBenchmarkFrameCallback(
            to: commandBuffer,
            backend: .cpu,
            didFallbackFromGanesh: requestedRenderBackend == .ganesh,
            renderDurationMs: renderDurationMs
        )

        hasPresentedFrame = true
        if geometrySwap {
            presentGeometryFrame(freshDrawable, on: commandBuffer, targetFrame: targetFrame, revision: revision)
        } else {
            commandBuffer.present(freshDrawable)
        }
        finishFrameAfterSubmission(commandBuffer, backend: .cpu)
        commandBuffer.commit()
        return true
    }
}

extension MobileInkCanvasView {
  private func canPreviewHoldToShape() -> Bool {
    holdToShapeEnabled && !isSelectionMode
      && !isTextMode
      && (pendingTool == "pen"
        || pendingTool == "pencil"
        || pendingTool == "marker"
        || pendingTool == "calligraphy")
  }

  func currentUptimeTimestampMillis() -> Int64 {
    Int64(ProcessInfo.processInfo.systemUptime * 1000)
  }

  private func scheduleHoldToShapePreview(
    restart: Bool = false,
    delay: TimeInterval? = nil
  ) {
    if restart {
      cancelHoldToShapePreview()
    }

    guard holdToShapeTimer == nil, isHoldToShapeStrokeActive, canPreviewHoldToShape() else {
      return
    }

    let timer = Timer(timeInterval: delay ?? holdToShapeDelay, repeats: false) { [weak self] _ in
      self?.showHoldToShapePreview()
    }
    holdToShapeTimer = timer
    RunLoop.main.add(timer, forMode: .common)
  }

  func cancelHoldToShapePreview() {
    holdToShapeTimer?.invalidate()
    holdToShapeTimer = nil
  }

  private func showHoldToShapePreview() {
    holdToShapeTimer = nil

    guard canPreviewHoldToShape(), let engine = drawingEngine else {
      return
    }

    clearPredictedPoints(engine)
    if updateHoldShapePreview(engine, currentUptimeTimestampMillis()) {
      requestDisplay()
    } else if isHoldToShapeStrokeActive {
      scheduleHoldToShapePreview(delay: holdToShapeRetryDelay)
    }
  }

  private func normalizedPressure(for touch: UITouch) -> Float {
    PencilStrokeInputNormalizer.normalizedPressure(for: touch)
  }

  private func extractAzimuthAndAltitude(for touch: UITouch) -> (azimuth: Float, altitude: Float) {
    PencilStrokeInputNormalizer.azimuthAndAltitude(for: touch, in: self)
  }

  private func processTouchSample(engine: OpaquePointer, touch: UITouch) {
    let location = touch.location(in: superview ?? self)
    let pressure = normalizedPressure(for: touch)
    let (azimuth, altitude) = extractAzimuthAndAltitude(for: touch)
    let isPencilInput = PencilStrokeInputNormalizer.isPencil(touch)
    let scaledX = Float(location.x * scaleX)
    let scaledY = Float(location.y * scaleY)
    let timestamp = Int64(touch.timestamp * 1000)  // Convert to milliseconds
    touchMoved(engine, scaledX, scaledY, pressure, azimuth, altitude, timestamp, isPencilInput)
    recordBenchmarkInputSample()
  }

  // PREDICTIVE TOUCH: Process predicted touch samples for Apple Pencil low-latency rendering
  // These points are rendered temporarily and replaced by actual data on next touch event
  private func processPredictedTouchSample(engine: OpaquePointer, touch: UITouch) {
    let location = touch.location(in: superview ?? self)
    let pressure = normalizedPressure(for: touch)
    let (azimuth, altitude) = extractAzimuthAndAltitude(for: touch)
    let isPencilInput = PencilStrokeInputNormalizer.isPencil(touch)
    let scaledX = Float(location.x * scaleX)
    let scaledY = Float(location.y * scaleY)
    let timestamp = Int64(touch.timestamp * 1000)
    addPredictedPoint(engine, scaledX, scaledY, pressure, azimuth, altitude, timestamp, isPencilInput)
  }

  private func allocatePixelBuffer(width: Int, height: Int) {
    let bytesPerPixel = 4
    let bytesPerRow = width * bytesPerPixel
    let length = bytesPerRow * height

    if width <= 0 || height <= 0 || length <= 0 {
      pixelBuffer?.deallocate()
      pixelBuffer = nil
      pixelBufferLength = 0
      pixelBytesPerRow = 0
      return
    }

    if length != pixelBufferLength {
      pixelBuffer?.deallocate()
      pixelBuffer = UnsafeMutablePointer<UInt8>.allocate(capacity: length)
      pixelBufferLength = length
    }
    pixelBytesPerRow = bytesPerRow
  }

}
