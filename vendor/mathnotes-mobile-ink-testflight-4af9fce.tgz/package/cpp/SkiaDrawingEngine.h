#pragma once

#include <vector>
#include <memory>
#include <string>
#include <cmath>
#include <algorithm>

// Use angle brackets to force system search paths (not CocoaPods symlinks)
#include <include/core/SkCanvas.h>
#include <include/core/SkColorFilter.h>
#include <include/core/SkSurface.h>
#include <include/core/SkPath.h>
#include <include/core/SkPaint.h>
#include <include/core/SkColor.h>
#include <include/core/SkImage.h>
#include <include/core/SkPicture.h>
#include <include/core/SkPathMeasure.h>
#include <include/core/SkPathUtils.h>
#include <SkPathOps.h>
#include <unordered_set>
#include <unordered_map>
#include <mutex>
#include <cstdint>
#include "DrawingTypes.h"

namespace nativedrawing {

// Forward declarations for helper modules
class DrawingSelection;
class BackgroundRenderer;
class DrawingSerialization;
class PathRenderer;
class EraserRenderer;
class StrokeSplitter;
class BatchExporter;
class ActiveStrokeRenderer;
struct EraserMaskOptimizationBatch;

class SkiaDrawingEngine {
public:
    // viewportOnly is for continuous documents. Set a visible viewport before
    // rendering; native views must provide a viewport-sized output target.
    SkiaDrawingEngine(int width, int height, bool viewportOnly = false);
    ~SkiaDrawingEngine();
    bool resizeDocument(int width, int height);

    // Drawing operations (called from touch events)
    void touchBegan(float x, float y, float pressure, float azimuth = 0.0f, float altitude = 1.57f, long timestamp = 0, bool isPencilInput = false);
    void touchMoved(float x, float y, float pressure, float azimuth = 0.0f, float altitude = 1.57f, long timestamp = 0, bool isPencilInput = false);
    void touchEnded(long timestamp = 0);
    bool updateHoldShapePreview(long timestamp);
    void setHoldToShapeEnabled(bool enabled);

    // Predictive touch support (Apple Pencil low-latency rendering)
    void clearPredictedPoints();  // Remove predicted points before adding new actual data
    void addPredictedPoint(float x, float y, float pressure, float azimuth, float altitude, long timestamp, bool isPencilInput = false);

    // Canvas operations
    void clear();
    bool clearDocumentPage(int pageIndex, float pageHeight);
    uint64_t reserveLayerOrder();
    void includeLayerOrder(uint64_t order);
    void setImageLayers(std::vector<ImageLayer> images);
    std::vector<ImageLayer> snapshotImageLayers();
    bool hasImageLayers() const;
    void setInkDisplayTransform(bool dark, bool swapRedBlue);
    // Returns an opaque overlay patch for external edits, or empty for ink/no-op.
    std::string undo();
    std::string redo();
    bool commitExternalEdit(const std::string& before, const std::string& after);
    void eraseObjects();

    // Tool settings
    void setStrokeColor(SkColor color);
    void setStrokeWidth(float width);
    void setTool(const char* toolType);
    void setToolWithParams(const char* toolType, float width, uint32_t color, const char* eraserMode);

    // Background settings
    void setBackgroundType(const char* backgroundType);
    std::string getBackgroundType() const;
    void setPdfBackgroundImage(sk_sp<SkImage> image);

    // Selection operations
    bool selectStrokeAt(float x, float y); // Returns true if stroke was selected
    bool selectShapeStrokeAt(float x, float y); // Finger tap selects only recognized shapes
    void clearSelection();
    void deleteSelection();
    void copySelection();
    void pasteSelection(float offsetX, float offsetY);
    void moveSelection(float dx, float dy);
    void finalizeMove(); // Call when move operation completes to update history
    void beginSelectionTransform(int handleIndex);
    void updateSelectionTransform(float x, float y);
    void finalizeSelectionTransform();
    void cancelSelectionTransform();
    void prepareSelectionDragCache();  // OPTIMIZATION: Pre-cache for fast drag (call when selection changes)
    void beginSelectionDrag();         // Start drag mode (uses pre-cached snapshots)
    void endSelectionDrag();           // Clear drag state
    int getSelectionCount() const;
    std::vector<float> getSelectionBounds(); // Returns [minX, minY, maxX, maxY]

    // Rendering
    void render(SkCanvas* canvas);
    // Render the configured visible rectangle into a viewport-sized target.
    void renderVisibleViewport(SkCanvas* canvas);
    void renderForExport(SkCanvas* canvas);
    void setRenderViewport(
        float renderScale,
        float visibleLeft,
        float visibleTop,
        float visibleWidth,
        float visibleHeight
    );
    void setViewportMotionActive(bool active);
    sk_sp<SkImage> makeSnapshot();

    // Batch export: Render multiple pages to PNG without creating new engine each time
    // Returns vector of base64-encoded PNG strings
    std::vector<std::string> batchExportPages(
        const std::vector<std::vector<uint8_t>>& pagesData,
        const std::vector<std::string>& backgroundTypes,
        const std::vector<sk_sp<SkImage>>& pdfBackgrounds,
        const std::vector<int>& pageIndices,
        float scale
    );

    // Eraser cursor (for pixel eraser visualization)
    void setEraserCursor(float x, float y, float radius, bool visible);
    bool isEraserCursorVisible() const;

    // Serialization
    std::vector<uint8_t> serializeDrawing();
    // Copy committed strokes under the state lock; encode the independent copy off-thread.
    std::vector<Stroke> snapshotDrawing();
    std::unique_ptr<EraserMaskOptimizationBatch> snapshotEraserMasks();
    bool installOptimizedEraserMask(const EraserMaskOptimizationBatch& batch);
    bool deserializeDrawing(const std::vector<uint8_t>& data);
    // Swap already decoded geometry into the engine; caller retains old strokes.
    void replaceDrawing(std::vector<Stroke>& preparedStrokes);

    // State queries
    bool canUndo() const;
    bool canRedo() const;
    bool isEmpty() const;

private:
    // Cap on undo history depth. 20 entries is generous (real users rarely
    // chain past 5 undos). With delta-based history each entry is
    // O(opSize), not O(stateSize), so the total memory cost stays
    // bounded as the stroke count grows -- the memory pathology that
    // forced the previous reduce-the-cap workaround is gone.
    static constexpr size_t MAX_HISTORY_ENTRIES = 20;

    // Delta-history state. Each commit pushes onto undoStack_ and clears
    // redoStack_; undo pops from undoStack_ + reverts + pushes onto
    // redoStack_; redo does the inverse. Both are capped at
    // MAX_HISTORY_ENTRIES (oldest dropped from the bottom of undoStack_).
    std::vector<StrokeDelta> undoStack_;
    std::vector<StrokeDelta> redoStack_;
    void commitDelta(StrokeDelta&& delta);
    void applyDelta(const StrokeDelta& delta);   // forward (used by redo)
    void revertDelta(const StrokeDelta& delta);  // backward (used by undo)
    // Selection and object-eraser state store positions into strokes_. Call
    // whenever strokes_ is rebuilt or compacted (undo/redo/clear/load/object
    // erase) so no stale index can address a different or missing stroke.
    void resetIndexedSelectionState();

    // Pixel-eraser accumulator. During an eraser drag (touchBegan eraser
    // -> touchMoved... -> touchEnded), applyPixelEraserAt only collects
    // circles (and mirrors them into pendingPixelEraserPath_ for the
    // zoomed cutout overlay). touchEnded calls
    // applyPendingPixelEraseToStrokes, which assigns the circles to the
    // strokes they intersect, fills pendingPixelEraseEntries_, and emits
    // one PixelErase delta covering the whole drag. Reset at the start of
    // each eraser touch.
    std::vector<StrokeDelta::PixelEraseEntry> pendingPixelEraseEntries_;
    std::vector<EraserCircle> pendingPixelEraserCircles_;
    SkPath pendingPixelEraserPath_;
    bool applyPendingPixelEraseToStrokes();

    // Continuous documents render bounded tiles instead of a document-sized bitmap.
    const bool viewportOnly_;
    int width_;
    int height_;

    // Current stroke being drawn
    std::vector<Point> currentPoints_;
    SkPath currentPath_;

    // Input smoothing for reducing jitter
    Point lastSmoothedPoint_;
    bool hasLastSmoothedPoint_;
    bool currentStrokeUsesEnhancedPenProfile_ = false;

    // Predictive touch: tracks how many trailing points are predictions (not actual input)
    // These are cleared at the start of each touchMoved and replaced with new predictions
    size_t predictedPointCount_ = 0;

    // Completed strokes
    std::vector<Stroke> strokes_;
    uint64_t layerSequence_ = 4;
    std::vector<ImageLayer> imageLayers_;
    void renderImageLayer(SkCanvas* canvas, const ImageLayer& image);
    SkPaint displayInkPaint(const SkPaint& paint);
    bool displayInkDark_ = false;
    bool displayInkSwap_ = false;
    sk_sp<SkColorFilter> displayInkFilter_;
    std::unordered_map<SkColor, SkColor> displayInkColors_;

    // Pixel eraser circles - applied during rendering to punch holes
    std::vector<EraserCircle> eraserCircles_;

    // (History is now delta-based: undoStack_/redoStack_ declared above
    //  alongside the apply/revert helpers.)

    // Current tool settings
    SkPaint currentPaint_;
    std::string currentTool_;
    std::string eraserMode_;
    std::unordered_set<size_t> pendingDeleteIndices_;

    // Selection state
    std::unordered_set<size_t> selectedIndices_;
    std::vector<Stroke> copiedStrokes_;

    // Selection drag optimization - transform instead of rebuild
    bool isDraggingSelection_ = false;
    bool hasDragCache_ = false;                 // True if snapshots are pre-cached
    float selectionOffsetX_ = 0.0f;
    float selectionOffsetY_ = 0.0f;
    bool isTransformingSelection_ = false;
    bool selectionTransformHasDelta_ = false;
    int selectionTransformHandleIndex_ = -1;
    std::unordered_map<size_t, Stroke> selectionTransformOriginalStrokes_;
    sk_sp<SkImage> dragBackgroundSnapshot_;     // Cache background for O(1) drag
    sk_sp<SkImage> nonSelectedSnapshot_;
    sk_sp<SkImage> selectedSnapshot_;           // Cache selected strokes for O(1) drag
    sk_sp<SkImage> selectionHighlightSnapshot_; // Cache selection highlight too

    // Offscreen surface for rendering strokes only (transparent background)
    // Background patterns are drawn directly to output canvas, not this surface
    sk_sp<SkSurface> strokeSurface_;
    sk_sp<SkImage> cachedStrokeSnapshot_;  // Cached snapshot for fast rendering
    bool needsStrokeRedraw_;

    struct StrokeTileKey {
        int scaleBucket = 100;
        int tileX = 0;
        int tileY = 0;
        uint64_t epoch = 0;

        bool operator==(const StrokeTileKey& other) const {
            return scaleBucket == other.scaleBucket
                && tileX == other.tileX
                && tileY == other.tileY
                && epoch == other.epoch;
        }
    };

    struct StrokeTileKeyHasher {
        size_t operator()(const StrokeTileKey& key) const {
            uint64_t value = static_cast<uint64_t>(static_cast<uint32_t>(key.scaleBucket));
            value = (value * 1315423911u) ^ static_cast<uint32_t>(key.tileX);
            value = (value * 1315423911u) ^ static_cast<uint32_t>(key.tileY);
            value = (value * 1315423911u) ^ key.epoch;
            return static_cast<size_t>(value);
        }
    };

    struct StrokeTileEntry {
        sk_sp<SkImage> image;
        size_t bytes = 0;
        uint64_t lastUsed = 0;
        std::vector<size_t> appendedStrokes;
    };

    std::unordered_map<StrokeTileKey, StrokeTileEntry, StrokeTileKeyHasher> strokeTileCache_;
    uint64_t strokeTileEpoch_ = 1;
    uint64_t strokeTileUseCounter_ = 0;
    size_t strokeTileCacheBytes_ = 0;
    struct CrayonPictureKey {
        uint32_t pathID, color, widthBits;
        bool operator==(const CrayonPictureKey& other) const {
            return pathID == other.pathID && color == other.color && widthBits == other.widthBits;
        }
    };
    struct CrayonPictureKeyHasher {
        size_t operator()(const CrayonPictureKey& key) const {
            return (static_cast<uint64_t>(key.pathID) * 1315423911u ^ key.color) * 1315423911u ^ key.widthBits;
        }
    };
    struct CrayonPictureEntry { sk_sp<SkPicture> picture; size_t bytes; uint64_t used; };
    std::unordered_map<CrayonPictureKey, CrayonPictureEntry, CrayonPictureKeyHasher> crayonPictureCache_;
    size_t crayonPictureCacheBytes_ = 0;
    uint64_t crayonPictureUseCounter_ = 0;
    float renderScale_ = 1.0f;
    float visibleLeft_ = 0.0f;
    float visibleTop_ = 0.0f;
    float visibleWidth_;
    float visibleHeight_;

    // Eraser cursor state
    float eraserCursorX_;
    float eraserCursorY_;
    float eraserCursorRadius_;
    bool showEraserCursor_;

    // Track last eraser position for smooth stroke drawing (not just circles)
    float lastEraserX_ = 0;
    float lastEraserY_ = 0;
    float lastEraserRadius_ = 0;
    bool hasLastEraserPoint_ = false;

    // Track how many circles are already baked into strokeSurface_
    // During render: only apply kClear for circles beyond this count (new circles)
    // During redraw: apply ALL circles, then update this count
    size_t bakedCircleCount_;

    // Dual-surface: tracks which strokes are affected by eraser
    // Strokes with index < maxAffectedStrokeIndex_ can be erased
    // Strokes with index >= maxAffectedStrokeIndex_ are drawn on top (overlay)
    size_t maxAffectedStrokeIndex_;

    // Background type (plain, lined, grid, dotted, graph, pdf)
    std::string backgroundType_;
    float backgroundOriginY_ = 0.0f;

    // PDF background image (set from platform-specific code)
    sk_sp<SkImage> pdfBackgroundImage_;

    // Helper modules (extracted for maintainability)
    std::unique_ptr<DrawingSelection> selection_;
    std::unique_ptr<BackgroundRenderer> backgroundRenderer_;
    std::unique_ptr<DrawingSerialization> serializer_;
    std::unique_ptr<PathRenderer> pathRenderer_;
    std::unique_ptr<EraserRenderer> eraserRenderer_;
    std::unique_ptr<StrokeSplitter> strokeSplitter_;
    std::unique_ptr<BatchExporter> batchExporter_;
    std::unique_ptr<ActiveStrokeRenderer> activeStrokeRenderer_;

    bool hasActiveShapePreview_ = false;
    bool holdToShapeEnabled_ = true;
    bool viewportMotionActive_ = false;
    std::string activeShapePreviewToolType_;
    std::vector<Point> activeShapePreviewPoints_;
    std::vector<Point> activeShapePreviewBasePoints_;
    SkPath activeShapePreviewPath_;
    Point activeShapePreviewAnchorPoint_{0.0f, 0.0f, 1.0f, 0.0f, 1.57079632679f, 1.0f, 0};
    bool hasActiveShapePreviewAnchor_ = false;
    float activeShapePreviewReferenceAngle_ = 0.0f;
    float activeShapePreviewReferenceDistance_ = 1.0f;

    // Helper methods
    void smoothPath(const std::vector<Point>& points, SkPath& path);
    void finishStroke(long endTimestamp = 0);
    void renderStrokeGeometry(SkCanvas* canvas, const Stroke& stroke, const SkPaint& paint);
    void clearActiveShapePreview();
    bool updateActiveShapePreviewForPoint(float x, float y);
    void redrawStrokes();
    void markStrokeCachesDirty();
    void invalidateStrokeTilesForRect(const SkRect& bounds);
    void renderScaleAwareStrokes(SkCanvas* canvas);
    bool drawCachedStrokeTileFallback(SkCanvas* canvas, const StrokeTileKey& key, int tileWidth, int tileHeight);
    void renderActiveContent(SkCanvas* canvas);
    // Draw points as a single constant-width stroked centerline (highlighter/
    // marker). Uses cachedPath when non-empty, else smooths from points.
    void drawCenterlineStrokePath(
        SkCanvas* canvas,
        const std::vector<Point>& points,
        const SkPath& cachedPath,
        const SkPaint& paint
    );
    const void* strokeTileContext_ = nullptr;
    sk_sp<SkImage> renderStrokeTile(SkCanvas* targetCanvas, const StrokeTileKey& key, int tileWidth, int tileHeight, float scale, const std::vector<size_t>& candidates, std::unordered_map<size_t, sk_sp<SkPicture>>& crayonPictures, const sk_sp<SkImage>& base = nullptr);
    bool applyAppendedStrokes(SkCanvas* canvas, const StrokeTileKey& key, StrokeTileEntry& entry);
    void appendStrokeToCachedTiles(const SkRect& bounds, size_t strokeIndex);
    sk_sp<SkPicture> crayonPicture(const Stroke& stroke, const SkPaint& paint);
    void pruneStrokeTileCache();

    // Pixel eraser stroke splitting - splits a stroke by removing portions that intersect the eraser
    std::vector<Stroke> splitStrokeAtPoint(const Stroke& originalStroke, const Point& eraserPoint, float eraserRadius);

    // Bake eraser effect: apply eraserCircles_ to strokes_ permanently via splitStrokeAtPoint
    // Called at touchEnded for pixel eraser - makes eraserCircles_ empty for O(1) rendering
    void bakeEraserCircles();

    // PencilKit-style pixel eraser: immediately splits strokes at eraser point
    // Returns true if any strokes were modified
    void applyPixelEraserAt(float x, float y, float radius);
    void resetPendingPixelErase();

    mutable std::recursive_mutex stateMutex_;
};

} // namespace nativedrawing
