import React from "react";
import type { NotebookPage } from "../types";
import { type InkDisplayAppearance } from '../displayAppearance';
export type PageBackgroundsProps = {
    displayAppearance?: InkDisplayAppearance;
    pages: NotebookPage[];
    pageWidth: number;
    pageHeight: number;
    backgroundType: string;
    pdfBackgroundBaseUri?: string;
    showPageLabels: boolean;
    visiblePageIndex: number;
};
export declare const PageBackgrounds: React.NamedExoticComponent<PageBackgroundsProps>;
export type PageBreaksProps = {
    displayAppearance?: InkDisplayAppearance;
    pages: NotebookPage[];
    pageHeight: number;
    visiblePageIndex?: number;
    viewportHeight?: number;
    minimumScale?: number;
};
/** Include the entire viewport even at minimum zoom, plus several pages of pan runway. */
export declare function pageBreakRange(pageCount: number, visiblePage: number | undefined, pageHeight: number, viewportHeight: number | undefined, minimumScale: number | undefined): {
    first: number;
    last: number;
};
export declare const PageBreaks: React.NamedExoticComponent<PageBreaksProps>;
//# sourceMappingURL=PageStack.d.ts.map