import React, { forwardRef, useImperativeHandle, useCallback, useMemo } from 'react';
import { StyleSheet, View, LayoutChangeEvent } from 'react-native';
import { GestureDetector } from 'react-native-gesture-handler';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
} from 'react-native-reanimated';
import type {
  TouchExclusionRect,
  ZoomableInkViewportProps,
  ZoomableInkViewportRef,
} from './zoomable-ink-viewport/types';
import {
  shouldLockHorizontalTranslation as shouldLockHorizontalTranslationForLayout,
} from './zoomable-ink-viewport/geometry';
import { useViewportTransition } from './zoomable-ink-viewport/useViewportTransition';
import { useZoomableViewportGestures } from './zoomable-ink-viewport/useZoomableViewportGestures';

export type {
  TouchExclusionRect,
  ZoomableInkViewportProps,
  ZoomableInkViewportRef,
} from './zoomable-ink-viewport/types';

/**
 * ZoomableInkViewport - Wraps content with pinch-to-zoom and pan gestures
 *
 * Behavior varies by drawing mode:
 * - Finger mode (fingerDrawingEnabled=true):
 *     Two-finger pinch to zoom, two-finger pan. Single finger draws.
 * - Pencil mode (fingerDrawingEnabled=false):
 *     Two-finger pinch to zoom, one-or-two-finger pan (center area only).
 *     Edge-zone finger touches fall through to page swipe. Stylus draws.
 */
const ZoomableInkViewport = forwardRef<ZoomableInkViewportRef, ZoomableInkViewportProps>(
  (props, ref) => {
    const {
      children,
      style,
      testID = 'ink-viewport',
      minScale = 1,
      maxScale = 5,
      initialScale = 1,
      enabled = true,
      onZoomChange,
      onGestureStateChange,
      onMotionStateChange,
      contentWidth = 0,
      contentHeight = 0,
      contentPadding = 0,
      isLandscape = false,
      fingerDrawingEnabled = true,
      edgeExclusionWidth = 0,
      viewportRef,
      blockedTouchRects = [],
      enableMomentumScroll = false,
      panEnabled = true,
      singleFingerPanBlocked = false,
      lockHorizontalPanNearFit = false,
      onTransformChange,
      transformNotificationMinIntervalMs = 16,
      onContentTap,
    } = props;

    // Layout dimensions
    const containerWidth = useSharedValue(0);
    const containerHeight = useSharedValue(0);

    // Content dimensions (from props, stored as shared values for worklets)
    const contentW = useSharedValue(contentWidth);
    const contentH = useSharedValue(contentHeight);
    const contentPad = useSharedValue(contentPadding);
    const isLandscapeMode = useSharedValue(isLandscape);
    const lockHorizontalPanNearFitValue = useSharedValue(lockHorizontalPanNearFit);
    const blockedRects = useSharedValue<TouchExclusionRect[]>(blockedTouchRects);

    // Update content dimensions when props change
    React.useEffect(() => {
      contentW.value = contentWidth;
      contentH.value = contentHeight;
      contentPad.value = contentPadding;
      isLandscapeMode.value = isLandscape;
      // Note: Initial positioning is handled by CSS (flex-start in landscape, center in portrait)
      // translateY starts at 0 and user can pan to see more content
    }, [contentWidth, contentHeight, contentW, contentH, contentPadding, contentPad, isLandscape, isLandscapeMode]);

    React.useEffect(() => {
      blockedRects.value = blockedTouchRects;
    }, [blockedRects, blockedTouchRects]);

    React.useEffect(() => {
      lockHorizontalPanNearFitValue.value = lockHorizontalPanNearFit;
    }, [lockHorizontalPanNearFit, lockHorizontalPanNearFitValue]);

    // Transform state
    const startingScale = Math.min(maxScale, Math.max(minScale,
      Number.isFinite(initialScale) ? initialScale : 1));
    const scale = useSharedValue(startingScale);
    const translateX = useSharedValue(0);
    const translateY = useSharedValue(0);

    // Saved state for gesture continuity
    const savedScale = useSharedValue(startingScale);
    const savedTranslateX = useSharedValue(0);
    const savedTranslateY = useSharedValue(0);

    // Focal point for pinch, captured at gesture start.
    // event.focalX/focalY are in screen (GestureDetector view) coords --
    // the GestureDetector wraps a stable, untransformed wrapper, so
    // RNGH does NOT apply an inverse content transform here.
    // Treating these as content coords gives wrong math whenever
    // translateX/Y is non-zero.
    const focalX = useSharedValue(0);
    const focalY = useSharedValue(0);

    // Track if we're currently gesturing (for blocking canvas)
    const isGesturingRef = useSharedValue(false);

    // Track if pinch is *actively scaling* (not just "fingers down").
    // Pan yields to pinch only while the scale is changing this frame
    // -- otherwise a 2-finger drag after a zoom would be permanently
    // suppressed because pinch's onEnd never fires until the fingers
    // lift. We update this every pinch.onUpdate based on the per-frame
    // delta of event.scale.
    const isPinchActive = useSharedValue(false);
    const lastPinchEventScale = useSharedValue(1);
    // Per-frame translation deltas for pan: RNGH gives us cumulative
    // translationX since gesture start, but we need per-frame delta so
    // we don't undo pinch's focal-point translateX adjustments.
    const lastPanTranslationX = useSharedValue(0);
    const lastPanTranslationY = useSharedValue(0);
    const isDecayingX = useSharedValue(false);
    const isDecayingY = useSharedValue(false);
    const isClampingX = useSharedValue(false);
    const isClampingY = useSharedValue(false);
    const isMotionActive = useSharedValue(false);
    const lastTransformNotificationTs = useSharedValue(0);

    const handleLayout = useCallback((event: LayoutChangeEvent) => {
      const { width, height } = event.nativeEvent.layout;
      const prevWidth = containerWidth.value;
      const prevHeight = containerHeight.value;
      containerWidth.value = width;
      containerHeight.value = height;

      // On orientation change, reset pan/zoom to defaults. A software keyboard
      // can shrink the viewport height by several hundred pixels too, but it
      // does not rotate the viewport: its width stays stable. Treating that as
      // an orientation change recenters the document and hides the active text
      // box behind the keyboard.
      const isOrientationChange =
        prevWidth > 0 &&
        prevHeight > 0 &&
        Math.abs(width - prevWidth) > 200 &&
        Math.abs(height - prevHeight) > 200;
      if (isOrientationChange) {
        // Reset to initial state - CSS handles positioning (flex-start in landscape, center in portrait)
        translateX.value = 0;
        translateY.value = 0;
        savedTranslateX.value = 0;
        savedTranslateY.value = 0;
        scale.value = 1;
        savedScale.value = 1;
      }
    }, [containerWidth, containerHeight, translateX, translateY, savedTranslateX, savedTranslateY, scale, savedScale]);

    const composedGesture = useZoomableViewportGestures({
      enabled,
      minScale,
      maxScale,
      onZoomChange,
      onGestureStateChange,
      onMotionStateChange,
      fingerDrawingEnabled,
      edgeExclusionWidth,
      enableMomentumScroll,
      panEnabled,
      singleFingerPanBlocked,
      onTransformChange,
      transformNotificationMinIntervalMs,
      onContentTap,
      containerWidth,
      containerHeight,
      contentW,
      contentH,
      contentPad,
      isLandscapeMode,
      lockHorizontalPanNearFitValue,
      blockedRects,
      scale,
      translateX,
      translateY,
      savedScale,
      savedTranslateX,
      savedTranslateY,
      focalX,
      focalY,
      isGesturingRef,
      isPinchActive,
      lastPinchEventScale,
      lastPanTranslationX,
      lastPanTranslationY,
      isDecayingX,
      isDecayingY,
      isClampingX,
      isClampingY,
      isMotionActive,
      lastTransformNotificationTs,
    });

    const applyTransition = useViewportTransition({
      scale, translateX, translateY, savedScale, savedTranslateX, savedTranslateY,
      containerWidth, containerHeight, isGesturingRef, isDecayingX, isDecayingY,
      isClampingX, isClampingY, isMotionActive,
    }, onMotionStateChange, onTransformChange);

    const resetZoom = useCallback(() => {
      applyTransition({ scale: 1, translateX: 0, translateY: 0 }, false);
    }, [applyTransition]);
    const resetZoomAnimated = useCallback(() => {
      applyTransition({ scale: 1, translateX: 0, translateY: 0 }, true);
    }, [applyTransition]);

    const contentFrameStyle = useMemo(() => ({
      height: Math.max(0, contentHeight + contentPadding * 2),
    }), [contentHeight, contentPadding]);

    const isZoomed = useCallback(() => {
      return scale.value > 1.05;
    }, [scale]);

    useImperativeHandle(ref, () => ({
      resetZoom,
      resetZoomAnimated,
      isZoomed,
      getScale: () => scale.value,
      getTransform: () => ({
        scale: scale.value,
        translateX: translateX.value,
        translateY: translateY.value,
        containerWidth: containerWidth.value,
        containerHeight: containerHeight.value,
      }),
      setTransform: ({ scale: nextScale, translateX: nextTranslateX, translateY: nextTranslateY, animated = false }) => {
        const resolvedScale = nextScale ?? scale.value;
        const shouldLockResolvedX = shouldLockHorizontalTranslationForLayout(
          resolvedScale,
          contentWidth,
          containerWidth.value,
          lockHorizontalPanNearFit,
          isLandscape,
        );
        const resolvedTranslateX =
          shouldLockResolvedX
            ? 0
            : nextTranslateX ?? translateX.value;
        const resolvedTranslateY = nextTranslateY ?? translateY.value;

        applyTransition({
          scale: resolvedScale, translateX: resolvedTranslateX, translateY: resolvedTranslateY,
        }, animated);
      },
    }), [resetZoom, resetZoomAnimated, isZoomed, scale, translateX, translateY, containerWidth, containerHeight, savedScale, savedTranslateX, savedTranslateY, lockHorizontalPanNearFit, isLandscape, contentWidth, applyTransition]);

    const animatedStyle = useAnimatedStyle(() => {
      return {
        transformOrigin: [
          containerWidth.value / 2,
          containerHeight.value / 2,
          0,
        ],
        transform: [
          { translateX: translateX.value },
          { translateY: translateY.value },
          { scale: scale.value },
        ],
      };
    });

    // When disabled, render without gesture handling
    if (!enabled) {
      return (
        <View testID={testID} style={[styles.container, style]} onLayout={handleLayout}>
          <View style={contentFrameStyle}>
            {children}
          </View>
        </View>
      );
    }

    // Attach the gesture handler to an untransformed wrapper, and transform an
    // inner view. Pinch focal coordinates are then measured in stable viewport
    // coordinates instead of a view whose own transform is changing every frame.
    return (
      <View testID={testID} ref={viewportRef} style={[styles.clipContainer, style]} collapsable={false}>
        <GestureDetector gesture={composedGesture}>
          <View style={styles.container} onLayout={handleLayout}>
            <Animated.View
              collapsable={false}
              style={[styles.transformedContent, contentFrameStyle, animatedStyle]}
            >
              {children}
            </Animated.View>
          </View>
        </GestureDetector>
      </View>
    );
  }
);

const styles = StyleSheet.create({
  clipContainer: {
    flex: 1,
    overflow: 'hidden', // Clip transformed content
  },
  container: {
    flex: 1,
  },
  transformedContent: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
  },
});

ZoomableInkViewport.displayName = 'ZoomableInkViewport';

export default ZoomableInkViewport;
