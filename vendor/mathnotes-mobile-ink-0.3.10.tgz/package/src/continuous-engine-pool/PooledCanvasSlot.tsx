import React, {
  forwardRef,
  memo,
  useCallback,
  useEffect,
  useImperativeHandle,
  useMemo,
  useRef,
  useState,
} from "react";
import { Image, StyleSheet, View } from "react-native";
import { NativeInkCanvas } from "../NativeInkCanvas";
import type { NativeInkBenchmarkRecordingOptions } from "../benchmark";
import type { NativeSelectionBounds } from "../types";
import {
  BLANK_PAGE_PAYLOAD,
  getPdfBackgroundUri,
  loadCanvasDataWithRetry,
  OFFSCREEN_TOP,
  waitForNextFrame,
} from "./helpers";
import { getPageRenderViewport } from "./renderViewport";
import type {
  ContinuousEnginePoolAssignment,
  ContinuousEnginePoolSlotRef,
  ContinuousEnginePoolToolState,
  NativeCanvasRef,
  PooledCanvasSlotAssignOptions,
  PooledCanvasSlotHandle,
  PooledCanvasSlotProps,
} from "./types";

type SlotPointerEvents = "auto" | "none";

type SlotFrame = {
  top: number;
  height: number;
  opacity: number;
  pointerEvents: SlotPointerEvents;
};

const PAGE_PREVIEW_CAPTURE_SCALE = 0.5;

const hiddenSlotFrame = (height = 0): SlotFrame => ({
  top: OFFSCREEN_TOP,
  height,
  opacity: 0,
  pointerEvents: "none",
});

export const PooledCanvasSlot = memo(forwardRef<PooledCanvasSlotHandle, PooledCanvasSlotProps>(
  function PooledCanvasSlot({
    poolIndex,
    pageWidth,
    canvasHeight,
    contentPadding,
    viewportTransform,
    renderScale,
    displayAppearance,
    backgroundType,
    renderBackend,
    pdfBackgroundBaseUri,
    drawingPolicy,
    getToolState,
    onCanvasReady,
    onSlotLoaded,
    onDrawingChange,
    onSelectionChange,
    onDrawingBegin,
    onPencilDoubleTap,
    registerRef,
    shouldCaptureBeforeReassign,
    capturePreviewOnReassign,
    onCaptureBeforeReassign,
  }, ref) {
    const slotViewRef = useRef<View | null>(null);
    const canvasRef = useRef<NativeCanvasRef | null>(null);
    const [slotFrame, setSlotFrameState] = useState<SlotFrame>(() => hiddenSlotFrame());
    const [previewUri, setPreviewUri] = useState<string | null>(null);
    const [isPreviewVisible, setIsPreviewVisible] = useState(false);
    const lastAttachedCanvasRef = useRef<NativeCanvasRef | null>(null);
    const nativeReadyRef = useRef(false);
    const nativeReadyWaitersRef = useRef<Array<() => void>>([]);
    const isLoadedRef = useRef(false);
    const loadedPageIdRef = useRef<string | null>(null);
    const registeredPageIdRef = useRef<string | null>(null);
    const currentAssignmentRef = useRef<ContinuousEnginePoolAssignment | null>(null);
    const loadTokenRef = useRef(0);
    const forwardedReadyRef = useRef(false);
    const benchmarkRecordingActiveRef = useRef(false);
    const shouldCaptureBeforeReassignRef = useRef(shouldCaptureBeforeReassign);
    const capturePreviewOnReassignRef = useRef(capturePreviewOnReassign);
    const captureCallbackRef = useRef(onCaptureBeforeReassign);
    const onCanvasReadyRef = useRef(onCanvasReady);
    const onSlotLoadedRef = useRef(onSlotLoaded);
    const onSelectionChangeRef = useRef(onSelectionChange);
    const getToolStateRef = useRef(getToolState);

    shouldCaptureBeforeReassignRef.current = shouldCaptureBeforeReassign;
    capturePreviewOnReassignRef.current = capturePreviewOnReassign;
    captureCallbackRef.current = onCaptureBeforeReassign;
    onCanvasReadyRef.current = onCanvasReady;
    onSlotLoadedRef.current = onSlotLoaded;
    onSelectionChangeRef.current = onSelectionChange;
    getToolStateRef.current = getToolState;

    const setNativeCanvasRef = useCallback((nextRef: NativeCanvasRef | null) => {
      canvasRef.current = nextRef;
      if (nextRef) {
        lastAttachedCanvasRef.current = nextRef;
      }
    }, []);

    const waitForNativeReady = useCallback(() => {
      if (nativeReadyRef.current && canvasRef.current) {
        return Promise.resolve();
      }

      return new Promise<void>((resolve) => {
        nativeReadyWaitersRef.current.push(resolve);
      });
    }, []);

    const setSlotFrame = useCallback((
      pageIndex: number | null,
      height: number,
      isVisible: boolean,
      isInteractive = isVisible,
    ) => {
      const nextFrame: SlotFrame = pageIndex === null
        ? hiddenSlotFrame(height)
        : {
            top: pageIndex * height,
            height,
            opacity: isVisible ? 1 : 0,
            pointerEvents: isInteractive ? "auto" : "none",
          };

      setSlotFrameState(nextFrame);
      slotViewRef.current?.setNativeProps({
        style: {
          top: nextFrame.top,
          height: nextFrame.height,
          opacity: nextFrame.opacity,
        },
      });
    }, []);

    const setNativeCanvasVisible = useCallback((isVisible: boolean) => {
      canvasRef.current?.setNativeProps?.({
        style: {
          opacity: isVisible ? 1 : 0,
        },
      });
    }, []);

    const applyToolState = useCallback((toolState: ContinuousEnginePoolToolState) => {
      canvasRef.current?.setTool(
        toolState.toolType,
        toolState.width,
        toolState.color,
        toolState.eraserMode,
      );
    }, []);

    const applyCurrentTool = useCallback(() => {
      applyToolState(getToolStateRef.current());
    }, [applyToolState]);

    const renderViewport = useMemo(() => {
      const pageIndex = slotFrame.top >= 0 && canvasHeight > 0
        ? Math.round(slotFrame.top / canvasHeight)
        : null;

      return getPageRenderViewport(
        viewportTransform, pageIndex, pageWidth, canvasHeight, contentPadding,
      );
    }, [
      canvasHeight,
      contentPadding,
      pageWidth,
      slotFrame.top,
      viewportTransform,
    ]);

    const slotRef = useMemo<ContinuousEnginePoolSlotRef>(
      () => ({
        getBase64Data: async () => {
          const canvas = canvasRef.current;
          const pageId = loadedPageIdRef.current;
          const token = loadTokenRef.current;
          if (!canvas || !pageId || !isLoadedRef.current) {
            throw new Error('Cannot serialize an unloaded ink page.');
          }
          const data = await canvas.getBase64Data();
          if (loadTokenRef.current !== token || loadedPageIdRef.current !== pageId ||
              !isLoadedRef.current || canvasRef.current !== canvas) {
            throw new Error('Ink page assignment changed during serialization.');
          }
          if (!data) throw new Error('Native ink serialization returned no payload.');
          return data;
        },
        getPreviewData: async (scale = PAGE_PREVIEW_CAPTURE_SCALE) => {
          if (!canvasRef.current) return null;
          try {
            return await canvasRef.current.getBase64PngData(scale);
          } catch {
            return null;
          }
        },
        isLoaded: () => isLoadedRef.current,
        setTool: (toolType, width, color, eraserMode) => {
          canvasRef.current?.setTool(toolType, width, color, eraserMode);
        },
        clear: () => {
          canvasRef.current?.clear();
        },
        undo: () => {
          canvasRef.current?.undo();
        },
        redo: () => {
          canvasRef.current?.redo();
        },
        performCopy: () => {
          canvasRef.current?.performCopy();
        },
        performPaste: () => {
          canvasRef.current?.performPaste();
        },
        performDelete: () => {
          canvasRef.current?.performDelete();
        },
        runBenchmark: (options) => {
          if (!canvasRef.current?.runBenchmark) {
            return Promise.reject(new Error("Native benchmark runner is unavailable."));
          }
          return canvasRef.current.runBenchmark(options);
        },
        startBenchmarkRecording: (options) => {
          if (!canvasRef.current?.startBenchmarkRecording) {
            return Promise.reject(new Error("Native benchmark recorder is unavailable."));
          }
          return canvasRef.current.startBenchmarkRecording(options);
        },
        stopBenchmarkRecording: () => {
          if (!canvasRef.current?.stopBenchmarkRecording) {
            return Promise.reject(new Error("Native benchmark recorder is unavailable."));
          }
          return canvasRef.current.stopBenchmarkRecording();
        },
      }),
      [],
    );

    const captureLoadedPage = useCallback(async (
      pageId: string | null,
      sourceRef: NativeCanvasRef | null = canvasRef.current,
    ) => {
      if (
        !pageId ||
        !sourceRef ||
        !isLoadedRef.current ||
        !shouldCaptureBeforeReassignRef.current(pageId)
      ) {
        return;
      }

      const data = await sourceRef.getBase64Data();
      if (!data) throw new Error('Native ink capture returned no payload.');
      let previewUri: string | null = null;
      if (capturePreviewOnReassignRef.current) {
        try {
          previewUri = await sourceRef.getBase64PngData(PAGE_PREVIEW_CAPTURE_SCALE);
        } catch {
          // Previews are replaceable; the drawing payload is not.
          previewUri = null;
        }
      }
      await captureCallbackRef.current(pageId, data, previewUri || undefined);
    }, []);

    const unregisterCurrentPage = useCallback(() => {
      const pageId = registeredPageIdRef.current;
      if (!pageId) {
        return;
      }
      registerRef(pageId, null, slotRef);
      registeredPageIdRef.current = null;
    }, [registerRef, slotRef]);

    const registerAssignment = useCallback((pageId: string) => {
      if (registeredPageIdRef.current === pageId) {
        return;
      }

      unregisterCurrentPage();
      registerRef(pageId, slotRef);
      registeredPageIdRef.current = pageId;
    }, [registerRef, slotRef, unregisterCurrentPage]);

    const clearAssignment = useCallback(async () => {
      const token = loadTokenRef.current + 1;
      loadTokenRef.current = token;
      const previousPageId = loadedPageIdRef.current;
      await captureLoadedPage(previousPageId);
      if (loadTokenRef.current !== token) {
        return;
      }

      unregisterCurrentPage();
      currentAssignmentRef.current = null;
      isLoadedRef.current = false;
      loadedPageIdRef.current = null;
      setPreviewUri(null);
      setIsPreviewVisible(false);
      setNativeCanvasVisible(false);
      setSlotFrame(null, canvasHeight, false);
    }, [
      canvasHeight,
      captureLoadedPage,
      setNativeCanvasVisible,
      setSlotFrame,
      unregisterCurrentPage,
    ]);

    const assign = useCallback(async ({
      assignment,
      assignmentKey,
      canvasHeight: nextCanvasHeight,
      backgroundType: nextBackgroundType,
      pdfBackgroundBaseUri: nextPdfBackgroundBaseUri,
    }: PooledCanvasSlotAssignOptions) => {
      if (!assignment) {
        await clearAssignment();
        return;
      }

      const nextPageId = assignment.page.id;
      const previousPageId = loadedPageIdRef.current;
      const isAlreadyLoadedPage =
        previousPageId === nextPageId && isLoadedRef.current;
      const token = loadTokenRef.current + 1;
      const nextPreviewUri = assignment.page.previewUri ?? null;
      loadTokenRef.current = token;
      // Keep the old engine, registration and frame until its dirty ink is safe.
      if (previousPageId && previousPageId !== nextPageId) {
        await captureLoadedPage(previousPageId);
        if (loadTokenRef.current !== token) return;
      }
      currentAssignmentRef.current = assignment;

      if (!isAlreadyLoadedPage) {
        setPreviewUri(nextPreviewUri);
        setIsPreviewVisible(Boolean(nextPreviewUri));
        setNativeCanvasVisible(false);
        setSlotFrame(assignment.pageIndex, nextCanvasHeight, true, false);
        await waitForNextFrame();
        if (
          loadTokenRef.current !== token ||
          currentAssignmentRef.current?.page.id !== nextPageId
        ) {
          return;
        }
      }

      setSlotFrame(
        assignment.pageIndex,
        nextCanvasHeight,
        true,
        isAlreadyLoadedPage,
      );

      await waitForNativeReady();
      if (
        loadTokenRef.current !== token ||
        currentAssignmentRef.current?.page.id !== nextPageId
      ) {
        return;
      }

      const canvas = canvasRef.current;
      if (!canvas) {
        return;
      }

      if (isAlreadyLoadedPage) {
        setPreviewUri(nextPreviewUri);
        setIsPreviewVisible(false);
        canvas.setNativeProps?.({
          backgroundType: nextBackgroundType,
          pdfBackgroundUri: getPdfBackgroundUri(
            assignment,
            nextBackgroundType,
            nextPdfBackgroundBaseUri,
          ),
          style: {
            opacity: 1,
          },
        });
        registerAssignment(nextPageId);
        applyCurrentTool();
        onSlotLoadedRef.current?.(
          poolIndex,
          assignmentKey,
          nextPageId,
          assignment.pageIndex,
        );
        return;
      }

      canvas.setNativeProps?.({
        backgroundType: nextBackgroundType,
        pdfBackgroundUri: getPdfBackgroundUri(
          assignment,
          nextBackgroundType,
          nextPdfBackgroundBaseUri,
        ),
        style: {
          opacity: 0,
        },
      });

      unregisterCurrentPage();
      isLoadedRef.current = false;
      loadedPageIdRef.current = null;

      try {
        const didLoad = await loadCanvasDataWithRetry(
          canvas,
          assignment.page.data || BLANK_PAGE_PAYLOAD,
        );
        if (!didLoad) {
          throw new Error(`Native canvas engine was not ready for page ${nextPageId}.`);
        }
        if (loadTokenRef.current !== token) {
          return;
        }

        loadedPageIdRef.current = nextPageId;
        isLoadedRef.current = true;
        registerAssignment(nextPageId);
        applyCurrentTool();
        await new Promise<void>((resolve) => {
          requestAnimationFrame(() => {
            requestAnimationFrame(() => resolve());
          });
        });
        if (
          loadTokenRef.current !== token ||
          currentAssignmentRef.current?.page.id !== nextPageId
        ) {
          return;
        }

        setSlotFrame(assignment.pageIndex, nextCanvasHeight, true);
        setNativeCanvasVisible(true);
        setIsPreviewVisible(false);
        onSlotLoadedRef.current?.(
          poolIndex,
          assignmentKey,
          nextPageId,
          assignment.pageIndex,
        );
      } catch (error) {
        if (loadTokenRef.current === token) {
          loadedPageIdRef.current = null;
          isLoadedRef.current = false;
          setNativeCanvasVisible(false);
          setIsPreviewVisible(Boolean(nextPreviewUri));
          unregisterCurrentPage();
        }
        throw error;
      }
    }, [
      applyCurrentTool,
      captureLoadedPage,
      clearAssignment,
      poolIndex,
      registerAssignment,
      setNativeCanvasVisible,
      setSlotFrame,
      waitForNativeReady,
      unregisterCurrentPage,
    ]);

    const release = useCallback(async () => {
      const nativeCanvas = canvasRef.current ?? lastAttachedCanvasRef.current;
      loadTokenRef.current += 1;
      unregisterCurrentPage();
      if (nativeCanvas) {
        if (benchmarkRecordingActiveRef.current) {
          await nativeCanvas.stopBenchmarkRecording?.().catch(() => null);
          benchmarkRecordingActiveRef.current = false;
        }
        // Unmount often happens while React Native is tearing down the native view.
        // Capturing at that point can crash below the JS layer; normal autosave and
        // page-reassignment capture handle persistence while the slot is alive.
        await nativeCanvas.releaseEngine?.().catch(() => {});
        if (lastAttachedCanvasRef.current === nativeCanvas) {
          lastAttachedCanvasRef.current = null;
        }
      }
    }, [unregisterCurrentPage]);

    const startBenchmarkRecording = useCallback(async (
      options?: NativeInkBenchmarkRecordingOptions,
    ) => {
      if (benchmarkRecordingActiveRef.current) {
        return true;
      }
      if (!isLoadedRef.current || !canvasRef.current?.startBenchmarkRecording) {
        return false;
      }

      const didStart = await canvasRef.current.startBenchmarkRecording(options);
      benchmarkRecordingActiveRef.current = didStart;
      return didStart;
    }, []);

    const stopBenchmarkRecording = useCallback(async () => {
      if (!benchmarkRecordingActiveRef.current) {
        return null;
      }
      if (!canvasRef.current?.stopBenchmarkRecording) {
        benchmarkRecordingActiveRef.current = false;
        return null;
      }

      try {
        const result = await canvasRef.current.stopBenchmarkRecording();
        benchmarkRecordingActiveRef.current = false;
        return result;
      } catch (error) {
        benchmarkRecordingActiveRef.current = false;
        const message = error instanceof Error ? error.message : String(error);
        if (message.includes("not running")) {
          return null;
        }
        throw error;
      }
    }, []);

    useImperativeHandle(ref, () => ({
      assign,
      getLoadedPageId: () => isLoadedRef.current ? loadedPageIdRef.current : null,
      applyToolState,
      startBenchmarkRecording,
      stopBenchmarkRecording,
      release,
    }), [
      assign,
      applyToolState,
      release,
      startBenchmarkRecording,
      stopBenchmarkRecording,
    ]);

    useEffect(() => {
      return () => {
        void release();
      };
    }, [release]);

    const handleNativeCanvasReady = useCallback(() => {
      nativeReadyRef.current = true;
      applyCurrentTool();
      if (!forwardedReadyRef.current) {
        forwardedReadyRef.current = true;
        onCanvasReadyRef.current?.();
      }

      const waiters = nativeReadyWaitersRef.current;
      nativeReadyWaitersRef.current = [];
      for (const resolve of waiters) {
        resolve();
      }
    }, [applyCurrentTool]);

    const handleDrawingChange = useCallback(() => {
      const pageId =
        loadedPageIdRef.current ?? currentAssignmentRef.current?.page.id;
      if (pageId) {
        onDrawingChange(pageId);
      }
    }, [onDrawingChange]);

    const handleSelectionChange = useCallback((event: {
      nativeEvent: { count: number; bounds?: NativeSelectionBounds | null };
    }) => {
      const pageId =
        loadedPageIdRef.current ?? currentAssignmentRef.current?.page.id;
      if (pageId) {
        onSelectionChangeRef.current?.(
          pageId,
          event.nativeEvent.count,
          event.nativeEvent.bounds ?? null,
        );
      }
    }, []);

    return (
      <View
        ref={slotViewRef}
        style={[
          styles.slot,
          {
            top: slotFrame.top,
            height: slotFrame.height,
            opacity: slotFrame.opacity,
          },
        ]}
        pointerEvents={slotFrame.pointerEvents}
        collapsable={false}
        testID={`continuous-engine-pool-slot-${poolIndex}`}
      >
        {previewUri ? (
          <Image
            source={{ uri: previewUri }}
            style={[
              styles.previewImage,
              !isPreviewVisible && styles.hiddenPreviewImage,
            ]}
            resizeMode="stretch"
            testID={`continuous-engine-pool-preview-${poolIndex}`}
          />
        ) : null}
        <NativeInkCanvas displayAppearance={displayAppearance}
          ref={setNativeCanvasRef}
          style={styles.nativeCanvas}
          drawingPolicy={drawingPolicy}
          renderBackend={renderBackend}
          renderScale={renderViewport.intersectsViewport ? renderScale : 1}
          renderViewportLeftRatio={renderViewport.leftRatio}
          renderViewportTopRatio={renderViewport.topRatio}
          renderViewportWidthRatio={renderViewport.widthRatio}
          renderViewportHeightRatio={renderViewport.heightRatio}
          onCanvasReady={handleNativeCanvasReady}
          onDrawingBegin={onDrawingBegin}
          onDrawingChange={handleDrawingChange}
          onSelectionChange={handleSelectionChange}
          onPencilDoubleTap={onPencilDoubleTap}
        />
      </View>
    );
  },
), (prev, next) => (
  prev.poolIndex === next.poolIndex &&
  prev.pageWidth === next.pageWidth &&
  prev.canvasHeight === next.canvasHeight &&
  prev.contentPadding === next.contentPadding &&
  prev.viewportTransform === next.viewportTransform &&
  prev.renderScale === next.renderScale &&
  prev.displayAppearance === next.displayAppearance &&
  prev.backgroundType === next.backgroundType &&
  prev.renderBackend === next.renderBackend &&
  prev.pdfBackgroundBaseUri === next.pdfBackgroundBaseUri &&
  prev.drawingPolicy === next.drawingPolicy &&
  prev.getToolState === next.getToolState &&
  prev.onCanvasReady === next.onCanvasReady &&
  prev.onSlotLoaded === next.onSlotLoaded &&
  prev.onDrawingChange === next.onDrawingChange &&
  prev.onSelectionChange === next.onSelectionChange &&
  prev.onDrawingBegin === next.onDrawingBegin &&
  prev.onPencilDoubleTap === next.onPencilDoubleTap &&
  prev.registerRef === next.registerRef &&
  prev.shouldCaptureBeforeReassign === next.shouldCaptureBeforeReassign &&
  prev.capturePreviewOnReassign === next.capturePreviewOnReassign &&
  prev.onCaptureBeforeReassign === next.onCaptureBeforeReassign
));

const styles = StyleSheet.create({
  slot: {
    position: "absolute",
    left: 0,
    right: 0,
    top: OFFSCREEN_TOP,
    height: 0,
    opacity: 0,
  },
  nativeCanvas: {
    ...StyleSheet.absoluteFillObject,
  },
  previewImage: {
    ...StyleSheet.absoluteFillObject,
  },
  hiddenPreviewImage: {
    opacity: 0,
  },
});
