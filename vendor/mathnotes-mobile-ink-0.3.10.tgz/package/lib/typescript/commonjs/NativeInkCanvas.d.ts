import React from 'react';
import type { NativeInkCanvasProps, NativeInkCanvasRef } from "./native-ink-canvas/types";
export type { NativeInkCanvasProps, NativeInkCanvasRef, } from "./native-ink-canvas/types";
export { batchExportPages, composeContinuousWindow, decomposeContinuousWindow, readBodyFileParsed, parseNotebookData, } from "./native-ink-canvas/notebookBridge";
export declare const NativeInkCanvas: React.ForwardRefExoticComponent<NativeInkCanvasProps & React.RefAttributes<NativeInkCanvasRef>>;
//# sourceMappingURL=NativeInkCanvas.d.ts.map