import React from "react";
import type { PooledCanvasSlotHandle, PooledCanvasSlotProps } from "./types";
export declare const PooledCanvasSlot: React.NamedExoticComponent<PooledCanvasSlotProps & React.RefAttributes<PooledCanvasSlotHandle>>;
//# sourceMappingURL=PooledCanvasSlot.d.ts.map