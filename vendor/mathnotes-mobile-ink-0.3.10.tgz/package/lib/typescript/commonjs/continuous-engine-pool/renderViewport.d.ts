import type { ViewportTransformLike } from "../utils/viewportTransform";
/** Native viewport ratios for a page in the centered continuous page stack. */
export declare function getPageRenderViewport(transform: ViewportTransformLike | null, pageIndex: number | null, pageWidth: number, pageHeight: number, contentPadding: number): {
    leftRatio: number;
    topRatio: number;
    widthRatio: number;
    heightRatio: number;
    intersectsViewport: boolean;
};
//# sourceMappingURL=renderViewport.d.ts.map