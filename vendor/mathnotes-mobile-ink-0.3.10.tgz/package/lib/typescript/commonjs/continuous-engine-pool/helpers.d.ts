import type { ContinuousEnginePoolAssignment, NativeCanvasRef } from "./types";
export declare const BLANK_PAGE_PAYLOAD = "{\"pages\":{}}";
export declare const OFFSCREEN_TOP = -100000;
export declare const getAssignmentKey: (assignments: ContinuousEnginePoolAssignment[]) => string;
export declare const getPdfBackgroundUri: (assignment: ContinuousEnginePoolAssignment, backgroundType: string, pdfBackgroundBaseUri?: string) => string | undefined;
export declare const waitForNextFrame: () => Promise<void>;
export declare const loadCanvasDataWithRetry: (canvas: NativeCanvasRef, payload: string, attempts?: number) => Promise<boolean>;
//# sourceMappingURL=helpers.d.ts.map