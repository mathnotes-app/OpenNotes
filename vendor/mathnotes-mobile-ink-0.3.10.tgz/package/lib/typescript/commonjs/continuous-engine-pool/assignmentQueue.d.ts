import type { ContinuousEnginePoolAssignment } from './types';
/** Native loads cannot overlap: an older load could overwrite a newer page. */
export declare function createAssignmentQueue(): {
    enqueue(assignments: ContinuousEnginePoolAssignment[], run: (pages: ContinuousEnginePoolAssignment[], isCurrent: () => boolean) => Promise<void>): Promise<void>;
    captured(pageId: string, data: string, previewUri?: string): void;
    drain(): Promise<void>;
};
//# sourceMappingURL=assignmentQueue.d.ts.map