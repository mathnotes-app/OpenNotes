export declare const MobileInkCanvasViewManager: any;
export declare const MobileInkModule: any;
export declare const MobileInkBridge: any;
export declare const supportsRenderBackendProp: boolean;
export declare const MobileInkCanvasViewNative: import("react-native").HostComponent<any> | (() => never);
//# sourceMappingURL=nativeModules.d.ts.map