import type { InkDisplayAppearance } from '../displayAppearance';
export declare const MobileInkCanvasViewManager: any;
export declare const MobileInkModule: any;
export declare const MobileInkBridge: any;
export declare const supportsRenderBackendProp: boolean;
export declare const supportsInkDisplayAppearance: boolean;
/** Keep document ink and paper readable when JavaScript runs on an older binary. */
export declare function resolveInkDisplayAppearance(requested: InkDisplayAppearance): InkDisplayAppearance;
export declare const MobileInkCanvasViewNative: import("react-native").HostComponent<any> | (() => never);
//# sourceMappingURL=nativeModules.d.ts.map