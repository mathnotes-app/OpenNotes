/**
 * Batch export multiple pages to PNG images natively.
 * This is much faster than exporting pages one by one because it:
 * 1. Creates a single Skia engine and surface (reused for all pages)
 * 2. Doesn't switch visible pages (no UI updates)
 * 3. Processes all pages in a single native call
 *
 * @param pagesData Array of page data objects (JSON format with base64 drawing data)
 * @param backgroundTypes Array of background type strings per page
 * @param width Canvas width in pixels
 * @param height Canvas height in pixels
 * @param scale Export scale factor (e.g., 2.0 for retina)
 * @param pdfBackgroundUri Optional PDF file URI for PDF backgrounds
 * @returns Array of base64 PNG data URIs
 */
export declare function batchExportPages(pagesData: string[], backgroundTypes: string[], width: number, height: number, scale?: number, pdfBackgroundUri?: string, pageIndices?: number[]): Promise<string[]>;
/**
 * Native body-file read + parse.
 *
 * Reads the notebook body file in C++ via NSJSONSerialization and returns
 * the parsed structure to JS. Skips Hermes JSON.parse on a multi-MB string,
 * which is the dominant cost of opening a heavy notebook.
 *
 * Resolves with `null` if the file doesn't exist (caller treats as new file)
 * or if the native fast path isn't available (older build). Rejects on real
 * read/parse errors so the caller can fall back to the slow path.
 *
 * MobileInkBridge/MobileInkModule ship the parser on native platforms.
 */
export declare function readBodyFileParsed(bodyPath: string): Promise<Record<string, unknown> | null>;
export declare function composeContinuousWindow(pagePayloads: string[], pageHeight: number): Promise<string>;
export declare function decomposeContinuousWindow(windowPayload: string, pageCount: number, pageHeight: number): Promise<string[]>;
/** Parse the caller-selected notebook, never a potentially older file on disk.
 * Null means the native parser is unavailable; malformed input rejects. */
export declare function parseNotebookData(data: string): Promise<Record<string, unknown> | null>;
//# sourceMappingURL=notebookBridge.d.ts.map