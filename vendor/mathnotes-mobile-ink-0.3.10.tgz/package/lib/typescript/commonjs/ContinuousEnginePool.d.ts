import React from "react";
import type { ContinuousEnginePoolProps, ContinuousEnginePoolRef } from "./continuous-engine-pool/types";
export type { ContinuousEnginePoolAssignment, ContinuousEnginePoolProps, ContinuousEnginePoolRef, ContinuousEnginePoolSlotRef, ContinuousEnginePoolToolState, } from "./continuous-engine-pool/types";
export declare const ContinuousEnginePool: React.NamedExoticComponent<ContinuousEnginePoolProps & React.RefAttributes<ContinuousEnginePoolRef>>;
//# sourceMappingURL=ContinuousEnginePool.d.ts.map