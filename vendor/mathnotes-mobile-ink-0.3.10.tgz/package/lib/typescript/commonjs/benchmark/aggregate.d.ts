import type { NativeInkBenchmarkRecordingOptions, NativeInkBenchmarkResult } from "./types";
export declare const aggregateNotebookBenchmarkResults: (results: NativeInkBenchmarkResult[], options?: NativeInkBenchmarkRecordingOptions) => NativeInkBenchmarkResult;
//# sourceMappingURL=aggregate.d.ts.map