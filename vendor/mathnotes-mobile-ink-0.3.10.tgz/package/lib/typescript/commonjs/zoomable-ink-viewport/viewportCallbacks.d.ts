import type { ZoomableInkViewportProps } from './types';
export type ViewportCallbacks = Pick<ZoomableInkViewportProps, 'onZoomChange' | 'onGestureStateChange' | 'onMotionStateChange' | 'onTransformChange' | 'onContentTap'>;
/** Keep native-held functions outside the render closure that owns notebook data. */
export declare function createViewportCallbacks(): {
    update(next: ViewportCallbacks | null): void;
    notifyZoomChange: (scale: number) => void | undefined;
    notifyGestureStart: () => void | undefined;
    notifyGestureEnd: () => void | undefined;
    notifyMotionChange: (moving: boolean) => void | undefined;
    notifyTransformChange: (scale: number, translateX: number, translateY: number, containerWidth: number, containerHeight: number) => void | undefined;
    notifyContentTap: (locationX: number, locationY: number) => void | undefined;
};
//# sourceMappingURL=viewportCallbacks.d.ts.map