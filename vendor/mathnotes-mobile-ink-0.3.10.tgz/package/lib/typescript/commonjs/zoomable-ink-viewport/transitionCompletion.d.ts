/** Native may retain this function after timing animations finish. Keep consumers
 * in replaceable state and release them when finished, superseded, or unmounted. */
export declare function createTransitionCompletion(): {
    begin(token: number, axes: number, finish: () => void): void;
    clear(): void;
    completeAxis(token: number, finished?: boolean): void;
};
//# sourceMappingURL=transitionCompletion.d.ts.map