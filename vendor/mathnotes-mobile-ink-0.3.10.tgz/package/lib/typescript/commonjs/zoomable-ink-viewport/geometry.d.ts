export declare const HORIZONTAL_LOCK_MAX_SCALE = 1.12;
export type TranslationBounds = {
    minX: number;
    maxX: number;
    minY: number;
    maxY: number;
};
export declare const clamp: (value: number, min: number, max: number) => number;
/**
 * Calculates pan bounds from the current content, viewport, zoom, and layout mode.
 */
export declare const getTranslationBounds: (currentScale: number, containerW: number, containerH: number, contentWidth: number, contentHeight: number, padding: number, landscape: boolean) => TranslationBounds;
export declare const clampTranslation: (tx: number, ty: number, currentScale: number, containerW: number, containerH: number, contentWidth: number, contentHeight: number, padding: number, landscape: boolean) => {
    x: number;
    y: number;
};
export declare const shouldLockHorizontalTranslation: (currentScale: number, contentWidth: number, containerWidth: number, lockHorizontalPanNearFit: boolean, isLandscape: boolean) => boolean;
/** Invert the centered transform used by ZoomableInkViewport for all touch routing. */
export declare function viewportPointToContent(x: number, y: number, scale: number, translateX: number, translateY: number, width: number, height: number): {
    x: number;
    y: number;
};
//# sourceMappingURL=geometry.d.ts.map