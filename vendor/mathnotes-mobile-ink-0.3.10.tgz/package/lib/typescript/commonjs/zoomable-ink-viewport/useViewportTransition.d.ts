import type { SharedValue } from 'react-native-reanimated';
import type { ZoomableInkViewportProps } from './types';
type NumericKey = 'scale' | 'translateX' | 'translateY' | 'savedScale' | 'savedTranslateX' | 'savedTranslateY' | 'containerWidth' | 'containerHeight';
type MotionKey = 'isGesturingRef' | 'isDecayingX' | 'isDecayingY' | 'isClampingX' | 'isClampingY' | 'isMotionActive';
type Values = {
    [K in NumericKey]: SharedValue<number>;
} & {
    [K in MotionKey]: SharedValue<boolean>;
};
type Transform = {
    scale: number;
    translateX: number;
    translateY: number;
};
/** Imperative jumps must trigger the same pool handoff as a finished gesture. */
export declare function useViewportTransition(values: Values, onMotionStateChange: ZoomableInkViewportProps['onMotionStateChange'], onTransformChange: ZoomableInkViewportProps['onTransformChange']): (next: Transform, animated: boolean) => void;
export {};
//# sourceMappingURL=useViewportTransition.d.ts.map