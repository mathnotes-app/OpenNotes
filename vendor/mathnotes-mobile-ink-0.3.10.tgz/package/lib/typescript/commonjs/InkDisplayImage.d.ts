import React from 'react';
import { type StyleProp, type ImageStyle } from 'react-native';
import { type InkDisplayAppearance } from './displayAppearance';
export type InkDisplayImageProps = {
    uri: string;
    style?: StyleProp<ImageStyle>;
    displayAppearance?: InkDisplayAppearance;
    onReady?: () => void;
    onError?: (error: Error) => void;
};
/** For rendered ink/diagrams. Photos should retain their authored appearance. */
export declare function InkDisplayImage(props: InkDisplayImageProps): React.JSX.Element;
//# sourceMappingURL=InkDisplayImage.d.ts.map