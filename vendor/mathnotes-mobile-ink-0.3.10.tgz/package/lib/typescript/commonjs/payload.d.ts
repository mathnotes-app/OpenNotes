export type NormalizedPagePayload = {
    isValid: boolean;
    normalizedPayload: string;
    reasonCode?: string;
};
export declare function normalizePagePayloadForNativeLoad(pagePayload: string | null | undefined): NormalizedPagePayload;
//# sourceMappingURL=payload.d.ts.map