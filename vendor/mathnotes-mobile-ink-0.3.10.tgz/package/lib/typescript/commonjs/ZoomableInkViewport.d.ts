import React from 'react';
import type { ZoomableInkViewportProps, ZoomableInkViewportRef } from './zoomable-ink-viewport/types';
export type { TouchExclusionRect, ZoomableInkViewportProps, ZoomableInkViewportRef, } from './zoomable-ink-viewport/types';
/**
 * ZoomableInkViewport - Wraps content with pinch-to-zoom and pan gestures
 *
 * Behavior varies by drawing mode:
 * - Finger mode (fingerDrawingEnabled=true):
 *     Two-finger pinch to zoom, two-finger pan. Single finger draws.
 * - Pencil mode (fingerDrawingEnabled=false):
 *     Two-finger pinch to zoom, one-or-two-finger pan (center area only).
 *     Edge-zone finger touches fall through to page swipe. Stylus draws.
 */
declare const ZoomableInkViewport: React.ForwardRefExoticComponent<ZoomableInkViewportProps & React.RefAttributes<ZoomableInkViewportRef>>;
export default ZoomableInkViewport;
//# sourceMappingURL=ZoomableInkViewport.d.ts.map