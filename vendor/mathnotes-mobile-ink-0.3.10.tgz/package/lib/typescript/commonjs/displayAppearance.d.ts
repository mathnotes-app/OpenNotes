export type InkDisplayAppearance = 'light' | 'dark';
export declare const INK_PAPER_COLORS: {
    readonly light: "#FFFFFF";
    readonly dark: "#262626";
};
export declare const DARK_INK_IMAGE_SHADER: string;
/** Matches Skia's lightness inversion in linear RGB; authored values stay intact. */
export declare function inkDisplayColor(authored: string | null | undefined, appearance: InkDisplayAppearance, fallback?: string): string;
//# sourceMappingURL=displayAppearance.d.ts.map