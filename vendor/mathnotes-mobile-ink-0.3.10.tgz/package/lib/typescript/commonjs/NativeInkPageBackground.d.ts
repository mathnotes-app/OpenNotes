import React from "react";
import { StyleProp, ViewStyle } from "react-native";
export type NativeInkPageBackgroundProps = {
    style?: StyleProp<ViewStyle>;
    backgroundType?: "plain" | "lined" | "grid" | "dotted" | "graph" | "pdf" | string;
    pdfBackgroundUri?: string;
};
export declare function NativeInkPageBackground({ style, backgroundType, pdfBackgroundUri, }: NativeInkPageBackgroundProps): React.JSX.Element;
export default NativeInkPageBackground;
//# sourceMappingURL=NativeInkPageBackground.d.ts.map