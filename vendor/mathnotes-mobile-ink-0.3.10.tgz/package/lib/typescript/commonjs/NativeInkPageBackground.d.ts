import React from "react";
import { type InkDisplayAppearance } from './displayAppearance';
import { StyleProp, ViewStyle } from "react-native";
export type NativeInkPageBackgroundProps = {
    style?: StyleProp<ViewStyle>;
    backgroundType?: "plain" | "lined" | "grid" | "dotted" | "graph" | "pdf" | string;
    pdfBackgroundUri?: string;
    displayAppearance?: InkDisplayAppearance;
};
export declare function NativeInkPageBackground({ style, backgroundType, pdfBackgroundUri, displayAppearance: requestedAppearance, }: NativeInkPageBackgroundProps): React.JSX.Element;
export default NativeInkPageBackground;
//# sourceMappingURL=NativeInkPageBackground.d.ts.map