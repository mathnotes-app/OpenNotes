export declare const DEFAULT_PAGE_WIDTH = 820;
export declare const DEFAULT_PAGE_HEIGHT = 1061;
export declare const DEFAULT_INITIAL_PAGE_COUNT = 1;
export declare const DEFAULT_CONTENT_PADDING = 16;
//# sourceMappingURL=constants.d.ts.map