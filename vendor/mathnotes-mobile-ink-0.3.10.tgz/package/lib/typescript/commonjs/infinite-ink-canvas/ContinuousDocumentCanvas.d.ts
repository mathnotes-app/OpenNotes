import React from 'react';
import { type TouchExclusionRect } from '../ZoomableInkViewport';
import type { InfiniteInkCanvasProps, InfiniteInkCanvasRef } from './types';
export type ContinuousDocumentCanvasRef = InfiniteInkCanvasRef & {
    recordExternalEdit: (before: string, after: string) => Promise<boolean>;
};
export type ContinuousDocumentCanvasProps = InfiniteInkCanvasProps & {
    /** Apply this host-owned overlay patch after a native undo/redo. */
    onExternalEdit?: (payload: string) => void;
    /** Host overlay bodies/handles, in unscaled viewport-content coordinates. */
    blockedTouchRects?: TouchExclusionRect[];
    /** Called after the corresponding ink/overlay update has been delivered. */
    onHistoryAction?: (action: "undo" | "redo") => void;
};
/**
 * A save was superseded: ink or pages changed while it captured. Nothing is
 * wrong with the document; the change that superseded it should save again.
 */
export declare class DocumentChangedDuringCaptureError extends Error {
    constructor();
}
/** Checks by name so it also holds when Error subclasses are transpiled. */
export declare const isDocumentCaptureSuperseded: (error: unknown) => boolean;
export declare const ContinuousDocumentCanvas: React.ForwardRefExoticComponent<InfiniteInkCanvasProps & {
    /** Apply this host-owned overlay patch after a native undo/redo. */
    onExternalEdit?: (payload: string) => void;
    /** Host overlay bodies/handles, in unscaled viewport-content coordinates. */
    blockedTouchRects?: TouchExclusionRect[];
    /** Called after the corresponding ink/overlay update has been delivered. */
    onHistoryAction?: (action: "undo" | "redo") => void;
} & React.RefAttributes<ContinuousDocumentCanvasRef>>;
//# sourceMappingURL=ContinuousDocumentCanvas.d.ts.map