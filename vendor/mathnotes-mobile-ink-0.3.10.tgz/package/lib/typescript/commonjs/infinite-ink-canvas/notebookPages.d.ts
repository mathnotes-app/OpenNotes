import type { NotebookPage, SerializedNotebookData } from "../types";
import type { InfiniteInkViewportTransform } from "./types";
export declare const clonePage: (page: NotebookPage, pageIndex: number) => NotebookPage;
export declare const parseNotebookData: (data: SerializedNotebookData | string | undefined) => SerializedNotebookData | null;
export declare const createInitialPages: (initialData: SerializedNotebookData | string | undefined, initialPageCount: number) => NotebookPage[];
export declare const getVisiblePageIndex: (transform: InfiniteInkViewportTransform, pageHeight: number, pageCount: number, contentPadding: number) => number;
//# sourceMappingURL=notebookPages.d.ts.map