export declare const styles: {
    root: {
        flex: number;
        backgroundColor: string;
    };
    viewport: {
        flex: number;
        overflow: "hidden";
    };
    canvasShell: {
        flex: number;
        alignItems: "center";
        justifyContent: "flex-start";
        zIndex: number;
    };
    page: {
        position: "absolute";
        left: number;
        overflow: "hidden";
        backgroundColor: string;
    };
    pageLabel: {
        position: "absolute";
        top: number;
        right: number;
        color: string;
        fontSize: number;
        fontWeight: "700";
    };
    pageBreak: {
        position: "absolute";
        left: number;
        right: number;
        height: number;
        backgroundColor: string;
        zIndex: number;
    };
};
//# sourceMappingURL=styles.d.ts.map