import type { TouchExclusionRect } from "../ZoomableInkViewport";
import type { NativeSelectionBounds } from "../types";
export declare const SELECTION_TOUCH_BLOCK_PADDING = 36;
export type SelectionTouchRectInput = {
    bounds: NativeSelectionBounds | null;
    pageIndex: number;
    pageWidth: number;
    pageHeight: number;
    contentPadding: number;
    containerWidth: number;
    padding?: number;
};
export declare function selectionBoundsToTouchRect({ bounds, pageIndex, pageWidth, pageHeight, contentPadding, containerWidth, padding, }: SelectionTouchRectInput): TouchExclusionRect | null;
//# sourceMappingURL=selectionTouchRects.d.ts.map