import React from "react";
import type { NotebookPage } from "../types";
import { type InkDisplayAppearance } from '../displayAppearance';
export type PageBackgroundsProps = {
    displayAppearance?: InkDisplayAppearance;
    pages: NotebookPage[];
    pageWidth: number;
    pageHeight: number;
    backgroundType: string;
    pdfBackgroundBaseUri?: string;
    showPageLabels: boolean;
    visiblePageIndex: number;
};
export declare const PageBackgrounds: React.NamedExoticComponent<PageBackgroundsProps>;
export type PageBreaksProps = {
    displayAppearance?: InkDisplayAppearance;
    pages: NotebookPage[];
    pageHeight: number;
};
export declare const PageBreaks: React.NamedExoticComponent<PageBreaksProps>;
//# sourceMappingURL=PageStack.d.ts.map