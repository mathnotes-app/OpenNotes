import React from "react";
import type { NotebookPage } from "../types";
export type PageBackgroundsProps = {
    pages: NotebookPage[];
    pageWidth: number;
    pageHeight: number;
    backgroundType: string;
    pdfBackgroundBaseUri?: string;
    showPageLabels: boolean;
    visiblePageIndex: number;
};
export declare const PageBackgrounds: React.NamedExoticComponent<PageBackgroundsProps>;
export type PageBreaksProps = {
    pages: NotebookPage[];
    pageHeight: number;
};
export declare const PageBreaks: React.NamedExoticComponent<PageBreaksProps>;
//# sourceMappingURL=PageStack.d.ts.map