export type ViewportTransformLike = {
    scale: number;
    translateX: number;
    translateY: number;
    containerWidth: number;
    containerHeight: number;
};
export type VisibleContentRect = {
    left: number;
    top: number;
    right: number;
    bottom: number;
    width: number;
    height: number;
};
export declare const getRevealTargetScreenY: (containerHeight: number) => number;
export declare const getRevealTranslateY: (contentY: number, targetScreenY: number, scale: number, containerHeight: number) => number;
export declare const getVisibleContentRect: (transform: ViewportTransformLike) => VisibleContentRect;
//# sourceMappingURL=viewportTransform.d.ts.map