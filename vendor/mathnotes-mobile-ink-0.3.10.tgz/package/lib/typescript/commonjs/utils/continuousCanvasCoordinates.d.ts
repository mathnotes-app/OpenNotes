export interface ContinuousTapInput {
    rawLocationX: number;
    rawLocationY: number;
    isZoomableContentTap: boolean;
    canvasWrapperOffset: {
        x: number;
        y: number;
    };
    canvasHeight: number;
    totalPages: number;
}
export interface ContinuousTapCoordinates {
    stackLocationX: number;
    stackLocationY: number;
    pageIndex: number;
    localX: number;
    localY: number;
}
export declare function resolveContinuousTapCoordinates({ rawLocationX, rawLocationY, isZoomableContentTap, canvasWrapperOffset, canvasHeight, totalPages, }: ContinuousTapInput): ContinuousTapCoordinates | null;
//# sourceMappingURL=continuousCanvasCoordinates.d.ts.map