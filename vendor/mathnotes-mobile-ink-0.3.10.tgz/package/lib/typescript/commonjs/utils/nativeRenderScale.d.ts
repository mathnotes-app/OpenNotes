export declare const MAX_NATIVE_DRAWABLE_PIXELS = 24000000;
export declare const getNativeRenderScaleBudget: (pageWidth: number, pageHeight: number, deviceScale: number) => number;
/** The highest bucket at or below `scale`. */
export declare const quantizeNativeRenderScale: (scale: number, maxScale: number) => number;
/** The bucket native iOS would choose for `scale` (nearest, ties toward lower). */
export declare const nearestNativeRenderScale: (scale: number, maxScale: number) => number;
//# sourceMappingURL=nativeRenderScale.d.ts.map