import { type ViewportTransformLike } from './viewportTransform';
/** Ratios into a whole document, bounded to the visible part of the canvas. */
export declare function getDocumentRenderViewport(transform: ViewportTransformLike | null, pageWidth: number, pageHeight: number, pageCount: number, contentPadding: number): {
    leftRatio: number;
    topRatio: number;
    widthRatio: number;
    heightRatio: number;
};
//# sourceMappingURL=documentViewport.d.ts.map