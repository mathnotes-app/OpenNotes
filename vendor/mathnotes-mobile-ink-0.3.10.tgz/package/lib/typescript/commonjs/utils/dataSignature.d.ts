export declare const computeDataSignature: (data: string) => string;
//# sourceMappingURL=dataSignature.d.ts.map