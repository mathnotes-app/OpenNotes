/**
 * Hermes can copy an external string even when trim removes nothing. Notebook
 * bodies are often tens of MB; inspect their boundaries before asking for a copy.
 * Use JavaScript's whitespace class to preserve trim's Unicode/BOM semantics.
 */
export declare function trimIfNeeded(value: string | null | undefined): string;
//# sourceMappingURL=trimIfNeeded.d.ts.map