import { NotebookPage, SerializedNotebookData, TextBox } from '../types';
/**
 * Serialization utilities for notebook data persistence.
 * Handles conversion between NotebookPage[] and JSON strings for storage.
 */
/**
 * Serializes notebook pages to JSON string for storage
 * @param pages - Array of notebook pages to serialize
 * @param canvasWidth - Current canvas width (stored for cross-device scaling)
 */
export declare const serializeNotebookData: (pages: NotebookPage[], canvasWidth?: number) => string;
export interface DeserializedNotebookData {
    pages: NotebookPage[];
    originalCanvasWidth?: number;
}
export interface PdfNotebookReconciliationResult extends DeserializedNotebookData {
    notebookData: string;
    changed: boolean;
    reasonCode: string;
}
/**
 * Build the in-memory pages structure from an already-parsed notebook
 * object. Pulled out of deserializeNotebookData so the native fast-load
 * path (readBodyFileParsed -> structured object) can share the same
 * migration logic without paying a JSON.parse round-trip on the JS side.
 */
export declare const buildNotebookFromParsed: (data: SerializedNotebookData | null | undefined) => DeserializedNotebookData;
/**
 * Deserializes JSON string back to notebook pages
 * Includes migration logic for backward compatibility
 * @returns Object with pages array and optional originalCanvasWidth for scaling
 */
export declare const deserializeNotebookData: (json: string) => DeserializedNotebookData;
/**
 * Reconciles detected PDF page count with an existing notebook.
 * Existing pages are never replaced or removed; only missing PDF page shells are appended.
 */
export declare const reconcilePdfNotebookPageCount: (existingNotebookData: string | null | undefined, detectedPageCount: number) => PdfNotebookReconciliationResult;
/**
 * Helper function to composite text boxes onto a canvas base64 image
 * Currently returns the original image as text boxes are rendered in PDF HTML template
 *
 * @param base64Image - Base64 encoded image string
 * @param textBoxes - Array of text boxes to composite (currently unused)
 * @param scale - Scaling factor for rendering (currently unused)
 * @returns Base64 encoded image string
 */
export declare const compositeTextBoxesOnImage: (base64Image: string, textBoxes: TextBox[] | undefined, scale?: number) => Promise<string>;
//# sourceMappingURL=serialization.d.ts.map