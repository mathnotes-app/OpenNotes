export declare const CONTINUOUS_ENGINE_POOL_SIZE = 3;
export declare const getContinuousEnginePoolRange: (currentPageIndex: number, totalPages: number, poolSize?: number) => {
    startIndex: number;
    endIndex: number;
};
//# sourceMappingURL=continuousEnginePool.d.ts.map