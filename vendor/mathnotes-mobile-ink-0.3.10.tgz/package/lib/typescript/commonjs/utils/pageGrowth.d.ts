import type { NotebookPage } from "../types";
export declare const BLANK_PAGE_PAYLOAD = "{\"pages\":{}}";
export declare const createBlankPage: (pageIndex: number) => NotebookPage;
export declare const isBlankPagePayload: (data?: string) => boolean;
export declare const pageHasPdfBackground: (page: NotebookPage) => boolean;
export declare const pageHasContent: (page: NotebookPage, dirtyPageIds?: Set<string>) => boolean;
export declare const getLastContentPageIndex: (pages: NotebookPage[], dirtyPageIds?: Set<string>) => number;
export declare const withSingleTrailingBlankPage: (pages: NotebookPage[], dirtyPageIds?: Set<string>, retainedPageIds?: Set<string>) => NotebookPage[];
export declare const appendWritableBlankPage: (pages: NotebookPage[], contentPageIds?: Set<string>, force?: boolean) => {
    pages: NotebookPage[];
    appendedPageId: string | null;
};
//# sourceMappingURL=pageGrowth.d.ts.map