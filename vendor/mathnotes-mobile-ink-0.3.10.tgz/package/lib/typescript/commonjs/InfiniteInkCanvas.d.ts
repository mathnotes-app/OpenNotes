import React from "react";
import type { InfiniteInkCanvasProps, InfiniteInkCanvasRef } from "./infinite-ink-canvas/types";
export type { InfiniteInkCanvasProps, InfiniteInkCanvasRef, InfiniteInkViewportTransform, } from "./infinite-ink-canvas/types";
export declare const InfiniteInkCanvas: React.ForwardRefExoticComponent<InfiniteInkCanvasProps & React.RefAttributes<InfiniteInkCanvasRef>>;
export default InfiniteInkCanvas;
//# sourceMappingURL=InfiniteInkCanvas.d.ts.map